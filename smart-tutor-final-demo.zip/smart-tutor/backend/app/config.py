"""Application settings, loaded from environment variables or a .env file."""
from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    app_name: str = "Smart Tutor Platform"
    # SQLite for local demo; set to postgresql+psycopg2://user:pass@host/db in production
    database_url: str = "sqlite:///./smart_tutor.db"
    secret_key: str = "change-me-in-production-please-use-a-long-random-string"
    access_token_minutes: int = 60 * 12
    cors_origins: str = "http://localhost:5173,http://localhost:3000,http://localhost:8080"

    # LLM: "openai", "anthropic" or "offline". "auto" picks whichever key is present.
    llm_provider: str = "auto"
    openai_api_key: str = ""
    openai_model: str = "gpt-4o-mini"
    anthropic_api_key: str = ""
    anthropic_model: str = "claude-sonnet-4-5"
    llm_timeout_sec: int = 40

    quiz_length: int = 8
    teacher_invite_code: str = "CIT-TEACHER"
    # true = load 23 demo students with fake history (for demos); false = clean start for a real pilot
    seed_demo_students: bool = True


@lru_cache
def get_settings() -> Settings:
    return Settings()
