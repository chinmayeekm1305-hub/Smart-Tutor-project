import logging
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from .config import get_settings
from .database import Base, engine
from .routers import auth, content, quiz, student, teacher, tutor
from .services import llm

logging.basicConfig(level=logging.INFO)
settings = get_settings()
Base.metadata.create_all(bind=engine)
if settings.secret_key.startswith("change-me"):
    logging.getLogger("security").warning("SECRET_KEY is the default value. Set a long random SECRET_KEY before deploying!")

app = FastAPI(title=settings.app_name, version="1.0.0",
              description="Combining Artificial & Natural Intelligence for Adaptive Learning")
app.add_middleware(CORSMiddleware, allow_origins=[o.strip() for o in settings.cors_origins.split(",")],
                   allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

for r in (auth, content, quiz, student, tutor, teacher):
    app.include_router(r.router)


@app.get("/api/health")
def health():
    return {"status": "ok", "llm_provider": llm.provider()}


# Serve the built React app (frontend/dist) from the same server in production
DIST = Path(__file__).resolve().parents[2] / "frontend" / "dist"
if DIST.exists():
    app.mount("/assets", StaticFiles(directory=DIST / "assets"), name="assets")

    @app.get("/{path:path}", include_in_schema=False)
    def spa(path: str):
        f = DIST / path
        return FileResponse(f if path and f.is_file() else DIST / "index.html")
