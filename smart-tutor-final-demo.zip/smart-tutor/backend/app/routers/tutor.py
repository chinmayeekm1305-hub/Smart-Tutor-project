from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field
from sqlalchemy import delete, select
from sqlalchemy.orm import Session

from ..auth import require_student
from ..database import get_db
from ..models import ChatMessage, Mastery, Topic, User
from ..services import adaptive, llm

router = APIRouter(prefix="/api/tutor", tags=["tutor"])


class ChatIn(BaseModel):
    message: str = Field(min_length=1, max_length=3000)
    topic_id: int | None = None


def learner_profile(db: Session, user: User, topic_id: int | None) -> str:
    rows = db.execute(select(Topic.name, Mastery.p_known).join(Mastery, Mastery.topic_id == Topic.id)
                      .where(Mastery.student_id == user.id, Mastery.attempts > 0)).all()
    weak = [n for n, p in rows if p < adaptive.BEGINNER_MAX]
    strong = [n for n, p in rows if p >= adaptive.ADVANCED_MIN]
    lvl = "Intermediate"
    if topic_id:
        m = adaptive.get_mastery(db, user.id, topic_id, create=False)
        if m and m.attempts:
            lvl = adaptive.level_for(m.p_known)
    return (f"{user.name}; level on this topic: {lvl}; weak topics: {', '.join(weak) or 'none yet'}; "
            f"strong topics: {', '.join(strong) or 'none yet'}")


@router.post("/chat")
def chat(data: ChatIn, user: User = Depends(require_student), db: Session = Depends(get_db)):
    t = db.get(Topic, data.topic_id) if data.topic_id else None
    hist_rows = db.scalars(select(ChatMessage).where(ChatMessage.student_id == user.id)
                           .order_by(ChatMessage.id.desc()).limit(10)).all()
    history = [{"role": m.role, "content": m.content} for m in reversed(hist_rows)]
    # Anthropic requires the first message to be from the user
    while history and history[0]["role"] != "user":
        history.pop(0)
    reply, provider = llm.tutor_reply(history, data.message, t.name if t else "",
                                      (t.notes + "\n\n" + t.simple_notes) if t else "",
                                      learner_profile(db, user, data.topic_id))
    db.add_all([ChatMessage(student_id=user.id, topic_id=data.topic_id, role="user", content=data.message),
                ChatMessage(student_id=user.id, topic_id=data.topic_id, role="assistant", content=reply)])
    db.commit()
    return {"reply": reply, "provider": provider}


@router.get("/history")
def history(user: User = Depends(require_student), db: Session = Depends(get_db)):
    rows = db.scalars(select(ChatMessage).where(ChatMessage.student_id == user.id)
                      .order_by(ChatMessage.id.desc()).limit(40)).all()
    return [{"role": m.role, "content": m.content, "created_at": m.created_at.isoformat()} for m in reversed(rows)]


@router.delete("/history")
def clear(user: User = Depends(require_student), db: Session = Depends(get_db)):
    db.execute(delete(ChatMessage).where(ChatMessage.student_id == user.id))
    db.commit()
    return {"ok": True}


@router.get("/status")
def status():
    return {"provider": llm.provider()}
