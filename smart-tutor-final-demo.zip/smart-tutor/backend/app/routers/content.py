from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..auth import get_current_user, require_student
from ..database import get_db
from ..models import Mastery, Question, StudyLog, Subject, Topic, User
from ..services import adaptive

router = APIRouter(prefix="/api", tags=["content"])


@router.get("/subjects")
def subjects(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    mastery = {m.topic_id: m for m in db.scalars(select(Mastery).where(Mastery.student_id == user.id))}
    qcount = dict(db.execute(select(Question.topic_id, func.count()).where(Question.approved.is_(True))
                             .group_by(Question.topic_id)).all())
    out = []
    for s in db.scalars(select(Subject).order_by(Subject.id)):
        topics = []
        for t in s.topics:
            m = mastery.get(t.id)
            topics.append({"id": t.id, "name": t.name, "order": t.order, "questions": qcount.get(t.id, 0),
                           "mastery": round(m.p_known, 3) if m and m.attempts else None,
                           "level": adaptive.level_for(m.p_known) if m and m.attempts else None})
        out.append({"id": s.id, "name": s.name, "description": s.description, "icon": s.icon, "topics": topics})
    return out


@router.get("/topics/{topic_id}")
def topic(topic_id: int, view: str = "auto", user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Notes adapt to the learner: Beginner gets simplified notes, Advanced gets extra depth.
    view=standard|simple|advanced overrides."""
    t = db.get(Topic, topic_id)
    if not t:
        raise HTTPException(404, "Topic not found")
    m = adaptive.get_mastery(db, user.id, t.id, create=False) if user.role == "student" else None
    p = m.p_known if m and m.attempts else None
    level, notes = adaptive.notes_for_level(t, p)
    if view == "simple" and t.simple_notes:
        notes, level = t.simple_notes, "Beginner"
    elif view == "advanced" and t.advanced_notes:
        notes, level = t.notes + "\n\n---\n\n" + t.advanced_notes, "Advanced"
    elif view == "standard":
        notes, level = t.notes, "Intermediate"
    return {"id": t.id, "name": t.name, "subject": t.subject.name, "subject_id": t.subject_id,
            "notes": notes, "level": level, "video_url": t.video_url,
            "mastery": round(p, 3) if p is not None else None,
            "has_simple": bool(t.simple_notes), "has_advanced": bool(t.advanced_notes)}


class StudyIn(BaseModel):
    seconds: int = Field(ge=1, le=3600)


@router.post("/topics/{topic_id}/study")
def log_study(topic_id: int, data: StudyIn, user: User = Depends(require_student), db: Session = Depends(get_db)):
    if not db.get(Topic, topic_id):
        raise HTTPException(404, "Topic not found")
    db.add(StudyLog(student_id=user.id, topic_id=topic_id, seconds=data.seconds))
    db.commit()
    return {"ok": True}
