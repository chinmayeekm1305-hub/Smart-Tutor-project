from fastapi import APIRouter, Depends, HTTPException
from fastapi.security import OAuth2PasswordRequestForm
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..config import get_settings
from ..auth import create_token, get_current_user, hash_password, verify_password
from ..database import get_db
from ..models import User

router = APIRouter(prefix="/api/auth", tags=["auth"])


class RegisterIn(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    email: EmailStr
    password: str = Field(min_length=6, max_length=100)
    role: str = Field(default="student", pattern="^(student|teacher)$")
    academic_info: str = ""
    teacher_code: str = ""  # teachers need the invite code so students can't self-promote


class LoginIn(BaseModel):
    email: EmailStr
    password: str




def user_out(u: User) -> dict:
    return {"id": u.id, "name": u.name, "email": u.email, "role": u.role,
            "academic_info": u.academic_info, "xp": u.xp}


@router.post("/register")
def register(data: RegisterIn, db: Session = Depends(get_db)):
    if db.scalar(select(User).where(User.email == data.email.lower())):
        raise HTTPException(400, "An account with this email already exists")
    if data.role == "teacher" and data.teacher_code != get_settings().teacher_invite_code:
        raise HTTPException(403, "Invalid teacher invite code")
    u = User(name=data.name.strip(), email=data.email.lower(), password_hash=hash_password(data.password),
             role=data.role, academic_info=data.academic_info)
    db.add(u)
    db.commit()
    return {"access_token": create_token(u), "token_type": "bearer", "user": user_out(u)}


@router.post("/login")
def login(data: LoginIn, db: Session = Depends(get_db)):
    u = db.scalar(select(User).where(User.email == data.email.lower()))
    if not u or not verify_password(data.password, u.password_hash):
        raise HTTPException(401, "Incorrect email or password")
    return {"access_token": create_token(u), "token_type": "bearer", "user": user_out(u)}


@router.post("/token", include_in_schema=False)
def token(form: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    """OAuth2 form login so the Swagger 'Authorize' button works."""
    u = db.scalar(select(User).where(User.email == form.username.lower()))
    if not u or not verify_password(form.password, u.password_hash):
        raise HTTPException(401, "Incorrect email or password")
    return {"access_token": create_token(u), "token_type": "bearer"}


class PasswordIn(BaseModel):
    current_password: str
    new_password: str = Field(min_length=6, max_length=100)


@router.post("/change-password")
def change_password(data: PasswordIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if not verify_password(data.current_password, user.password_hash):
        raise HTTPException(400, "Current password is wrong")
    user.password_hash = hash_password(data.new_password)
    db.commit()
    return {"ok": True}


@router.get("/config")
def public_config():
    """Tells the login page whether to show the one-click demo buttons."""
    return {"demo_mode": get_settings().seed_demo_students}


@router.get("/me")
def me(user: User = Depends(get_current_user)):
    return user_out(user)
