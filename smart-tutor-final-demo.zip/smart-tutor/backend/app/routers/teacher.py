"""Teacher side: class analytics, student drill-down, feedback, and the question bank.

AI-generated questions land as approved=False; a teacher reviews and approves them before
students see them. This is the human-in-the-loop ("Natural Intelligence") check on the AI.
"""
from collections import defaultdict

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import Integer, cast, func, select
from sqlalchemy.orm import Session

from ..auth import require_teacher
from ..database import get_db
from ..models import Attempt, Mastery, Question, QuizSession, StudyLog, Subject, TeacherFeedback, Topic, User
from ..services import adaptive, features, llm, ml

router = APIRouter(prefix="/api/teacher", tags=["teacher"])


def _students(db: Session):
    return db.scalars(select(User).where(User.role == "student").order_by(User.name)).all()


def _class_rows(db: Session) -> list[dict]:
    rows = []
    for s in _students(db):
        f = features.student_features(db, s.id)
        rows.append({"id": s.id, "name": s.name, "email": s.email, "academic_info": s.academic_info, "xp": s.xp,
                     **f, "risk": ml.predict_risk(f)})
    clusters = ml.cluster_students(rows)
    for r in rows:
        r["cluster"] = clusters.get(r["id"], "New")
    return rows


@router.get("/overview")
def overview(t: User = Depends(require_teacher), db: Session = Depends(get_db)):
    rows = _class_rows(db)
    active = [r for r in rows if r["n_attempts"] > 0]
    # topic heatmap: class mean mastery & accuracy per topic
    topic_stats = db.execute(
        select(Topic.id, Topic.name, Subject.name, func.avg(Mastery.p_known), func.count(Mastery.id),
               func.sum(Mastery.attempts), func.sum(Mastery.correct))
        .join(Subject, Subject.id == Topic.subject_id)
        .join(Mastery, Mastery.topic_id == Topic.id, isouter=True)
        .where((Mastery.attempts > 0) | (Mastery.id.is_(None)))
        .group_by(Topic.id, Topic.name, Subject.name).order_by(Subject.name, Topic.id)).all()
    topics = [{"topic_id": tid, "topic": tn, "subject": sn, "avg_mastery": round(am or 0, 3), "students": n or 0,
               "accuracy": round((c or 0) / a, 3) if a else None} for tid, tn, sn, am, n, a, c in topic_stats]
    # most-missed questions
    missed = db.execute(
        select(Question.id, Question.text, Topic.name, func.count(Attempt.id),
               func.sum(cast(Attempt.is_correct, Integer)))
        .join(Attempt, Attempt.question_id == Question.id).join(Topic, Topic.id == Question.topic_id)
        .group_by(Question.id, Question.text, Topic.name).having(func.count(Attempt.id) >= 3)).all()
    missed = sorted([{"question_id": i, "text": tx, "topic": tn, "attempts": n, "accuracy": round((c or 0) / n, 3)}
                     for i, tx, tn, n, c in missed], key=lambda r: r["accuracy"])[:8]
    cluster_counts = defaultdict(int)
    for r in rows:
        cluster_counts[r["cluster"]] += 1
    unread = db.scalar(select(func.count()).select_from(TeacherFeedback)
                       .where(TeacherFeedback.from_student.is_(True), TeacherFeedback.is_read.is_(False)))
    pending = db.scalar(select(func.count()).select_from(Question).where(Question.approved.is_(False)))
    at_risk = sorted([r for r in rows if r["risk"]["risk"] is not None and r["risk"]["risk"] >= 0.3],
                     key=lambda r: -r["risk"]["risk"])
    return {
        "kpis": {"students": len(rows), "active": len(active),
                 "avg_accuracy": round(sum(r["accuracy"] for r in active) / len(active), 3) if active else 0,
                 "at_risk": sum(1 for r in rows if r["risk"]["label"] == "High risk"),
                 "quizzes": db.scalar(select(func.count()).select_from(QuizSession)
                                      .where(QuizSession.finished_at.is_not(None))),
                 "unread_doubts": unread, "pending_questions": pending},
        "clusters": [{"name": k, "count": v} for k, v in cluster_counts.items()],
        "students": [{k: r[k] for k in ("id", "name", "academic_info", "accuracy", "n_attempts", "mastery_avg",
                                        "trend", "avg_time", "study_minutes", "cluster", "risk", "xp")} for r in rows],
        "at_risk": [{"id": r["id"], "name": r["name"], "risk": r["risk"], "cluster": r["cluster"]} for r in at_risk[:8]],
        "topics": topics,
        "most_missed": missed,
    }


@router.get("/students/{student_id}")
def student_detail(student_id: int, t: User = Depends(require_teacher), db: Session = Depends(get_db)):
    s = db.get(User, student_id)
    if not s or s.role != "student":
        raise HTTPException(404, "Student not found")
    f = features.student_features(db, s.id)
    mast = db.execute(select(Topic, Mastery).join(Mastery, Mastery.topic_id == Topic.id)
                      .where(Mastery.student_id == s.id, Mastery.attempts > 0)).all()
    sessions = db.scalars(select(QuizSession).where(QuizSession.student_id == s.id,
                                                    QuizSession.finished_at.is_not(None))
                          .order_by(QuizSession.finished_at.desc()).limit(15)).all()
    msgs = db.scalars(select(TeacherFeedback).where(TeacherFeedback.student_id == s.id)
                      .order_by(TeacherFeedback.created_at)).all()
    study = db.execute(select(Topic.name, func.sum(StudyLog.seconds)).join(Topic, Topic.id == StudyLog.topic_id)
                       .where(StudyLog.student_id == s.id).group_by(Topic.name)).all()
    mistakes = []
    for qid, c in adaptive.topic_mistakes(db, s.id)[:6]:
        q = db.get(Question, qid)
        mistakes.append({"question_id": qid, "text": q.text, "topic": q.topic.name, "times_wrong": c})
    return {
        "student": {"id": s.id, "name": s.name, "email": s.email, "academic_info": s.academic_info, "xp": s.xp},
        "features": f, "risk": ml.predict_risk(f),
        "topics": sorted([{"topic_id": tp.id, "topic": tp.name, "subject": tp.subject.name,
                           "mastery": round(m.p_known, 3), "level": adaptive.level_for(m.p_known),
                           "attempts": m.attempts, "accuracy": round(m.correct / m.attempts, 3)} for tp, m in mast],
                         key=lambda r: r["mastery"]),
        "trend": features.daily_accuracy(db, s.id, 21),
        "sessions": [{"topic": q.topic.name, "score": q.score, "total": q.total,
                      "date": q.finished_at.isoformat()} for q in sessions],
        "study": [{"topic": n, "minutes": round((sec or 0) / 60, 1)} for n, sec in study],
        "mistakes": mistakes,
        "messages": [{"id": m.id, "from_student": m.from_student, "message": m.message,
                      "created_at": m.created_at.isoformat(), "is_read": m.is_read} for m in msgs],
    }


class FeedbackIn(BaseModel):
    student_id: int
    message: str = Field(min_length=2, max_length=2000)
    topic_id: int | None = None


@router.post("/feedback")
def send_feedback(data: FeedbackIn, t: User = Depends(require_teacher), db: Session = Depends(get_db)):
    s = db.get(User, data.student_id)
    if not s or s.role != "student":
        raise HTTPException(404, "Student not found")
    db.add(TeacherFeedback(teacher_id=t.id, student_id=s.id, topic_id=data.topic_id, message=data.message))
    # reading a student's thread marks their doubts as handled
    for m in db.scalars(select(TeacherFeedback).where(TeacherFeedback.student_id == s.id,
                                                      TeacherFeedback.from_student.is_(True))):
        m.is_read = True
    db.commit()
    return {"ok": True}


@router.get("/doubts")
def doubts(t: User = Depends(require_teacher), db: Session = Depends(get_db)):
    rows = db.scalars(select(TeacherFeedback).where(TeacherFeedback.from_student.is_(True))
                      .order_by(TeacherFeedback.is_read, TeacherFeedback.created_at.desc()).limit(50)).all()
    out = []
    for m in rows:
        st = db.get(User, m.student_id)
        tp = db.get(Topic, m.topic_id) if m.topic_id else None
        out.append({"id": m.id, "student_id": st.id, "student": st.name, "topic": tp.name if tp else None,
                    "message": m.message, "is_read": m.is_read, "created_at": m.created_at.isoformat()})
    return out


# ------------------------------------------------------------------ question bank
class QuestionIn(BaseModel):
    topic_id: int
    text: str = Field(min_length=5)
    options: list[str] = Field(min_length=4, max_length=4)
    correct_index: int = Field(ge=0, le=3)
    explanation: str = ""
    difficulty: int = Field(default=2, ge=1, le=3)
    approved: bool = True


def qdict(q: Question) -> dict:
    return {"id": q.id, "topic_id": q.topic_id, "topic": q.topic.name, "subject": q.topic.subject.name,
            "text": q.text, "options": q.options, "correct_index": q.correct_index, "explanation": q.explanation,
            "difficulty": q.difficulty, "source": q.source, "approved": q.approved}


@router.get("/questions")
def list_questions(topic_id: int | None = None, pending: bool = False,
                   t: User = Depends(require_teacher), db: Session = Depends(get_db)):
    q = select(Question).order_by(Question.approved, Question.topic_id, Question.difficulty, Question.id)
    if topic_id:
        q = q.where(Question.topic_id == topic_id)
    if pending:
        q = q.where(Question.approved.is_(False))
    return [qdict(x) for x in db.scalars(q)]


@router.post("/questions")
def create_question(data: QuestionIn, t: User = Depends(require_teacher), db: Session = Depends(get_db)):
    if not db.get(Topic, data.topic_id):
        raise HTTPException(404, "Topic not found")
    q = Question(**data.model_dump(), source="teacher", created_by=t.id)
    db.add(q)
    db.commit()
    return qdict(q)


@router.put("/questions/{qid}")
def update_question(qid: int, data: QuestionIn, t: User = Depends(require_teacher), db: Session = Depends(get_db)):
    q = db.get(Question, qid)
    if not q:
        raise HTTPException(404, "Question not found")
    for k, v in data.model_dump().items():
        setattr(q, k, v)
    db.commit()
    return qdict(q)


@router.post("/questions/{qid}/approve")
def approve(qid: int, t: User = Depends(require_teacher), db: Session = Depends(get_db)):
    q = db.get(Question, qid)
    if not q:
        raise HTTPException(404, "Question not found")
    q.approved = True
    db.commit()
    return qdict(q)


@router.delete("/questions/{qid}")
def delete_question(qid: int, t: User = Depends(require_teacher), db: Session = Depends(get_db)):
    q = db.get(Question, qid)
    if not q:
        raise HTTPException(404, "Question not found")
    if db.scalar(select(Attempt.id).where(Attempt.question_id == qid).limit(1)):
        q.approved = False  # keep history intact; just retire it
        db.commit()
        return {"ok": True, "retired": True}
    db.delete(q)
    db.commit()
    return {"ok": True}


class GenerateIn(BaseModel):
    topic_id: int
    difficulty: int = Field(default=2, ge=1, le=3)
    count: int = Field(default=3, ge=1, le=10)


@router.post("/questions/generate")
def generate(data: GenerateIn, t: User = Depends(require_teacher), db: Session = Depends(get_db)):
    tp = db.get(Topic, data.topic_id)
    if not tp:
        raise HTTPException(404, "Topic not found")
    qs, provider = llm.generate_questions(tp.name, tp.subject.name, tp.notes + "\n" + tp.advanced_notes,
                                          data.difficulty, data.count)
    created = []
    for g in qs:
        q = Question(topic_id=tp.id, text=g["text"], options=g["options"], correct_index=g["correct_index"],
                     explanation=g.get("explanation", ""), difficulty=g.get("difficulty", data.difficulty),
                     source="ai", approved=False, created_by=t.id)
        db.add(q)
        db.flush()
        created.append(q)
    db.commit()
    return {"provider": provider, "questions": [qdict(q) for q in created]}


# ------------------------------------------------------------------ content
class NotesIn(BaseModel):
    notes: str | None = None
    simple_notes: str | None = None
    advanced_notes: str | None = None
    video_url: str | None = None


@router.get("/topics/{topic_id}")
def get_topic(topic_id: int, t: User = Depends(require_teacher), db: Session = Depends(get_db)):
    tp = db.get(Topic, topic_id)
    if not tp:
        raise HTTPException(404, "Topic not found")
    return {"id": tp.id, "name": tp.name, "subject": tp.subject.name, "notes": tp.notes,
            "simple_notes": tp.simple_notes, "advanced_notes": tp.advanced_notes, "video_url": tp.video_url}


@router.put("/topics/{topic_id}")
def update_topic(topic_id: int, data: NotesIn, t: User = Depends(require_teacher), db: Session = Depends(get_db)):
    tp = db.get(Topic, topic_id)
    if not tp:
        raise HTTPException(404, "Topic not found")
    for k, v in data.model_dump(exclude_none=True).items():
        setattr(tp, k, v)
    db.commit()
    return {"ok": True}


class SimplifyIn(BaseModel):
    level: str = Field(default="Beginner", pattern="^(Beginner|Advanced)$")


@router.post("/topics/{topic_id}/ai-notes")
def ai_notes(topic_id: int, data: SimplifyIn, t: User = Depends(require_teacher), db: Session = Depends(get_db)):
    """Draft a simplified / advanced version of the notes for the teacher to edit and save."""
    tp = db.get(Topic, topic_id)
    if not tp:
        raise HTTPException(404, "Topic not found")
    return {"draft": llm.simplify(tp.notes, data.level), "provider": llm.provider()}


@router.get("/model")
def model_info(t: User = Depends(require_teacher)):
    return {"metrics": ml.model_metrics(), "llm_provider": llm.provider()}
