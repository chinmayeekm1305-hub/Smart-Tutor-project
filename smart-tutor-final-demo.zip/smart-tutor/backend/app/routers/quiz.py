"""Adaptive quiz with instant feedback.

Flow: POST /start -> first question; POST /{id}/answer -> verdict + explanation + updated mastery
+ next question (difficulty adapted), until quiz_length questions are answered.
"""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..auth import require_student
from ..config import get_settings
from ..database import get_db
from ..models import Attempt, Question, QuizSession, Topic, User, now
from ..services import adaptive, llm

router = APIRouter(prefix="/api/quiz", tags=["quiz"])


def q_out(q: Question, number: int, total: int) -> dict:
    # never send correct_index to the client before the answer
    return {"id": q.id, "text": q.text, "options": q.options, "difficulty": q.difficulty,
            "number": number, "total": total}


class StartIn(BaseModel):
    topic_id: int


@router.post("/start")
def start(data: StartIn, user: User = Depends(require_student), db: Session = Depends(get_db)):
    t = db.get(Topic, data.topic_id)
    if not t:
        raise HTTPException(404, "Topic not found")
    m = adaptive.get_mastery(db, user.id, t.id)
    diff = adaptive.target_difficulty(m.p_known, [])
    q = adaptive.pick_next_question(db, user.id, t.id, diff, set())
    if not q:
        raise HTTPException(400, "This topic has no questions yet")
    total = get_settings().quiz_length
    s = QuizSession(student_id=user.id, topic_id=t.id, total=total, current_question_id=q.id)
    db.add(s)
    db.commit()
    return {"session_id": s.id, "topic": t.name, "subject": t.subject.name,
            "mastery": round(m.p_known, 3), "level": adaptive.level_for(m.p_known),
            "question": q_out(q, 1, total)}


class AnswerIn(BaseModel):
    question_id: int
    selected_index: int = Field(ge=0, le=3)
    time_taken_sec: float = Field(default=0, ge=0, le=3600)


@router.post("/{session_id}/answer")
def answer(session_id: int, data: AnswerIn, user: User = Depends(require_student), db: Session = Depends(get_db)):
    s = db.get(QuizSession, session_id)
    if not s or s.student_id != user.id:
        raise HTTPException(404, "Quiz not found")
    if s.finished_at:
        raise HTTPException(400, "Quiz already finished")
    if s.current_question_id != data.question_id:
        raise HTTPException(400, "That is not the current question")
    q = db.get(Question, data.question_id)
    correct = data.selected_index == q.correct_index

    before = adaptive.get_mastery(db, user.id, q.topic_id).p_known
    db.add(Attempt(session_id=s.id, student_id=user.id, question_id=q.id, topic_id=q.topic_id,
                   selected_index=data.selected_index, is_correct=correct, difficulty=q.difficulty,
                   time_taken_sec=data.time_taken_sec))
    m = adaptive.record_answer(db, user.id, q, correct)
    gained = adaptive.xp_for(correct, q.difficulty)
    user.xp += gained
    s.score += int(correct)
    db.flush()

    history = [a.is_correct for a in db.scalars(select(Attempt).where(Attempt.session_id == s.id)
                                                 .order_by(Attempt.id))]
    feedback = {"correct": correct, "correct_index": q.correct_index, "explanation": q.explanation,
                "mastery_before": round(before, 3), "mastery": round(m.p_known, 3),
                "level": adaptive.level_for(m.p_known), "xp_gained": gained, "score": s.score,
                "answered": len(history)}

    if len(history) >= s.total:
        s.finished_at = now()
        s.current_question_id = None
        db.commit()
        return {**feedback, "finished": True, "next_question": None}

    diff = adaptive.target_difficulty(m.p_known, history)
    seen = set(db.scalars(select(Attempt.question_id).where(Attempt.session_id == s.id)))
    nq = adaptive.pick_next_question(db, user.id, s.topic_id, diff, seen)
    if not nq:  # ran out of questions: finish early
        s.total = len(history)
        s.finished_at = now()
        s.current_question_id = None
        db.commit()
        return {**feedback, "finished": True, "next_question": None}
    s.current_question_id = nq.id
    db.commit()
    reason = ("Stepping up: harder question" if nq.difficulty > q.difficulty else
              "Easing off: let's rebuild confidence" if nq.difficulty < q.difficulty else "Same level")
    return {**feedback, "finished": False, "adapt_reason": reason,
            "next_question": q_out(nq, len(history) + 1, s.total)}


class ExplainIn(BaseModel):
    question_id: int
    selected_index: int = Field(ge=0, le=3)


@router.post("/explain")
def explain(data: ExplainIn, user: User = Depends(require_student), db: Session = Depends(get_db)):
    """Personalised AI explanation of a wrong answer."""
    q = db.get(Question, data.question_id)
    if not q:
        raise HTTPException(404, "Question not found")
    answered = db.scalar(select(Attempt.id).where(Attempt.student_id == user.id, Attempt.question_id == q.id))
    if not answered:
        raise HTTPException(400, "Answer the question first")
    m = adaptive.get_mastery(db, user.id, q.topic_id, create=False)
    level = adaptive.level_for(m.p_known) if m else "Intermediate"
    text = llm.explain_mistake(q.text, q.options, q.correct_index, data.selected_index, q.explanation, level)
    return {"explanation": text, "provider": llm.provider()}


@router.get("/{session_id}/result")
def result(session_id: int, user: User = Depends(require_student), db: Session = Depends(get_db)):
    s = db.get(QuizSession, session_id)
    if not s or s.student_id != user.id:
        raise HTTPException(404, "Quiz not found")
    atts = db.scalars(select(Attempt).where(Attempt.session_id == s.id).order_by(Attempt.id)).all()
    m = adaptive.get_mastery(db, user.id, s.topic_id, create=False)
    review = [{"question_id": a.question_id, "text": a.question.text, "options": a.question.options,
               "selected_index": a.selected_index, "correct_index": a.question.correct_index,
               "is_correct": a.is_correct, "difficulty": a.difficulty, "explanation": a.question.explanation,
               "time_taken_sec": a.time_taken_sec} for a in atts]
    wrong = [r for r in review if not r["is_correct"]]
    if not atts:
        tip = "No answers recorded."
    elif s.score / len(atts) >= 0.8:
        tip = "Excellent! Try the advanced notes or move to the next topic."
    elif wrong:
        tip = "Review the explanations below, then use the AI tutor for any doubt that remains."
    else:
        tip = "Good progress. One more quiz will strengthen this topic."
    return {"session_id": s.id, "topic": s.topic.name, "topic_id": s.topic_id, "score": s.score,
            "total": len(atts), "mastery": round(m.p_known, 3) if m else None,
            "level": adaptive.level_for(m.p_known) if m else None, "tip": tip, "review": review,
            "avg_time": round(sum(a.time_taken_sec for a in atts) / len(atts), 1) if atts else 0}


@router.get("/mistakes")
def mistakes(user: User = Depends(require_student), db: Session = Depends(get_db)):
    """Questions the student repeatedly gets wrong: the revision list."""
    out = []
    for qid, count in adaptive.topic_mistakes(db, user.id):
        q = db.get(Question, qid)
        out.append({"question_id": qid, "text": q.text, "options": q.options, "correct_index": q.correct_index,
                    "explanation": q.explanation, "topic": q.topic.name, "topic_id": q.topic_id, "times_wrong": count})
    return out
