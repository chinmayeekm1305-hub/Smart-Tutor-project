from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import Integer, cast, func, select
from sqlalchemy.orm import Session

from ..auth import require_student
from ..database import get_db
from ..models import Attempt, Mastery, QuizSession, Subject, TeacherFeedback, Topic, User
from ..services import adaptive, features, ml

router = APIRouter(prefix="/api/student", tags=["student"])


@router.get("/dashboard")
def dashboard(user: User = Depends(require_student), db: Session = Depends(get_db)):
    f = features.student_features(db, user.id)
    subj_names = {s.id: s.name for s in db.scalars(select(Subject))}
    subjects = [{**s, "name": subj_names.get(s["subject_id"], "")}
                for s in adaptive.subject_summary(db, user.id)]
    topic_rows = db.execute(select(Topic, Mastery).join(Mastery, Mastery.topic_id == Topic.id)
                            .where(Mastery.student_id == user.id, Mastery.attempts > 0)).all()
    topics = sorted([{"topic_id": t.id, "topic": t.name, "subject": t.subject.name, "mastery": round(m.p_known, 3),
                      "level": adaptive.level_for(m.p_known), "attempts": m.attempts,
                      "accuracy": round(m.correct / m.attempts, 3)} for t, m in topic_rows],
                    key=lambda r: r["mastery"])
    recent = db.scalars(select(QuizSession).where(QuizSession.student_id == user.id,
                                                  QuizSession.finished_at.is_not(None))
                        .order_by(QuizSession.finished_at.desc()).limit(6)).all()
    msgs = db.scalars(select(TeacherFeedback).where(TeacherFeedback.student_id == user.id)
                      .order_by(TeacherFeedback.created_at.desc()).limit(10)).all()
    return {
        "user": {"name": user.name, "xp": user.xp, "academic_info": user.academic_info,
                 "level_badge": "Gold" if user.xp >= 600 else "Silver" if user.xp >= 250 else "Bronze"},
        "stats": {"accuracy": f["accuracy"], "attempts": f["n_attempts"], "study_minutes": f["study_minutes"],
                  "active_days": f["active_days"], "avg_time": f["avg_time"], "trend": f["trend"],
                  "quizzes": db.scalar(select(func.count()).select_from(QuizSession)
                                       .where(QuizSession.student_id == user.id, QuizSession.finished_at.is_not(None)))},
        "learning_health": ml.predict_risk(f),
        "subjects": subjects,
        "topics": topics,
        "strengths": [t for t in reversed(topics) if t["mastery"] >= adaptive.ADVANCED_MIN][:3],
        "weaknesses": [t for t in topics if t["mastery"] < adaptive.BEGINNER_MAX][:3],
        "recommendations": adaptive.recommendations(db, user.id)[:6],
        "trend": features.daily_accuracy(db, user.id),
        "recent_quizzes": [{"id": q.id, "topic": q.topic.name, "score": q.score, "total": q.total,
                            "finished_at": q.finished_at.isoformat()} for q in recent],
        "messages": [{"id": m.id, "from_student": m.from_student, "teacher": m.teacher.name, "message": m.message,
                      "is_read": m.is_read, "created_at": m.created_at.isoformat()} for m in msgs],
    }


@router.post("/messages/{msg_id}/read")
def mark_read(msg_id: int, user: User = Depends(require_student), db: Session = Depends(get_db)):
    m = db.get(TeacherFeedback, msg_id)
    if not m or m.student_id != user.id:
        raise HTTPException(404, "Message not found")
    m.is_read = True
    db.commit()
    return {"ok": True}


class DoubtIn(BaseModel):
    message: str = Field(min_length=3, max_length=2000)
    topic_id: int | None = None


@router.post("/doubts")
def ask_teacher(data: DoubtIn, user: User = Depends(require_student), db: Session = Depends(get_db)):
    """Escalate a doubt to a human teacher (Natural Intelligence)."""
    teacher = db.scalar(select(User).where(User.role == "teacher").order_by(User.id))
    if not teacher:
        raise HTTPException(400, "No teacher available")
    db.add(TeacherFeedback(teacher_id=teacher.id, student_id=user.id, topic_id=data.topic_id,
                           message=data.message, from_student=True))
    db.commit()
    return {"ok": True, "teacher": teacher.name}


@router.get("/progress")
def progress(user: User = Depends(require_student), db: Session = Depends(get_db)):
    sessions = db.scalars(select(QuizSession).where(QuizSession.student_id == user.id,
                                                    QuizSession.finished_at.is_not(None))
                          .order_by(QuizSession.finished_at)).all()
    by_diff = db.execute(select(Attempt.difficulty, func.count(), func.sum(cast(Attempt.is_correct, Integer)))
                         .where(Attempt.student_id == user.id).group_by(Attempt.difficulty)).all()
    return {
        "sessions": [{"id": s.id, "topic": s.topic.name, "subject": s.topic.subject.name, "score": s.score,
                      "total": s.total, "pct": round(100 * s.score / s.total, 1) if s.total else 0,
                      "date": s.finished_at.isoformat()} for s in sessions],
        "by_difficulty": [{"difficulty": d, "attempts": n, "accuracy": round(100 * (c or 0) / n, 1)}
                          for d, n, c in sorted(by_diff)],
        "trend": features.daily_accuracy(db, user.id, 21),
    }
