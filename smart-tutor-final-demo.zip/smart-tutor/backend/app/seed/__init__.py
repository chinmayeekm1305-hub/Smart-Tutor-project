"""Seed the database with course content, demo accounts and realistic learning history.

Run:  python -m app.seed            (keeps existing data if already seeded)
      python -m app.seed --reset    (drops everything and reseeds)
"""
from __future__ import annotations

import argparse
import math
import random
from datetime import datetime, timedelta

from sqlalchemy import select

from ..auth import hash_password
from ..database import Base, SessionLocal, engine
from ..models import (Attempt, Question, QuizSession, StudyLog, Subject, TeacherFeedback, Topic, User)
from ..services import adaptive
from . import aptitude_content, dbms_content, python_content

CONTENT = [python_content, dbms_content, aptitude_content]

DEMO_STUDENT = ("Ananya Rao", "student@smarttutor.edu", "student123")
DEMO_TEACHER = ("Prof. Ramesh Kumar", "teacher@smarttutor.edu", "teacher123")

CLASSMATES = ["Rahul Gowda", "Priya Shetty", "Karthik Reddy", "Sneha Patil", "Arjun Nair", "Divya Hegde",
              "Manoj Kumar", "Pooja Iyer", "Vikram Joshi", "Kavya Murthy", "Rohan Das", "Meghana Rao",
              "Suresh Babu", "Lakshmi Prasad", "Aditya Shenoy", "Nisha Kulkarni", "Harsha Vardhan",
              "Bhavana Naik", "Chetan Raj", "Deepika S", "Naveen Pai", "Shruthi M"]


def seed_content(db) -> list[Topic]:
    topics = []
    for mod in CONTENT:
        s = Subject(**mod.SUBJECT)
        db.add(s)
        db.flush()
        for i, t in enumerate(mod.TOPICS):
            tp = Topic(subject_id=s.id, name=t["name"], order=i, notes=t["notes"], simple_notes=t["simple_notes"],
                       advanced_notes=t["advanced_notes"], video_url=t.get("video_url", ""))
            db.add(tp)
            db.flush()
            for d, text, opts, correct, expl in t["questions"]:
                db.add(Question(topic_id=tp.id, text=text, options=opts, correct_index=correct,
                                explanation=expl, difficulty=d, source="seed", approved=True))
            topics.append(tp)
    db.flush()
    return topics


def simulate_student(db, user: User, topics: list[Topic], ability: dict[int, float], diligence: float,
                     rng: random.Random, days: int = 21):
    """Simulate quizzes with the real adaptive engine so mastery, XP and history are consistent."""
    start = datetime.now() - timedelta(days=days)
    n_quizzes = max(2, int(rng.gauss(4 + 12 * diligence, 2)))
    for qn in range(n_quizzes):
        t = rng.choice(topics)
        when = start + timedelta(days=days * (qn + rng.random()) / n_quizzes, hours=rng.randint(9, 20))
        if when > datetime.now():
            when = datetime.now() - timedelta(minutes=rng.randint(5, 600))
        if rng.random() < 0.3 + 0.6 * diligence:
            db.add(StudyLog(student_id=user.id, topic_id=t.id, seconds=rng.randint(120, 900),
                            created_at=when - timedelta(minutes=15)))
        sess = QuizSession(student_id=user.id, topic_id=t.id, total=8, started_at=when)
        db.add(sess)
        db.flush()
        hist, seen = [], set()
        growth = 0.04 * qn * diligence  # practice helps
        for k in range(8):
            m = adaptive.get_mastery(db, user.id, t.id)
            diff = adaptive.target_difficulty(m.p_known, hist)
            q = adaptive.pick_next_question(db, user.id, t.id, diff, seen)
            if not q:
                break
            seen.add(q.id)
            a = ability.get(t.subject_id, 0.5) + growth
            p = 1 / (1 + math.exp(-5 * (a - 0.28 * q.difficulty)))  # logistic item-response curve
            ok = rng.random() < p
            choice = q.correct_index if ok else rng.choice([i for i in range(4) if i != q.correct_index])
            ts = when + timedelta(seconds=40 * k)
            db.add(Attempt(session_id=sess.id, student_id=user.id, question_id=q.id, topic_id=t.id,
                           selected_index=choice, is_correct=ok, difficulty=q.difficulty,
                           time_taken_sec=max(5, rng.gauss(45 - 25 * a + 6 * q.difficulty, 8)), created_at=ts))
            adaptive.record_answer(db, user.id, q, ok)
            user.xp += adaptive.xp_for(ok, q.difficulty)
            sess.score += int(ok)
            hist.append(ok)
            db.flush()
        sess.total = len(hist)
        sess.finished_at = when + timedelta(minutes=6)


def seed(reset: bool = False):
    if reset:
        Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    if db.scalar(select(Subject.id).limit(1)):
        print("Database already seeded. Use --reset to start over.")
        db.close()
        return
    rng = random.Random(2026)
    topics = seed_content(db)
    subj_ids = sorted({t.subject_id for t in topics})

    teacher = User(name=DEMO_TEACHER[0], email=DEMO_TEACHER[1], password_hash=hash_password(DEMO_TEACHER[2]),
                   role="teacher", academic_info="Dept. of AI & DS")
    db.add(teacher)

    from ..config import get_settings
    if not get_settings().seed_demo_students:
        db.commit()
        db.close()
        print(f"Seeded {len(topics)} topics (clean start, no demo students).")
        print(f"Teacher login: {DEMO_TEACHER[1]} / {DEMO_TEACHER[2]}  <- change this password after first login!")
        return

    pw = hash_password("student123")
    demo = User(name=DEMO_STUDENT[0], email=DEMO_STUDENT[1], password_hash=pw, role="student",
                academic_info="B.E. AI & DS, 5th Sem")
    db.add(demo)
    db.flush()
    # Demo student: strong in Python, weak in DBMS, average in aptitude, so every feature shows up
    simulate_student(db, demo, [t for t in topics if t.subject_id == subj_ids[0]],
                     {subj_ids[0]: 0.78}, 0.8, rng, 18)
    simulate_student(db, demo, [t for t in topics if t.subject_id == subj_ids[1]][1:3],
                     {subj_ids[1]: 0.22}, 0.4, rng, 14)
    simulate_student(db, demo, [t for t in topics if t.subject_id == subj_ids[2]][:3],
                     {subj_ids[2]: 0.55}, 0.6, rng, 10)

    students = [demo]
    for i, name in enumerate(CLASSMATES):
        email = name.lower().replace(" ", ".").replace("..", ".") + "@smarttutor.edu"
        u = User(name=name, email=email, password_hash=pw, role="student", academic_info="B.E. AI & DS, 5th Sem")
        db.add(u)
        db.flush()
        base = rng.betavariate(2.0, 2.0)
        ability = {sid: min(0.95, max(0.1, base + rng.gauss(0, 0.12))) for sid in subj_ids}
        diligence = rng.betavariate(2, 2)
        simulate_student(db, u, rng.sample(topics, k=rng.randint(4, 10)), ability, diligence, rng)
        students.append(u)

    # Natural-Intelligence touches: teacher guidance, and student doubts
    norm = next(t for t in topics if t.name == "Normalization")
    db.add_all([
        TeacherFeedback(teacher_id=teacher.id, student_id=demo.id, topic_id=norm.id,
                        message="Ananya, I noticed Normalization is tricky for you. Read the simplified notes first, "
                                "then try identifying partial vs transitive dependencies on the 'Enrollment' example. "
                                "Come see me after Thursday's class if it still feels confusing.",
                        created_at=datetime.now() - timedelta(days=2)),
        TeacherFeedback(teacher_id=teacher.id, student_id=demo.id, from_student=True, topic_id=norm.id,
                        message="Sir, why is a table with key (A,B) and C→B in 3NF but not BCNF?",
                        is_read=True, created_at=datetime.now() - timedelta(days=3)),
        TeacherFeedback(teacher_id=teacher.id, student_id=students[3].id, from_student=True,
                        message="Ma'am/Sir, can you share more practice problems on Time & Work with pipes?",
                        created_at=datetime.now() - timedelta(hours=5)),
        TeacherFeedback(teacher_id=teacher.id, student_id=students[7].id, from_student=True,
                        message="I keep getting confused between LEFT JOIN and RIGHT JOIN. Could you explain in class?",
                        created_at=datetime.now() - timedelta(hours=20)),
    ])
    # One AI-drafted question awaiting teacher approval
    sql = next(t for t in topics if t.name == "SQL Queries")
    db.add(Question(topic_id=sql.id, text="Which clause removes duplicate rows from a SELECT result?",
                    options=["UNIQUE", "DISTINCT", "GROUP", "FILTER"], correct_index=1,
                    explanation="SELECT DISTINCT returns only unique rows.", difficulty=1, source="ai",
                    approved=False, created_by=teacher.id))
    db.commit()
    n_q = db.query(Question).count()
    n_a = db.query(Attempt).count()
    db.close()
    print(f"Seeded {len(topics)} topics, {n_q} questions, {len(students)} students, {n_a} attempts.")
    print(f"Student login: {DEMO_STUDENT[1]} / {DEMO_STUDENT[2]}")
    print(f"Teacher login: {DEMO_TEACHER[1]} / {DEMO_TEACHER[2]}")


