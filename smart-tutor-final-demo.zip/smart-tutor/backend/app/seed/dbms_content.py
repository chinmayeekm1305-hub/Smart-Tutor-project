"""DBMS: notes (3 levels) and MCQs."""

SUBJECT = {"name": "DBMS", "icon": "🗄️",
           "description": "Database Management Systems: ER modelling, SQL, normalization and transactions."}

TOPICS = [
    {
        "name": "ER Model & Keys",
        "video_url": "https://www.youtube.com/results?search_query=er+model+keys+dbms",
        "notes": """# ER Model & Keys

The **Entity-Relationship (ER) model** is a blueprint of a database, drawn before building tables.

- An **entity** is a real-world object (Student, Course). An **entity set** is a collection of similar entities.
- An **attribute** is a property (name, roll_no). Kinds: simple vs **composite** (address → street, city), single vs **multivalued** (phone numbers), and **derived** (age from DOB).
- A **relationship** links entities (Student *enrolls in* Course).
- **Cardinality**: one-to-one, one-to-many, many-to-many.
- A **weak entity** cannot be identified by its own attributes and depends on an owner entity (Dependent of Employee).

## Keys
- **Super key**: any set of attributes that uniquely identifies a row.
- **Candidate key**: a *minimal* super key.
- **Primary key**: the candidate key chosen to identify rows. It cannot be NULL.
- **Alternate key**: candidate keys not chosen as primary.
- **Foreign key**: an attribute that refers to the primary key of another table and enforces **referential integrity**.
- **Composite key**: a key made of two or more attributes.""",
        "simple_notes": """# ER Model & Keys: the simple version

Imagine planning a college database on paper first. That plan is the **ER diagram**.

- **Entity** = a thing: *Student*, *Course* (drawn as a rectangle)
- **Attribute** = a detail about the thing: *name*, *roll_no* (drawn as an oval)
- **Relationship** = how things connect: *Student ENROLLS in Course* (drawn as a diamond)

**Keys are like ID cards:**
- **Primary key** = the official ID (roll_no). It must be unique and never empty.
- **Foreign key** = an ID borrowed from another table. In an *Enrollment* table, `roll_no` points back to *Student*.
- **Candidate key** = any column that *could* have been the ID (roll_no, email, Aadhaar no.).""",
        "advanced_notes": """## Going deeper
- Mapping M:N to tables: create a junction table whose primary key is the composite of both foreign keys.
- Participation: total (double line) vs partial. Total participation of the many-side lets you merge the relationship into that table.
- Every candidate key is a super key, but not vice versa. A relation with n attributes can have at most 2^n - 1 super keys.
- Foreign keys may be NULL (optional relationship) unless declared NOT NULL; ON DELETE CASCADE / SET NULL defines the integrity action.""",
        "questions": [
            (1, "In an ER diagram, an entity is represented by a…", ["Diamond", "Rectangle", "Ellipse", "Line"], 1, "Entities are rectangles, attributes ovals, relationships diamonds."),
            (1, "Which key uniquely identifies each row and cannot be NULL?", ["Foreign key", "Primary key", "Alternate key", "Composite attribute"], 1, "A primary key must be unique and NOT NULL."),
            (1, "A key in one table that refers to the primary key of another table is a…", ["Super key", "Candidate key", "Foreign key", "Partial key"], 2, "Foreign keys link tables and enforce referential integrity."),
            (1, "'Age' calculated from 'Date of Birth' is an example of a…", ["Multivalued attribute", "Derived attribute", "Key attribute", "Composite attribute"], 1, "Derived attributes are computed from other attributes."),
            (2, "A minimal super key is called a…", ["Primary key", "Candidate key", "Foreign key", "Composite key"], 1, "Candidate keys are super keys with no redundant attributes."),
            (2, "An entity that cannot be uniquely identified by its own attributes is a…", ["Strong entity", "Weak entity", "Associative entity", "Derived entity"], 1, "Weak entities depend on an owner entity's key."),
            (2, "'Phone numbers' of a student (a student can have several) is a…", ["Composite attribute", "Multivalued attribute", "Derived attribute", "Simple attribute"], 1, "A multivalued attribute can hold multiple values for one entity."),
            (3, "To map a many-to-many relationship Student–Course into tables you should…", ["Add course_id to Student", "Add roll_no to Course", "Create a separate table with both keys", "Merge both tables"], 2, "M:N needs a junction table whose key is the combination of both foreign keys."),
            (3, "A relation R(A, B, C) has candidate key A. How many super keys does it have?", ["1", "3", "4", "7"], 2, "Any superset of {A}: A, AB, AC, ABC = 4."),
            (3, "Which statement is TRUE?", ["Every super key is a candidate key", "Every candidate key is a super key", "A foreign key can never be NULL", "A table can have only one candidate key"], 1, "Candidate keys are minimal super keys, so each is also a super key."),
        ],
    },
    {
        "name": "SQL Queries",
        "video_url": "https://www.youtube.com/results?search_query=sql+queries+tutorial",
        "notes": """# SQL Queries

**SQL (Structured Query Language)** talks to relational databases.

## Command groups
- **DDL** (structure): CREATE, ALTER, DROP, TRUNCATE
- **DML** (data): INSERT, UPDATE, DELETE, SELECT
- **DCL** (permissions): GRANT, REVOKE
- **TCL** (transactions): COMMIT, ROLLBACK, SAVEPOINT

## SELECT anatomy
```sql
SELECT dept, AVG(salary) AS avg_sal
FROM employees
WHERE joined >= '2020-01-01'
GROUP BY dept
HAVING AVG(salary) > 50000
ORDER BY avg_sal DESC;
```
- **WHERE** filters rows *before* grouping; **HAVING** filters groups *after* **GROUP BY**.
- **Aggregate functions**: COUNT, SUM, AVG, MIN, MAX. `COUNT(*)` counts rows; `COUNT(col)` ignores NULLs.
- **DISTINCT** removes duplicates. **LIKE** matches patterns: `'A%'` starts with A, `'_a%'` second letter a.
- Test for NULL with **IS NULL**, never `= NULL`.

## Joins
- **INNER JOIN**: only matching rows from both tables.
- **LEFT JOIN**: all rows from the left table plus matches (NULL when there's no match).
- **RIGHT / FULL OUTER JOIN**, **CROSS JOIN** (every combination).""",
        "simple_notes": """# SQL: the simple version

SQL is how you *ask* a database questions, almost in plain English.

```sql
SELECT name, marks      -- which columns?
FROM students           -- which table?
WHERE marks > 60        -- which rows?
ORDER BY marks DESC;    -- in what order?
```

**Counting & totals:** `COUNT(*)`, `SUM(marks)`, `AVG(marks)`, `MAX(marks)`

**GROUP BY** makes buckets: "average marks *per department*":
```sql
SELECT dept, AVG(marks) FROM students GROUP BY dept;
```

**WHERE vs HAVING:** WHERE filters *students* (rows); HAVING filters *departments* (groups).

**JOIN** glues two tables together using a common column, like matching roll numbers on two lists.""",
        "advanced_notes": """## Going deeper
- Logical order of execution: FROM → JOIN → WHERE → GROUP BY → HAVING → SELECT → DISTINCT → ORDER BY → LIMIT. This is why a SELECT alias can't be used in WHERE.
- `NOT IN` with a subquery that returns a NULL yields no rows. Prefer `NOT EXISTS`.
- DELETE is DML (row-by-row, can be rolled back, fires triggers); TRUNCATE is DDL (fast, resets storage).
- Window functions: `RANK() OVER (PARTITION BY dept ORDER BY salary DESC)` ranks without collapsing rows.
- Nth highest salary: `SELECT DISTINCT salary FROM emp ORDER BY salary DESC LIMIT 1 OFFSET n-1;`""",
        "questions": [
            (1, "Which SQL command retrieves data from a table?", ["GET", "SELECT", "FETCH", "SHOW"], 1, "SELECT is the DML query command."),
            (1, "Which clause filters rows in a SELECT?", ["ORDER BY", "WHERE", "GROUP BY", "FROM"], 1, "WHERE filters individual rows."),
            (1, "Which of these is a DDL command?", ["INSERT", "UPDATE", "CREATE", "SELECT"], 2, "CREATE, ALTER, DROP and TRUNCATE define structure (DDL)."),
            (1, "Which pattern matches names starting with 'S'?", ["LIKE '%S'", "LIKE 'S%'", "LIKE '_S'", "= 'S*'"], 1, "% matches any sequence of characters, so 'S%' means starts with S."),
            (2, "To filter groups after GROUP BY you use…", ["WHERE", "HAVING", "ORDER BY", "DISTINCT"], 1, "HAVING filters aggregated groups."),
            (2, "How do you correctly find rows where email is missing?", ["WHERE email = NULL", "WHERE email IS NULL", "WHERE email == ''", "WHERE NULL(email)"], 1, "NULL is unknown, so comparisons with = return unknown; use IS NULL."),
            (2, "A LEFT JOIN returns…", ["Only matching rows", "All rows from the left table plus matches from the right", "All rows from both tables", "Every combination of rows"], 1, "Unmatched left rows appear with NULLs for right-side columns."),
            (3, "Table T has 5 rows; column c has 2 NULLs. What do COUNT(*) and COUNT(c) return?", ["5 and 5", "5 and 3", "3 and 3", "3 and 5"], 1, "COUNT(*) counts rows; COUNT(c) skips NULLs."),
            (3, "Why does `SELECT salary*12 AS annual FROM emp WHERE annual > 600000` fail in most DBs?", ["Aliases need quotes", "WHERE is evaluated before SELECT, so the alias doesn't exist yet", "You can't multiply in SELECT", "annual is a reserved word"], 1, "Logical order: FROM → WHERE → … → SELECT. Repeat the expression or use a subquery."),
            (3, "Tables A (3 rows) and B (4 rows). How many rows does `A CROSS JOIN B` return?", ["7", "12", "4", "3"], 1, "A cross join is the Cartesian product: 3 × 4 = 12."),
        ],
    },
    {
        "name": "Normalization",
        "video_url": "https://www.youtube.com/results?search_query=normalization+1nf+2nf+3nf+bcnf",
        "notes": """# Normalization

**Normalization** organises tables to reduce **redundancy** and avoid **anomalies**: insertion, update and deletion anomalies.

A **functional dependency (FD)** X → Y means the value of X determines Y (roll_no → name).

## Normal forms
- **1NF**: every column holds **atomic** (indivisible) values; no repeating groups.
- **2NF**: 1NF + no **partial dependency**. A non-key attribute must depend on the *whole* composite key, not part of it.
- **3NF**: 2NF + no **transitive dependency** (non-key → non-key). E.g. roll_no → dept_id → dept_name violates 3NF.
- **BCNF**: for every FD X → Y, X must be a **super key**. BCNF is stricter than 3NF.

## Example
Enrollment(roll_no, course_id, student_name, grade) with key (roll_no, course_id):
`roll_no → student_name` is a partial dependency, so it's not in 2NF. Decompose into Student(roll_no, student_name) and Enrollment(roll_no, course_id, grade).

Decomposition should be **lossless** (no information lost on join) and ideally **dependency preserving**.""",
        "simple_notes": """# Normalization: the simple version

Normalization means **don't store the same fact in many places**.

Imagine one big Excel sheet with a student's name repeated on every course row. If the name changes, you must fix it everywhere. Miss one and the data disagrees (an **update anomaly**).

**The fix:** split into smaller tables that each talk about *one thing*.

- **1NF**: one value per cell (no "Maths, Physics" in one cell)
- **2NF**: every column depends on the **whole** key
- **3NF**: columns depend **only on the key**, not on another column

A memory hook: *"The key, the whole key, and nothing but the key."*""",
        "advanced_notes": """## Going deeper
- Closure X+ finds what X determines. X is a super key if X+ contains all attributes.
- 3NF allows X → A when A is a *prime attribute*; BCNF does not. A 3NF decomposition that is lossless and dependency-preserving always exists; for BCNF dependency preservation isn't guaranteed.
- Lossless join test for a binary decomposition: R1 ∩ R2 must be a key of R1 or of R2.
- 4NF removes multivalued dependencies. Denormalisation is a deliberate trade-off for read-heavy analytics.""",
        "questions": [
            (1, "The main goal of normalization is to…", ["Increase redundancy", "Reduce redundancy and anomalies", "Speed up all queries", "Encrypt data"], 1, "Normalization removes redundant data to avoid anomalies."),
            (1, "A table in 1NF must have…", ["No transitive dependency", "Atomic values in every column", "A composite key", "No foreign keys"], 1, "1NF requires atomic (indivisible) values."),
            (1, "Having to change the same data in many rows is called an…", ["Insertion anomaly", "Update anomaly", "Deletion anomaly", "Join anomaly"], 1, "Redundant copies must all be updated, which is an update anomaly."),
            (2, "A partial dependency violates which normal form?", ["1NF", "2NF", "3NF", "BCNF only"], 1, "2NF forbids non-key attributes depending on part of a composite key."),
            (2, "roll_no → dept_id and dept_id → dept_name. Storing all three in one table violates…", ["1NF", "2NF", "3NF", "None"], 2, "dept_name depends transitively on the key through dept_id."),
            (2, "In BCNF, for every non-trivial FD X → Y, X must be a…", ["Foreign key", "Super key", "Prime attribute", "Non-key attribute"], 1, "That's the definition of BCNF."),
            (3, "R(A,B,C) with FDs A→B, B→C. What is the closure A+?", ["{A}", "{A,B}", "{A,B,C}", "{B,C}"], 2, "A→B, then B→C, so A determines A, B and C."),
            (3, "R(A,B,C), key AB, FD C → B. R is in…", ["3NF but not BCNF", "BCNF", "2NF but not 3NF", "Not even 1NF"], 0, "C isn't a super key, so BCNF fails; B is prime, so 3NF holds."),
            (3, "Decomposing R into R1 and R2 is lossless if…", ["R1 ∪ R2 = R only", "R1 ∩ R2 is a key of R1 or R2", "R1 and R2 have no common attribute", "Both are in 1NF"], 1, "The common attributes must functionally determine one side."),
            (3, "Which decomposition is always achievable while being lossless AND dependency preserving?", ["BCNF", "3NF", "4NF", "5NF"], 1, "3NF synthesis guarantees both; BCNF may lose dependencies."),
        ],
    },
    {
        "name": "Transactions & ACID",
        "video_url": "https://www.youtube.com/results?search_query=dbms+transactions+acid+properties",
        "notes": """# Transactions & ACID

A **transaction** is a sequence of operations treated as one logical unit, e.g. transferring ₹500 from account A to B (debit A, credit B).

## ACID properties
- **Atomicity**: all or nothing. If any step fails, the whole transaction is **rolled back**.
- **Consistency**: a transaction takes the database from one valid state to another, so constraints hold.
- **Isolation**: concurrent transactions don't interfere; the result is as if they ran one by one.
- **Durability**: once **committed**, changes survive crashes (via logs).

## Commands
**COMMIT** saves changes, **ROLLBACK** undoes them, **SAVEPOINT** marks a partial rollback point.

## Concurrency problems
- **Dirty read**: reading uncommitted data of another transaction.
- **Non-repeatable read**: same row read twice gives different values.
- **Phantom read**: a re-run query returns new rows.
- **Lost update**: two transactions overwrite each other.

**Locks** (shared for read, exclusive for write) and the **Two-Phase Locking (2PL)** protocol ensure **serializability**. **Deadlock** happens when transactions wait on each other forever.""",
        "simple_notes": """# Transactions: the simple version

Think of a **UPI transfer**: money leaves your account AND reaches your friend's. It must be **both or neither**. That package of steps is a **transaction**.

**ACID**, the four promises:
- **A**tomicity: all steps or none (no half-done transfers)
- **C**onsistency: rules are never broken (total money stays correct)
- **I**solation: two people paying at the same time don't mix each other up
- **D**urability: once it says "Success", it's saved even if the server crashes

**COMMIT** = "save it for good". **ROLLBACK** = "undo everything since the start".""",
        "advanced_notes": """## Going deeper
- Isolation levels: READ UNCOMMITTED (dirty reads allowed) → READ COMMITTED → REPEATABLE READ → SERIALIZABLE (prevents phantoms).
- Conflict serializability: build a precedence graph; acyclic means conflict-serializable.
- Strict 2PL holds exclusive locks until commit, which avoids cascading rollbacks.
- Deadlock handling: wait-die / wound-wait (timestamps), timeouts, or detection via a wait-for graph.
- Durability is implemented with write-ahead logging (WAL) and checkpoints; recovery redoes committed work and undoes uncommitted work.""",
        "questions": [
            (1, "'All or nothing' describes which ACID property?", ["Consistency", "Atomicity", "Isolation", "Durability"], 1, "Atomicity: either every operation happens or none."),
            (1, "Which command permanently saves a transaction's changes?", ["SAVE", "COMMIT", "ROLLBACK", "END"], 1, "COMMIT makes changes permanent."),
            (1, "Committed data surviving a power failure is guaranteed by…", ["Atomicity", "Isolation", "Durability", "Consistency"], 2, "Durability ensures committed changes persist."),
            (2, "Reading data written by a transaction that hasn't committed yet is a…", ["Phantom read", "Dirty read", "Lost update", "Deadlock"], 1, "Dirty reads see uncommitted (possibly rolled back) data."),
            (2, "Which property ensures concurrent transactions behave as if executed one after another?", ["Atomicity", "Isolation", "Durability", "Redundancy"], 1, "Isolation hides concurrent effects."),
            (2, "Two transactions each holding a lock the other needs, waiting forever, is a…", ["Starvation", "Deadlock", "Livelock", "Rollback"], 1, "A circular wait is a deadlock."),
            (3, "Which isolation level prevents phantom reads?", ["READ UNCOMMITTED", "READ COMMITTED", "REPEATABLE READ (per SQL standard)", "SERIALIZABLE"], 3, "Per the SQL standard, only SERIALIZABLE prevents phantoms."),
            (3, "A schedule is conflict-serializable if its precedence graph is…", ["Complete", "Acyclic", "Cyclic", "Disconnected"], 1, "No cycles means an equivalent serial order exists."),
            (3, "In Two-Phase Locking, the 'shrinking phase' means a transaction…", ["Can acquire but not release locks", "Can release but not acquire locks", "Holds no locks", "Must abort"], 1, "After the first release, no new locks may be acquired."),
            (3, "Strict 2PL avoids cascading rollbacks because…", ["It uses no locks", "Exclusive locks are held until commit/abort", "It allows dirty reads", "It aborts every conflicting transaction"], 1, "Others can't read uncommitted writes, so one abort can't cascade."),
        ],
    },
]
