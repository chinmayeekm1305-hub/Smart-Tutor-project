from . import seed
import argparse
ap = argparse.ArgumentParser(); ap.add_argument("--reset", action="store_true")
seed(ap.parse_args().reset)
