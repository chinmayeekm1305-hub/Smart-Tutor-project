"""Quantitative Aptitude: notes (3 levels) and MCQs. All answers hand-verified."""

SUBJECT = {"name": "Quantitative Aptitude", "icon": "🧮",
           "description": "Placement-ready aptitude: percentages, profit & loss, time & work, interest."}

TOPICS = [
    {
        "name": "Percentages",
        "video_url": "https://www.youtube.com/results?search_query=percentages+aptitude+tricks",
        "notes": """# Percentages

**Percent** means "per hundred": x% = x/100.

## Core formulas
- **x% of N** = N × x / 100
- **Percentage change** = (New − Old) / Old × 100
- Increase by r%: multiply by **(1 + r/100)**; decrease by r%: multiply by (1 − r/100)
- **Successive change** of a% and b%: net = a + b + ab/100 (use negative for decrease)

## Useful fraction equivalents
1/2 = 50%, 1/4 = 25%, 1/5 = 20%, 1/8 = 12.5%, 1/3 = 33.33%, 1/6 = 16.67%

## Classic results
- If A is r% more than B, then B is **r/(100+r) × 100**% less than A.
- If price rises r%, consumption must fall by r/(100+r) × 100% to keep **expenditure** unchanged.
- **Population growth** at r% per year for n years: P × (1 + r/100)^n

**Example:** +20% then −20% → 20 − 20 − 400/100 = **−4%** (a net decrease).""",
        "simple_notes": """# Percentages: the simple version

**%** just means "out of 100". 30% = 30 out of 100.

**Finding a percentage of a number:** 20% of 450 → 450 × 20 / 100 = **90**
Shortcut: 10% of 450 = 45, so 20% = 90.

**Percentage increase:** price went from ₹80 to ₹100.
Increase = 20. Divide by the **old** value: 20/80 = 0.25 → **25%**

**Watch out!** +20% and then −20% does NOT bring you back.
₹100 → ₹120 → ₹96. You lost 4%!""",
        "advanced_notes": """## Going deeper
- Use multiplying factors for speed: +12.5% = ×9/8, −16.67% = ×5/6.
- Inclusion–exclusion for pass/fail problems: passed both = 100 − (failA + failB − failBoth).
- Equivalent of successive discounts d1, d2: 1 − (1−d1)(1−d2).
- Election and mixture problems: set the total = 100 and work with differences.""",
        "questions": [
            (1, "What is 20% of 450?", ["45", "90", "80", "900"], 1, "450 × 20/100 = 90."),
            (1, "25 out of 200 as a percentage is…", ["25%", "12.5%", "8%", "20%"], 1, "25/200 × 100 = 12.5%."),
            (1, "A price rises from ₹80 to ₹100. The percentage increase is…", ["20%", "25%", "80%", "12.5%"], 1, "Increase 20 ÷ old value 80 = 25%."),
            (1, "What is 50% of 50% of 200?", ["100", "50", "25", "150"], 1, "50% of 200 = 100; 50% of 100 = 50."),
            (2, "A number is increased by 20% and then decreased by 20%. The net change is…", ["0%", "4% decrease", "4% increase", "2% decrease"], 1, "20 − 20 + (20 × −20)/100 = −4%."),
            (2, "A's salary is 25% more than B's. By what percent is B's salary less than A's?", ["25%", "20%", "33.33%", "15%"], 1, "25/125 × 100 = 20%."),
            (2, "A town of 10,000 grows 10% per year. Population after 2 years?", ["12,000", "12,100", "11,000", "12,210"], 1, "10000 × 1.1 × 1.1 = 12,100."),
            (3, "Sugar price rises 25%. By how much must consumption fall to keep expenditure the same?", ["25%", "20%", "15%", "30%"], 1, "25/(100+25) × 100 = 20%."),
            (3, "35% failed Maths, 25% failed English, 10% failed both. What % passed both?", ["40%", "50%", "60%", "45%"], 1, "Failed at least one = 35 + 25 − 10 = 50%, so 50% passed both."),
            (3, "Successive discounts of 20% and 10% equal a single discount of…", ["30%", "28%", "25%", "32%"], 1, "1 − 0.8 × 0.9 = 0.28 → 28%."),
        ],
    },
    {
        "name": "Profit & Loss",
        "video_url": "https://www.youtube.com/results?search_query=profit+and+loss+aptitude",
        "notes": """# Profit & Loss

- **Cost Price (CP)**: what you paid. **Selling Price (SP)**: what you sold for.
- **Profit** = SP − CP (when SP > CP); **Loss** = CP − SP.
- **Profit %** = Profit / CP × 100. Percentages are always on **CP** unless stated otherwise.
- SP = CP × (100 + Profit%)/100;  CP = SP × 100/(100 + Profit%)

## Marked price & discount
- **Marked Price (MP)** is the list price. **Discount** is always on MP.
- SP = MP × (100 − Discount%)/100

## Shortcuts
- Mark up m% and discount d% → net profit% = m − d − md/100
- Selling two items at the **same SP**, one at x% gain and one at x% loss → always a **loss of x²/100 %**
- CP of a articles = SP of b articles → profit% = (a − b)/b × 100
- **False weight**: gain% = (True − False)/False × 100""",
        "simple_notes": """# Profit & Loss: the simple version

You buy a pen for ₹40 (**CP**) and sell it for ₹50 (**SP**).
Profit = 50 − 40 = ₹10.
Profit % = 10 ÷ **40** × 100 = **25%**. Always divide by what you **paid**.

**Shop discounts:** a shirt marked ₹1000 with a 15% discount → you pay 1000 × 85/100 = ₹850.

**Finding CP backwards:** sold at ₹660 with 10% profit.
SP = 110% of CP → CP = 660 × 100/110 = **₹600**""",
        "advanced_notes": """## Going deeper
- Chain multiply: MP = CP × (1 + m) and SP = MP × (1 − d). Solve for whatever is unknown.
- Equal SP with x% gain and x% loss: the loss is x²/100 %, not zero, because the bases (CPs) differ.
- Dishonest dealers: combining a false weight and a markup multiplies the factors: (1 + markup) × True/False − 1.
- For GST-inclusive prices, back out the tax first: Base = Inclusive × 100/(100 + GST%).""",
        "questions": [
            (1, "CP = ₹400, SP = ₹500. Profit % is…", ["20%", "25%", "100%", "10%"], 1, "Profit 100 ÷ CP 400 = 25%."),
            (1, "An item costing ₹250 is sold at a 20% loss. SP = ?", ["₹200", "₹230", "₹300", "₹210"], 0, "250 × 80/100 = 200."),
            (1, "SP = ₹660 at 10% profit. CP = ?", ["₹594", "₹600", "₹650", "₹726"], 1, "660 × 100/110 = 600."),
            (2, "Marked price ₹1000 with a 15% discount. SP = ?", ["₹850", "₹150", "₹870", "₹985"], 0, "1000 × 0.85 = 850."),
            (2, "CP of 12 articles = SP of 10 articles. Profit % = ?", ["16.67%", "20%", "25%", "10%"], 1, "(12 − 10)/10 × 100 = 20%."),
            (2, "Selling at ₹450 gives a 10% loss. To gain 10%, sell at…", ["₹495", "₹550", "₹500", "₹540"], 1, "CP = 450/0.9 = 500; 500 × 1.1 = 550."),
            (2, "Two items sold at ₹990 each: 10% gain on one, 10% loss on the other. Overall result?", ["No profit, no loss", "1% loss", "1% gain", "2% loss"], 1, "Equal SP with ±x% always gives a loss of x²/100 = 1%."),
            (3, "Marked 40% above CP, then a 20% discount. Net profit % = ?", ["20%", "12%", "16%", "8%"], 1, "1.4 × 0.8 = 1.12 → 12%."),
            (3, "A dealer sells at cost price but uses a 900 g weight for 1 kg. Gain % = ?", ["10%", "11.11%", "9.09%", "12%"], 1, "(1000 − 900)/900 × 100 = 11.11%."),
            (3, "CP = ₹500. What MP gives a 26% profit after a 10% discount?", ["₹630", "₹700", "₹680", "₹720"], 1, "SP = 630; MP = 630/0.9 = 700."),
        ],
    },
    {
        "name": "Time & Work",
        "video_url": "https://www.youtube.com/results?search_query=time+and+work+aptitude",
        "notes": """# Time & Work

If A finishes a job in **n days**, A's **one-day work** = 1/n.

## Rules
- Working together: **add the rates**. A (a days) + B (b days) → together **ab/(a+b)** days.
- If A + B take t days and A alone takes a days, B alone = 1/(1/t − 1/a).
- **Efficiency** is inversely proportional to time: twice as efficient means half the time.
- **Man-days**: M1 × D1 = M2 × D2 (same work). With hours: M1·D1·H1 = M2·D2·H2.

## LCM method (fast)
Take total work = LCM of the days. A: 10 days, B: 15 days → work = 30 units; A = 3 units/day, B = 2 units/day → together 5 units/day → **6 days**.

## Pipes & cisterns
Filling pipes add (+), **leaking/emptying pipes subtract (−)**. Fill in 20 min, empty in 30 min → net 1/20 − 1/30 = 1/60 → 60 min.""",
        "simple_notes": """# Time & Work: the simple version

Think in **"how much per day"**.

Ravi paints a wall in **10 days**, so each day he paints **1/10** of it.
Meena takes **15 days**, so she paints **1/15** per day.

**Together:** 1/10 + 1/15 = 3/30 + 2/30 = 5/30 = **1/6** per day → **6 days**.

**LCM trick:** pretend the wall has 30 bricks (LCM of 10 and 15).
Ravi = 3 bricks/day, Meena = 2 bricks/day → 5 bricks/day → 30/5 = **6 days**.

**More people = fewer days:** 6 men × 12 days = 72 man-days, so 9 men need 72/9 = **8 days**.""",
        "advanced_notes": """## Going deeper
- Partial work: work done = rate × time. Track what's left after someone leaves or joins.
- Men and women: convert to a common unit through their rates (e.g. 10 men = 15 women → 2 men = 3 women).
- Alternate-day work: compute the 2-day cycle output, take full cycles, then finish the remainder.
- Wages are shared in the ratio of work done (rate × days), not in the ratio of days.""",
        "questions": [
            (1, "A finishes a job in 10 days. What fraction is done in 1 day?", ["1/5", "1/10", "10", "1/100"], 1, "One-day work = 1/10."),
            (1, "A takes 10 days and B takes 15 days. Together they take…", ["12.5 days", "6 days", "5 days", "25 days"], 1, "1/10 + 1/15 = 1/6 → 6 days."),
            (1, "6 men finish a job in 12 days. How long will 9 men take?", ["18 days", "8 days", "6 days", "9 days"], 1, "72 man-days ÷ 9 = 8 days."),
            (1, "A does a job in 8 days. What fraction is done in 2 days?", ["1/8", "1/4", "1/2", "2/3"], 1, "2 × 1/8 = 1/4."),
            (2, "A and B together take 12 days; A alone takes 20 days. B alone takes…", ["30 days", "8 days", "32 days", "24 days"], 0, "1/12 − 1/20 = 1/30."),
            (2, "Pipe A fills a tank in 20 min; pipe B empties it in 30 min. Both open, the tank fills in…", ["50 min", "60 min", "12 min", "10 min"], 1, "1/20 − 1/30 = 1/60."),
            (2, "A is twice as efficient as B; together they take 14 days. A alone takes…", ["21 days", "28 days", "42 days", "7 days"], 0, "Rates 2x + x = 1/14 → x = 1/42, A = 1/21."),
            (3, "A takes 12 days and B takes 18 days. A works 4 days and leaves. B finishes the rest in…", ["8 days", "12 days", "10 days", "14 days"], 1, "A does 4/12 = 1/3; the remaining 2/3 × 18 = 12 days."),
            (3, "A, B and C take 10, 12 and 15 days alone. Together they take…", ["5 days", "4 days", "3 days", "6 days"], 1, "1/10 + 1/12 + 1/15 = 15/60 = 1/4."),
            (3, "10 men or 15 women finish a job in 30 days. 5 men and 10 women will take…", ["180/7 days", "24 days", "30 days", "20 days"], 0, "Man = 1/300, woman = 1/450; 5/300 + 10/450 = 7/180 → 180/7 ≈ 25.7 days."),
        ],
    },
    {
        "name": "Simple & Compound Interest",
        "video_url": "https://www.youtube.com/results?search_query=simple+and+compound+interest+aptitude",
        "notes": """# Simple & Compound Interest

## Simple Interest (SI)
Interest is earned only on the **principal**.
- **SI = P × R × T / 100**;  Amount A = P + SI
- Money doubles under SI in **100/R years**.

## Compound Interest (CI)
Interest is earned on principal **plus accumulated interest**.
- **A = P (1 + R/100)^T**;  CI = A − P
- Half-yearly compounding: rate R/2, periods 2T. Quarterly: R/4 and 4T.
- **Effective annual rate** = (1 + R/(100n))^n − 1

## Shortcuts
- CI − SI for **2 years** = P (R/100)²
- If money doubles in t years under CI, it becomes 4× in 2t, **8× in 3t**.
- **Rule of 72**: doubling time ≈ 72 / R years at compound interest.
- Under SI, the amount grows by the **same SI every year**, so the difference of two amounts gives the yearly interest.""",
        "simple_notes": """# Interest: the simple version

**Simple Interest:** the bank pays you only on what you put in.
₹5000 at 8% for 3 years → 5000 × 8 × 3 / 100 = **₹1200**

**Compound Interest:** interest earns interest, like a snowball rolling downhill.
₹10,000 at 10%:
- Year 1: 10,000 + 1,000 = 11,000
- Year 2: 11,000 + **1,100** = 12,100 → CI = **₹2,100**

Notice year 2 paid ₹100 more: that's interest on interest!

**Doubling at SI:** 100 ÷ rate. At 10% → 10 years.""",
        "advanced_notes": """## Going deeper
- CI − SI for 3 years = P (R/100)² (3 + R/100).
- Instalment and EMI problems: the present values of the instalments sum to the loan amount.
- Depreciation is compound decay: V = P (1 − R/100)^T.
- When comparing an FD that compounds quarterly with a bond that pays annually, compare effective annual rates, not nominal ones.""",
        "questions": [
            (1, "SI on ₹5000 at 8% per annum for 3 years is…", ["₹1200", "₹400", "₹1500", "₹1000"], 0, "5000 × 8 × 3 / 100 = 1200."),
            (1, "The formula for Simple Interest is…", ["P(1+R/100)^T", "PRT/100", "P+R+T", "PR/100T"], 1, "SI = P × R × T / 100."),
            (1, "At 10% SI, money doubles in…", ["5 years", "10 years", "20 years", "7.2 years"], 1, "Doubling needs SI = P: 100/R = 10 years."),
            (2, "CI on ₹10,000 at 10% for 2 years, compounded annually, is…", ["₹2000", "₹2100", "₹2200", "₹1100"], 1, "10000 × 1.21 − 10000 = 2100."),
            (2, "The difference between CI and SI on ₹5000 at 10% for 2 years is…", ["₹50", "₹100", "₹25", "₹500"], 0, "P(R/100)² = 5000 × 0.01 = 50."),
            (2, "At SI a sum becomes ₹6000 in 2 years and ₹7000 in 4 years. The principal is…", ["₹5000", "₹5500", "₹4000", "₹4500"], 0, "2 years' SI = 1000, so P = 6000 − 1000 = 5000."),
            (3, "At CI a sum doubles in 5 years. It becomes 8 times in…", ["40 years", "15 years", "20 years", "10 years"], 1, "8 = 2³, so 3 × 5 = 15 years."),
            (3, "Interest on ₹8000 at 10% p.a. for 1 year, compounded half-yearly, is…", ["₹800", "₹820", "₹840", "₹810"], 1, "8000 × 1.05² = 8820 → ₹820."),
            (3, "The effective annual rate of 12% p.a. compounded quarterly is about…", ["12%", "12.55%", "13%", "12.36%"], 1, "(1.03)^4 − 1 ≈ 0.1255."),
            (3, "Using the Rule of 72, money at 9% compound interest roughly doubles in…", ["6 years", "8 years", "9 years", "11 years"], 1, "72 / 9 = 8 years."),
        ],
    },
]
