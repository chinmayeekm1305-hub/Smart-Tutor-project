"""Python Programming: notes (3 levels) and MCQs. Question tuple: (difficulty, text, options, correct, explanation)."""

SUBJECT = {"name": "Python Programming", "icon": "🐍",
           "description": "Core Python for AI & Data Science: types, control flow, functions and data structures."}

TOPICS = [
    {
        "name": "Data Types & Operators",
        "video_url": "https://www.youtube.com/results?search_query=python+data+types+operators",
        "notes": """# Data Types & Operators

Python is **dynamically typed**: a variable gets its type from the value assigned, and you never declare it.

## Built-in types
- **int**: whole numbers of unlimited size, e.g. `42`
- **float**: decimals, e.g. `3.14`. Floats are approximate: `0.1 + 0.2 != 0.3`
- **str**: text, e.g. `"hello"`. Strings are **immutable**.
- **bool**: `True` / `False`. `bool` is a subclass of `int`, so `True + True == 2`
- **NoneType**: `None` means "no value"

Use **type()** to check a value's type and **isinstance()** to test it.

## Operators
- Arithmetic: `+ - * /` and **floor division** `//`, **modulus** `%`, power `**`
- `/` always returns a float: `7 / 2 == 3.5`, while `7 // 2 == 3`
- Comparison: `== != < > <= >=`
- Logical: `and`, `or`, `not` (they short-circuit)
- Identity `is` checks whether two names point to the same object; `==` checks equal values.

## Type conversion
**Casting** functions: `int("5")`, `float("2.5")`, `str(10)`. `int(3.9)` truncates to `3`.

```python
x = 10        # int
y = x / 4     # 2.5 (float)
name = "Py"
print(name * 3)   # PyPyPy
```""",
        "simple_notes": """# Data Types: the simple version

Think of a variable as a **labelled box**. Python looks at what you put inside and decides the box type.

- `age = 20` → a whole number, an **int**
- `price = 99.5` → a number with a dot, a **float**
- `name = "Asha"` → text inside quotes, a **str**
- `passed = True` → yes/no, a **bool**

**Division has two forms:**
- `7 / 2` gives `3.5` (normal division, always a float)
- `7 // 2` gives `3` (drop the decimal part)
- `7 % 2` gives `1` (the remainder)

**Tip:** if you're unsure what's in the box, ask Python: `type(age)` prints `<class 'int'>`.

**Practice:** what does `10 // 3` print? (Answer: 3)""",
        "advanced_notes": """## Going deeper
- `is` vs `==`: CPython caches small ints (-5 to 256), so `a is b` may be True for small ints but False for large ones. Always use `==` for values and `is` only for `None`.
- Floating point: use `math.isclose(a, b)` or `decimal.Decimal` for money.
- Floor division rounds toward negative infinity: `-7 // 2 == -4` and `-7 % 2 == 1`.
- Truthiness: `0`, `0.0`, `""`, `[]`, `{}` and `None` are falsy.
- `and`/`or` return an operand, not a bool: `"" or "default"` returns `"default"`.""",
        "questions": [
            (1, "What is the output of `print(type(3.0))`?", ["<class 'int'>", "<class 'float'>", "<class 'str'>", "<class 'double'>"], 1, "Any number with a decimal point is a float in Python."),
            (1, "What does `7 // 2` evaluate to?", ["3.5", "3", "4", "1"], 1, "`//` is floor division; it drops the fractional part, giving 3."),
            (1, "Which of these is immutable?", ["list", "dict", "str", "set"], 2, "Strings cannot be changed in place; operations create new strings."),
            (1, "What is `10 % 3`?", ["3", "1", "0", "3.33"], 1, "`%` gives the remainder: 10 = 3×3 + 1."),
            (2, "What is the result of `True + True + False`?", ["TrueTrue", "2", "1", "Error"], 1, "bool is a subclass of int: True is 1 and False is 0, so the sum is 2."),
            (2, "What does `int('7') + float('2.5')` return?", ["9.5", "'72.5'", "9", "Error"], 0, "Both convert to numbers; int + float gives a float, 9.5."),
            (2, "What does `print('ab' * 2 + 'c')` print?", ["abc2", "ababc", "abcabc", "Error"], 1, "`*` repeats first ('abab'), then `+` concatenates 'c'."),
            (3, "What is the value of `-7 // 2`?", ["-3", "-4", "-3.5", "3"], 1, "Floor division rounds toward negative infinity, so -3.5 becomes -4."),
            (3, "What does `print(0.1 + 0.2 == 0.3)` output?", ["True", "False", "Error", "None"], 1, "Binary floating point can't represent 0.1 exactly; the sum is 0.30000000000000004."),
            (3, "What is returned by `'' or [] or 'py' or 0`?", ["True", "''", "'py'", "0"], 2, "`or` returns the first truthy operand; '' and [] are falsy, so it returns 'py'."),
        ],
    },
    {
        "name": "Control Flow & Loops",
        "video_url": "https://www.youtube.com/results?search_query=python+if+else+loops",
        "notes": """# Control Flow & Loops

## Decisions
**if / elif / else** chooses which block runs. Python uses **indentation** (4 spaces) to mark blocks.

```python
marks = 72
if marks >= 75:
    grade = "Distinction"
elif marks >= 60:
    grade = "First class"
else:
    grade = "Pass"
```

## Loops
- **for loop**: iterates over any iterable (list, string, range).
- **while loop**: repeats while a condition is True. Make sure the condition eventually becomes False.
- **range(start, stop, step)** produces numbers up to, but **not including**, stop. `range(5)` → 0,1,2,3,4

## Loop control
- **break** exits the loop immediately.
- **continue** skips to the next iteration.
- A loop's **else** block runs only if the loop finished without `break`.

```python
for n in range(2, 10):
    if n % 2 == 0:
        continue
    print(n)      # 3 5 7 9
```""",
        "simple_notes": """# Loops: the simple version

**if** works like a traffic signal: *if* green, go; *else*, stop.

A **for loop** is like reading the names on an attendance list one by one:
```python
for name in ["Ravi", "Meena", "Arun"]:
    print("Present:", name)
```

**range(5)** counts 0, 1, 2, 3, 4. It **stops before 5**. That's the most common mistake!

A **while loop** keeps going *while* something is true:
```python
count = 3
while count > 0:
    print(count)
    count = count - 1   # without this line it never stops!
```

- **break** = leave the loop now
- **continue** = skip this one, go to the next""",
        "advanced_notes": """## Going deeper
- `for ... else` / `while ... else`: the else runs when no `break` happened, which is useful for search loops.
- `enumerate(seq, start=1)` gives index and value; `zip(a, b)` walks two sequences in parallel and stops at the shorter.
- Modifying a list while iterating over it skips elements. Iterate over a copy (`for x in lst[:]`) or build a new list.
- Python has no do-while. The idiom is `while True: ... if cond: break`.
- The walrus operator: `while (line := f.readline()):`""",
        "questions": [
            (1, "How many times does `for i in range(5):` run?", ["4", "5", "6", "Infinite"], 1, "range(5) yields 0,1,2,3,4: five values."),
            (1, "Which keyword exits a loop immediately?", ["continue", "pass", "break", "exit"], 2, "`break` terminates the nearest enclosing loop."),
            (1, "What does Python use to define a code block?", ["Curly braces {}", "Indentation", "Semicolons", "BEGIN/END"], 1, "Python blocks are defined by consistent indentation."),
            (1, "What does `list(range(1, 4))` produce?", ["[1, 2, 3, 4]", "[1, 2, 3]", "[0, 1, 2, 3]", "[2, 3, 4]"], 1, "range stops before the stop value: 1, 2, 3."),
            (2, "Output of:\n```python\nfor i in range(5):\n    if i == 3:\n        continue\n    print(i, end=' ')\n```", ["0 1 2", "0 1 2 4", "0 1 2 3 4", "3"], 1, "`continue` skips only i=3; the loop continues to 4."),
            (2, "What is printed?\n```python\nx = 0\nwhile x < 10:\n    x += 3\nprint(x)\n```", ["9", "10", "12", "3"], 2, "x goes 3, 6, 9, 12. At 12 the condition fails, so 12 is printed."),
            (2, "What does `list(range(10, 0, -3))` give?", ["[10, 7, 4, 1]", "[10, 7, 4]", "[9, 6, 3]", "[]"], 0, "Start 10, step -3, stop before 0: 10, 7, 4, 1."),
            (3, "What is printed?\n```python\nfor n in range(3):\n    pass\nelse:\n    print('done')\n```", ["Nothing", "done", "0 1 2", "Error"], 1, "The for-else block runs because the loop ended without `break`."),
            (3, "What is printed?\n```python\nfor n in [4, 6, 9]:\n    if n % 3 == 0:\n        print(n); break\nelse:\n    print('none')\n```", ["6", "9", "none", "6 none"], 0, "6 is the first value divisible by 3; break stops the loop, so else is skipped."),
            (3, "What does `list(zip([1,2,3], 'ab'))` return?", ["[(1,'a'),(2,'b'),(3,None)]", "[(1,'a'),(2,'b')]", "Error", "[(1,2,3),('a','b')]"], 1, "zip stops at the shortest iterable."),
        ],
    },
    {
        "name": "Functions",
        "video_url": "https://www.youtube.com/results?search_query=python+functions+tutorial",
        "notes": """# Functions

A **function** is a reusable block of code defined with **def**. It may take **parameters** and send back a value with **return**. Without a return statement, a function returns **None**.

```python
def area(length, width=1):
    return length * width

area(5, 3)       # 15  (positional arguments)
area(width=2, length=4)   # 8 (keyword arguments)
area(5)          # 5  (default argument used)
```

## Arguments
- **Default arguments** give a parameter a fallback value.
- ***args** collects extra positional arguments into a tuple.
- ****kwargs** collects extra keyword arguments into a dict.

## Scope
Variables created inside a function are **local**. Python looks up names by the **LEGB rule**: Local, Enclosing, Global, Built-in. To assign to a global name inside a function, declare it **global**.

## Lambda
A **lambda** is a small anonymous function: `square = lambda x: x * x`. It is often used with `sorted`, `map` and `filter`.""",
        "simple_notes": """# Functions: the simple version

A function is like a **recipe card**. You write it once and use it whenever you want.

```python
def greet(name):          # name is the ingredient (parameter)
    return "Hello " + name  # return sends the dish back

print(greet("Charan"))     # Hello Charan
```

- **def** starts the recipe.
- **return** hands back the result. If you forget it, you get **None**.
- **Default value:** `def greet(name="friend")` means `greet()` still works.

**Common mistake:** `print` shows a value on screen, but `return` gives it back to your code. They're different!""",
        "advanced_notes": """## Going deeper
- **Mutable default trap:** `def add(x, lst=[])` shares ONE list across calls. Use `lst=None` and create the list inside.
- Closures capture variables, not values: lambdas made in a loop all see the final loop value unless you bind `i=i`.
- Functions are first-class objects, so they can be passed, returned and decorated (`@decorator`).
- Parameter order: `def f(a, b=2, *args, c, **kwargs)`. Names after `*args` are keyword-only.
- `nonlocal` rebinds a name in the enclosing (not global) scope.""",
        "questions": [
            (1, "Which keyword defines a function in Python?", ["func", "def", "function", "lambda"], 1, "Functions are defined with `def name(params):`."),
            (1, "What does a function return if it has no return statement?", ["0", "None", "False", "Error"], 1, "Python implicitly returns None."),
            (1, "What does `(lambda x: x * 2)(5)` return?", ["5", "10", "25", "Error"], 1, "The lambda doubles its argument: 5 × 2 = 10."),
            (2, "Given `def f(a, b=3): return a + b`, what is `f(2)`?", ["2", "5", "Error", "None"], 1, "b takes its default value 3, so 2 + 3 = 5."),
            (2, "Inside a function, `*args` collects extra positional arguments as a…", ["list", "dict", "tuple", "set"], 2, "*args is a tuple; **kwargs is a dict."),
            (2, "What is printed?\n```python\nx = 5\ndef g():\n    x = 10\ng()\nprint(x)\n```", ["10", "5", "None", "Error"], 1, "The x inside g is local; the global x stays 5."),
            (2, "What is `sorted(['bb', 'a', 'ccc'], key=len)`?", ["['a', 'bb', 'ccc']", "['ccc', 'bb', 'a']", "['a', 'ccc', 'bb']", "Error"], 0, "key=len sorts by string length."),
            (3, "What is printed?\n```python\ndef add(x, lst=[]):\n    lst.append(x)\n    return lst\nadd(1)\nprint(add(2))\n```", ["[2]", "[1, 2]", "[1]", "Error"], 1, "The default list is created once and shared across calls (the mutable default trap)."),
            (3, "What is `[f() for f in [lambda: i for i in range(3)]]`?", ["[0, 1, 2]", "[2, 2, 2]", "[3, 3, 3]", "Error"], 1, "Each lambda looks up i when called; by then i is 2 (late binding)."),
            (3, "In `def f(a, *args, b): ...`, how must b be passed?", ["Positionally", "As a keyword argument", "It can't be passed", "Inside args"], 1, "Parameters after *args are keyword-only."),
        ],
    },
    {
        "name": "Lists & Dictionaries",
        "video_url": "https://www.youtube.com/results?search_query=python+lists+dictionaries",
        "notes": """# Lists & Dictionaries

## Lists
A **list** is an ordered, **mutable** collection: `marks = [78, 85, 62]`.
- **Indexing** starts at 0; **negative indexing** `marks[-1]` gives the last item.
- **Slicing** `marks[0:2]` → `[78, 85]` (stop is excluded).
- Methods: **append()** adds one item, **extend()** adds many, `insert()`, `remove()`, **pop()** removes and returns.
- **List comprehension**: `[x*x for x in range(5) if x % 2 == 0]` → `[0, 4, 16]`

## Tuples & sets
A **tuple** is like a list but **immutable**: `(1, 2)`. A **set** holds unique items with no order: `{1, 2, 3}`.

## Dictionaries
A **dictionary** maps **keys** to values: `student = {"name": "Asha", "cgpa": 8.7}`.
- Keys must be **hashable** (str, int, tuple), and each key is unique.
- Access with `student["name"]` (KeyError if missing) or **get()** `student.get("age", 0)` (safe).
- Loop over pairs with `.items()`; `.keys()` and `.values()` give views.

```python
counts = {}
for ch in "banana":
    counts[ch] = counts.get(ch, 0) + 1
# {'b': 1, 'a': 3, 'n': 2}
```""",
        "simple_notes": """# Lists & Dictionaries: the simple version

A **list** is like a numbered queue at a bank counter, and **counting starts at 0**!
```python
fruits = ["apple", "mango", "banana"]
fruits[0]    # "apple"  (first)
fruits[-1]   # "banana" (last)
fruits.append("grape")   # add at the end
```

A **dictionary** is like a phone book: you look up a **name (key)** to get a **number (value)**.
```python
phone = {"Ravi": "98450...", "Meena": "99000..."}
phone["Ravi"]            # look up
phone.get("Arun", "Not found")   # safe look-up, no error
```

**Remember:** lists use positions `[0]`, dictionaries use keys `["Ravi"]`.""",
        "advanced_notes": """## Going deeper
- `b = a` copies the reference, not the list. Use `a.copy()` or `list(a)`; for nested lists use `copy.deepcopy`.
- `[[0]*3]*3` creates 3 references to the SAME inner list. Use `[[0]*3 for _ in range(3)]`.
- Dicts keep insertion order (Python 3.7+). Use `collections.Counter`, `defaultdict` and dict comprehensions `{k: v for ...}`.
- Complexity: list append O(1), list `in` O(n), dict/set lookup O(1) average.
- A list can't be a dict key (unhashable); a tuple of immutables can.""",
        "questions": [
            (1, "What is `[10, 20, 30][1]`?", ["10", "20", "30", "Error"], 1, "Indexing starts at 0, so index 1 is the second item, 20."),
            (1, "Which method adds a single item to the end of a list?", ["add()", "append()", "insert()", "extend()"], 1, "append(x) adds one element at the end."),
            (1, "How do you get the value for key 'a' from dict d, safely returning None if missing?", ["d['a']", "d.get('a')", "d.find('a')", "d.value('a')"], 1, "get() returns None (or a default) instead of raising KeyError."),
            (1, "What is `len({1, 2, 2, 3})`?", ["4", "3", "2", "Error"], 1, "Sets keep unique elements: {1, 2, 3}."),
            (2, "What is `[1, 2, 3, 4, 5][1:4]`?", ["[1, 2, 3, 4]", "[2, 3, 4]", "[2, 3, 4, 5]", "[1, 2, 3]"], 1, "Slice indices 1 up to (not including) 4: 2, 3, 4."),
            (2, "What is `[x * 2 for x in range(4) if x % 2]`?", ["[0, 4]", "[2, 6]", "[0, 2, 4, 6]", "[1, 3]"], 1, "x % 2 is truthy for odd x (1, 3); doubled gives [2, 6]."),
            (2, "Which of these CANNOT be a dictionary key?", ["'name'", "42", "(1, 2)", "[1, 2]"], 3, "Lists are mutable and unhashable, so they can't be keys."),
            (3, "What is printed?\n```python\na = [1, 2]\nb = a\nb.append(3)\nprint(a)\n```", ["[1, 2]", "[1, 2, 3]", "[3]", "Error"], 1, "b = a makes both names refer to the same list."),
            (3, "What is printed?\n```python\ng = [[0]*2]*2\ng[0][0] = 9\nprint(g)\n```", ["[[9, 0], [0, 0]]", "[[9, 0], [9, 0]]", "[[9, 9], [0, 0]]", "Error"], 1, "Both rows are the same inner list object, so the change shows twice."),
            (3, "What does `{k: v for k, v in zip('ab', [1, 2, 3])}` produce?", ["{'a': 1, 'b': 2}", "{'a': 1, 'b': 2, None: 3}", "Error", "{'ab': [1, 2, 3]}"], 0, "zip stops at the shorter sequence, giving pairs ('a',1) and ('b',2)."),
        ],
    },
]
