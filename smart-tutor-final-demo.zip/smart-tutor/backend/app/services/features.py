"""Turn a student's raw activity into the feature vector used by the ML models."""
from __future__ import annotations

from datetime import timedelta

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..models import Attempt, Mastery, StudyLog

FEATURES = [
    "accuracy",         # share of all answers that were correct
    "easy_accuracy",    # accuracy on difficulty-1 questions
    "hard_accuracy",    # accuracy on difficulty-3 questions
    "recent_accuracy",  # accuracy over the last 10 answers
    "trend",            # recent_accuracy - accuracy (improving > 0)
    "avg_time",         # mean seconds per question
    "n_attempts",       # total questions answered
    "study_minutes",    # minutes spent reading notes
    "mastery_avg",      # mean BKT P(known) across attempted topics
    "active_days",      # distinct days with activity
]


def _acc(rows):
    return sum(1 for r in rows if r.is_correct) / len(rows) if rows else 0.0


def student_features(db: Session, student_id: int) -> dict:
    atts = db.scalars(select(Attempt).where(Attempt.student_id == student_id).order_by(Attempt.created_at)).all()
    easy = [a for a in atts if a.difficulty == 1]
    hard = [a for a in atts if a.difficulty == 3]
    recent = atts[-10:]
    acc = _acc(atts)
    rec = _acc(recent)
    study_sec = db.scalar(select(func.coalesce(func.sum(StudyLog.seconds), 0)).where(StudyLog.student_id == student_id))
    m_avg = db.scalar(select(func.avg(Mastery.p_known)).where(Mastery.student_id == student_id, Mastery.attempts > 0))
    days = {a.created_at.date() for a in atts}
    return {
        "accuracy": round(acc, 4),
        "easy_accuracy": round(_acc(easy), 4) if easy else round(acc, 4),
        "hard_accuracy": round(_acc(hard), 4) if hard else round(acc * 0.6, 4),
        "recent_accuracy": round(rec, 4),
        "trend": round(rec - acc, 4),
        "avg_time": round(sum(a.time_taken_sec for a in atts) / len(atts), 2) if atts else 0.0,
        "n_attempts": len(atts),
        "study_minutes": round((study_sec or 0) / 60, 1),
        "mastery_avg": round(m_avg or 0.3, 4),
        "active_days": len(days),
    }


def daily_accuracy(db: Session, student_id: int, days: int = 14) -> list[dict]:
    atts = db.scalars(select(Attempt).where(Attempt.student_id == student_id)).all()
    if not atts:
        return []
    last = max(a.created_at for a in atts).date()
    out = []
    for i in range(days - 1, -1, -1):
        d = last - timedelta(days=i)
        day = [a for a in atts if a.created_at.date() == d]
        out.append({"date": d.isoformat(), "attempts": len(day),
                    "accuracy": round(_acc(day) * 100, 1) if day else None})
    return out
