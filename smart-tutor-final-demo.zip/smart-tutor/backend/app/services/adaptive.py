"""Adaptive learning engine.

1. Bayesian Knowledge Tracing (BKT) keeps, for every student and topic, the probability
   P(known) that the student has mastered the topic. It is updated after every answer.
   (Variant with a forgetting term: P(known) can decay, so mastery reflects recent performance.)
2. The next question's difficulty is chosen from P(known) and the student's recent streak.
3. Recommendations come from mastery, repeated mistakes and topics not yet started.
"""
from __future__ import annotations

import random
from collections import Counter

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..models import Attempt, Mastery, Question, Topic, now

# BKT parameters. Guess and slip depend on difficulty: hard questions are harder to guess
# and easier to slip on.
P_INIT = 0.30
P_LEARN = 0.03
P_FORGET = 0.05  # small forgetting term keeps mastery responsive to recent mistakes
GUESS = {1: 0.30, 2: 0.25, 3: 0.20}
SLIP = {1: 0.20, 2: 0.28, 3: 0.35}

BEGINNER_MAX = 0.45
ADVANCED_MIN = 0.75


def level_for(p: float) -> str:
    if p < BEGINNER_MAX:
        return "Beginner"
    if p < ADVANCED_MIN:
        return "Intermediate"
    return "Advanced"


def bkt_update(p_known: float, correct: bool, difficulty: int = 2) -> float:
    """One BKT step: Bayesian posterior given the answer, then the learning transition."""
    g, s = GUESS.get(difficulty, 0.22), SLIP.get(difficulty, 0.10)
    if correct:
        posterior = p_known * (1 - s) / (p_known * (1 - s) + (1 - p_known) * g)
    else:
        posterior = p_known * s / (p_known * s + (1 - p_known) * (1 - g))
    p_next = posterior * (1 - P_FORGET) + (1 - posterior) * P_LEARN
    return round(min(max(p_next, 0.02), 0.97), 4)


def get_mastery(db: Session, student_id: int, topic_id: int, create: bool = True) -> Mastery | None:
    m = db.scalar(select(Mastery).where(Mastery.student_id == student_id, Mastery.topic_id == topic_id))
    if m is None and create:
        m = Mastery(student_id=student_id, topic_id=topic_id, p_known=P_INIT, attempts=0, correct=0)
        db.add(m)
        db.flush()
    return m


def record_answer(db: Session, student_id: int, question: Question, correct: bool) -> Mastery:
    m = get_mastery(db, student_id, question.topic_id)
    m.p_known = bkt_update(m.p_known, correct, question.difficulty)
    m.attempts += 1
    m.correct += int(correct)
    m.updated_at = now()
    return m


def target_difficulty(p_known: float, session_history: list[bool]) -> int:
    """Pick 1/2/3 from mastery, then nudge by the in-quiz streak."""
    base = 1 if p_known < BEGINNER_MAX else (2 if p_known < ADVANCED_MIN else 3)
    if len(session_history) >= 2 and all(session_history[-2:]):
        base += 1          # two right in a row: step up
    elif session_history and not session_history[-1]:
        base -= 1          # just got one wrong: step down
    return max(1, min(3, base))


def pick_next_question(db: Session, student_id: int, topic_id: int, difficulty: int,
                       exclude_ids: set[int]) -> Question | None:
    """Choose an unseen-in-session question near the target difficulty.

    Prefers questions the student previously got wrong (spaced review) and then never-seen ones.
    """
    pool = db.scalars(select(Question).where(Question.topic_id == topic_id, Question.approved.is_(True))).all()
    pool = [q for q in pool if q.id not in exclude_ids]
    if not pool:
        return None
    history = db.execute(
        select(Attempt.question_id, Attempt.is_correct).where(Attempt.student_id == student_id,
                                                              Attempt.topic_id == topic_id)).all()
    wrong = {qid for qid, ok in history if not ok}
    right = {qid for qid, ok in history if ok}

    def score(q: Question) -> float:
        s = abs(q.difficulty - difficulty) * 10       # closeness to target matters most
        if q.id in wrong and q.id not in right:
            s -= 3                                    # revisit past mistakes
        elif q.id not in wrong and q.id not in right:
            s -= 2                                    # then fresh questions
        return s + random.random()

    return min(pool, key=score)


def topic_mistakes(db: Session, student_id: int, topic_id: int | None = None) -> list[tuple[int, int]]:
    """(question_id, wrong_count) for questions answered wrongly 2+ times."""
    q = select(Attempt.question_id).where(Attempt.student_id == student_id, Attempt.is_correct.is_(False))
    if topic_id:
        q = q.where(Attempt.topic_id == topic_id)
    counts = Counter(db.scalars(q).all())
    return [(qid, c) for qid, c in counts.most_common() if c >= 2]


def recommendations(db: Session, student_id: int) -> list[dict]:
    topics = db.scalars(select(Topic).order_by(Topic.subject_id, Topic.order)).all()
    mastery = {m.topic_id: m for m in db.scalars(select(Mastery).where(Mastery.student_id == student_id))}
    mistakes = Counter()
    for qid, c in topic_mistakes(db, student_id):
        q = db.get(Question, qid)
        if q:
            mistakes[q.topic_id] += c

    recs = []
    for t in topics:
        m = mastery.get(t.id)
        subj = t.subject.name
        if m is None or m.attempts == 0:
            recs.append(dict(topic_id=t.id, topic=t.name, subject=subj, kind="start", priority=3,
                             reason="You haven't started this topic yet.", action="Read the notes, then take the quiz"))
            continue
        if m.p_known < BEGINNER_MAX:
            recs.append(dict(topic_id=t.id, topic=t.name, subject=subj, kind="revise", priority=1,
                             reason=f"Mastery is only {round(m.p_known*100)}%. Simplified notes are ready for you.",
                             action="Read the simplified notes and practise easy questions"))
        elif mistakes.get(t.id):
            recs.append(dict(topic_id=t.id, topic=t.name, subject=subj, kind="mistakes", priority=2,
                             reason=f"You repeated mistakes {mistakes[t.id]} times here.",
                             action="Review your mistakes and ask the AI tutor"))
        elif m.p_known >= ADVANCED_MIN:
            recs.append(dict(topic_id=t.id, topic=t.name, subject=subj, kind="challenge", priority=4,
                             reason=f"Great work: {round(m.p_known*100)}% mastery.",
                             action="Try the advanced notes and hard questions"))
        else:
            recs.append(dict(topic_id=t.id, topic=t.name, subject=subj, kind="practice", priority=3,
                             reason=f"You're getting there ({round(m.p_known*100)}% mastery).",
                             action="Practise one more adaptive quiz"))
    recs.sort(key=lambda r: (r["priority"], r["subject"]))
    return recs


def notes_for_level(topic: Topic, p_known: float | None) -> tuple[str, str]:
    """Return (level, markdown) so content difficulty follows the learner."""
    if p_known is None:
        return "Intermediate", topic.notes
    lvl = level_for(p_known)
    if lvl == "Beginner" and topic.simple_notes:
        return lvl, topic.simple_notes
    if lvl == "Advanced" and topic.advanced_notes:
        return lvl, topic.notes + "\n\n---\n\n" + topic.advanced_notes
    return lvl, topic.notes


def xp_for(correct: bool, difficulty: int) -> int:
    return (5 * difficulty) if correct else 1


def subject_summary(db: Session, student_id: int) -> list[dict]:
    rows = db.execute(
        select(Topic.subject_id, func.avg(Mastery.p_known), func.sum(Mastery.attempts), func.sum(Mastery.correct))
        .join(Mastery, Mastery.topic_id == Topic.id)
        .where(Mastery.student_id == student_id).group_by(Topic.subject_id)).all()
    return [dict(subject_id=r[0], mastery=round(r[1] or 0, 3), attempts=int(r[2] or 0), correct=int(r[3] or 0))
            for r in rows]
