"""LLM layer: OpenAI or Anthropic (Claude), with an offline NLP fallback.

The fallback means the demo never breaks if there is no key or no internet:
- Tutor chat uses TF-IDF retrieval over the topic notes to answer from course material.
- Quiz generation builds cloze (fill-in-the-blank) MCQs from **key terms** in the notes.
"""
from __future__ import annotations

import json
import logging
import random
import re

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from ..config import get_settings

log = logging.getLogger("llm")


def provider() -> str:
    s = get_settings()
    p = s.llm_provider.lower()
    if p == "auto":
        if s.anthropic_api_key:
            return "anthropic"
        if s.openai_api_key:
            return "openai"
        return "offline"
    if p == "openai" and not s.openai_api_key:
        return "offline"
    if p == "anthropic" and not s.anthropic_api_key:
        return "offline"
    return p


def _call(system: str, messages: list[dict], max_tokens: int = 900, temperature: float = 0.4) -> str:
    """messages: [{"role": "user"|"assistant", "content": str}]"""
    s = get_settings()
    p = provider()
    if p == "anthropic":
        import anthropic
        client = anthropic.Anthropic(api_key=s.anthropic_api_key, timeout=s.llm_timeout_sec)
        # (temperature is left at the model default: newer SDK versions no longer accept it)
        r = client.messages.create(model=s.anthropic_model, system=system, messages=messages, max_tokens=max_tokens)
        return "".join(b.text for b in r.content if getattr(b, "type", "") == "text")
    if p == "openai":
        from openai import BadRequestError, OpenAI
        client = OpenAI(api_key=s.openai_api_key, timeout=s.llm_timeout_sec)
        msgs = [{"role": "system", "content": system}, *messages]
        try:
            r = client.chat.completions.create(model=s.openai_model, max_tokens=max_tokens,
                                               temperature=temperature, messages=msgs)
        except BadRequestError:
            # newer/reasoning models want max_completion_tokens and only the default temperature
            r = client.chat.completions.create(model=s.openai_model, max_completion_tokens=max_tokens * 4,
                                               messages=msgs)
        return r.choices[0].message.content or ""
    raise RuntimeError("offline")


# ---------------------------------------------------------------- tutor chat
TUTOR_SYSTEM = """You are "Smart Tutor", a patient, encouraging tutor for engineering students.
Subject areas: Python programming, DBMS (databases & SQL) and Quantitative Aptitude.
Learner profile: {profile}
Current topic: {topic}
Rules:
- Match the learner's level. For Beginner: short sentences, everyday analogies, one idea at a time.
  For Advanced: precise terms, edge cases, and a stretch question at the end.
- Prefer guiding questions and hints over just giving final answers to practice problems.
- Use small code/SQL examples in fenced blocks where useful. For aptitude, show steps.
- Keep answers under ~200 words unless asked for more.
- If something is outside these subjects, answer briefly and steer back to learning.
- If a doubt needs human judgement (exam rules, grading, personal issues), suggest messaging their teacher.
Reference notes for this topic (may be empty):
{notes}"""


def tutor_reply(history: list[dict], question: str, topic: str, notes: str, profile: str) -> tuple[str, str]:
    system = TUTOR_SYSTEM.format(profile=profile, topic=topic or "General", notes=notes[:4000])
    msgs = [*history[-10:], {"role": "user", "content": question}]
    try:
        return _call(system, msgs), provider()
    except Exception as e:  # noqa: BLE001
        if str(e) != "offline":
            log.warning("LLM call failed, using offline tutor: %s", e)
        return offline_answer(question, notes, topic), "offline"


def _paragraphs(notes: str) -> list[str]:
    parts = [p.strip() for p in re.split(r"\n\s*\n", notes) if len(p.strip()) > 25]
    return parts or ([notes] if notes else [])


def offline_answer(question: str, notes: str, topic: str) -> str:
    paras = _paragraphs(notes)
    if not paras:
        return ("I'm running in offline mode right now. Open a topic so I can answer from its notes, "
                "or ask your teacher for help.")
    vec = TfidfVectorizer(stop_words="english").fit(paras + [question])
    sims = cosine_similarity(vec.transform([question]), vec.transform(paras))[0]
    best = sims.argsort()[::-1][:2]
    if sims[best[0]] < 0.05:
        return (f"I couldn't find that in the **{topic}** notes. Try rephrasing with key words from the topic, "
                "or send this doubt to your teacher from the dashboard.")
    body = "\n\n".join(paras[i] for i in best if sims[i] > 0.03)
    return f"Here's what the **{topic}** notes say about that:\n\n{body}\n\n_(Offline tutor: answer retrieved from course notes.)_"


# ---------------------------------------------------------------- answer explanation
def explain_mistake(question: str, options: list[str], correct: int, chosen: int, base_expl: str, level: str) -> str:
    system = ("You are a friendly tutor. In under 120 words explain why the student's choice is wrong "
              "and why the correct option is right. Address the specific misconception. "
              f"The student's level is {level}; adapt your language. End with one quick tip to remember it.")
    prompt = (f"Question: {question}\nOptions: " + "; ".join(f"{chr(65+i)}) {o}" for i, o in enumerate(options)) +
              f"\nStudent chose: {chr(65+chosen)}) {options[chosen]}\nCorrect: {chr(65+correct)}) {options[correct]}"
              f"\nTextbook explanation: {base_expl}")
    try:
        return _call(system, [{"role": "user", "content": prompt}], max_tokens=350)
    except Exception:  # noqa: BLE001
        return (f"You chose **{options[chosen]}**, but the correct answer is **{options[correct]}**. "
                f"{base_expl}")


# ---------------------------------------------------------------- question generation
GEN_SYSTEM = """You write high-quality multiple-choice questions for engineering students.
Return ONLY valid JSON, no prose: {"questions": [{"text": str, "options": [4 strings],
"correct_index": 0-3, "explanation": str, "difficulty": 1|2|3}]}
Rules: exactly 4 plausible options, one correct; distractors reflect common misconceptions;
no "all of the above"; code in questions uses \\n for newlines; explanations are 1-3 sentences."""


def generate_questions(topic: str, subject: str, notes: str, difficulty: int, count: int) -> tuple[list[dict], str]:
    lvl = {1: "easy (recall/understanding)", 2: "medium (application)", 3: "hard (analysis, tricky edge cases)"}
    prompt = (f"Subject: {subject}\nTopic: {topic}\nDifficulty: {lvl.get(difficulty, 'medium')}\n"
              f"Write {count} questions.\nReference notes:\n{notes[:3500]}")
    try:
        raw = _call(GEN_SYSTEM, [{"role": "user", "content": prompt}], max_tokens=2500, temperature=0.7)
        m = re.search(r"\{.*\}", raw, re.S)
        data = json.loads(m.group(0) if m else raw)
        qs = [q for q in data.get("questions", []) if _valid(q)]
        for q in qs:
            q["difficulty"] = int(q.get("difficulty") or difficulty)
        if qs:
            return qs[:count], provider()
    except Exception as e:  # noqa: BLE001
        if str(e) != "offline":
            log.warning("LLM generation failed, using offline generator: %s", e)
    return cloze_questions(notes, difficulty, count), "offline"


def _valid(q: dict) -> bool:
    return (isinstance(q.get("text"), str) and isinstance(q.get("options"), list) and len(q["options"]) == 4
            and isinstance(q.get("correct_index"), int) and 0 <= q["correct_index"] < 4)


def cloze_questions(notes: str, difficulty: int, count: int) -> list[dict]:
    """Offline NLP generator: blank out a **bold key term** in a sentence; distractors are other key terms."""
    terms = list(dict.fromkeys(t.strip() for t in re.findall(r"\*\*(.+?)\*\*", notes) if 1 < len(t) < 40))
    sentences = [s.strip() for s in re.split(r"(?<=[.!?])\s+|\n", notes) if "**" in s and len(s) > 30]
    out, rng = [], random.Random()
    rng.shuffle(sentences)
    for s in sentences:
        found = [t for t in re.findall(r"\*\*(.+?)\*\*", s) if t in terms]
        others = [t for t in terms if t not in found]
        if not found or len(others) < 3 or s.rstrip().endswith(("e.g.", "i.e.", ":")):
            continue
        ans = found[0]
        stem = s.replace(f"**{ans}**", "_____").replace("**", "").lstrip("-*# ").strip()
        opts = rng.sample(others, 3) + [ans]
        rng.shuffle(opts)
        out.append({"text": f"Fill in the blank: {stem}", "options": opts, "correct_index": opts.index(ans),
                    "explanation": f"From the notes: {s.replace('**', '')}", "difficulty": difficulty})
        if len(out) >= count:
            break
    return out


def simplify(text: str, level: str) -> str:
    system = (f"Rewrite these study notes for a {level} learner. Keep markdown. Beginner: simpler words, an analogy, "
              "one worked example. Advanced: add depth, edge cases, interview-style insight. Keep it under 350 words.")
    try:
        return _call(system, [{"role": "user", "content": text[:5000]}], max_tokens=800)
    except Exception:  # noqa: BLE001
        return text
