"""Runtime ML: at-risk prediction (trained RandomForest) and learner clustering (K-Means)."""
from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

from .features import FEATURES

ART = Path(__file__).resolve().parents[2] / "ml" / "artifacts"


@lru_cache
def _load():
    path = ART / "risk_model.joblib"
    if not path.exists():
        from ml.train import simulate, train  # train on first use so the app always works
        train(simulate())
    return joblib.load(path)


def model_metrics() -> dict:
    _load()
    p = ART / "metrics.json"
    return json.loads(p.read_text()) if p.exists() else {}


def predict_risk(features: dict) -> dict:
    """Probability that the student is at risk of under-performing, plus the main drivers."""
    if features.get("n_attempts", 0) < 3:
        return {"risk": None, "label": "Not enough data", "drivers": []}
    bundle = _load()
    X = pd.DataFrame([[features[f] for f in bundle["features"]]], columns=bundle["features"])
    prob = float(bundle["model"].predict_proba(X)[0, 1])
    label = "High risk" if prob >= 0.6 else ("Watch" if prob >= 0.3 else "On track")
    drivers = []
    if features["accuracy"] < 0.5:
        drivers.append("low overall accuracy")
    if features["hard_accuracy"] < 0.35:
        drivers.append("struggles with hard questions")
    if features["trend"] < -0.1:
        drivers.append("recent performance dropping")
    if features["study_minutes"] < 10:
        drivers.append("very little time on study material")
    if features["avg_time"] > 60:
        drivers.append("slow responses")
    return {"risk": round(prob, 3), "label": label, "drivers": drivers}


CLUSTER_NAMES = ["Needs Support", "Steady Learner", "Fast Learner"]


def cluster_students(rows: list[dict]) -> dict[int, str]:
    """Group students by learning behaviour. rows: [{"id":.., **features}].

    Clusters are named by their average accuracy so labels are stable and explainable.
    """
    rows = [r for r in rows if r["n_attempts"] >= 3]
    if not rows:
        return {}
    cols = ["accuracy", "hard_accuracy", "avg_time", "mastery_avg", "trend"]
    X = np.array([[r[c] for c in cols] for r in rows], dtype=float)
    k = min(3, len(rows))
    if k < 3:
        return {r["id"]: ("Fast Learner" if r["accuracy"] >= .75 else "Needs Support" if r["accuracy"] < .5
                          else "Steady Learner") for r in rows}
    labels = KMeans(n_clusters=3, n_init=10, random_state=0).fit_predict(StandardScaler().fit_transform(X))
    order = sorted(range(3), key=lambda c: X[labels == c, 0].mean() if (labels == c).any() else 0)
    name_of = {c: CLUSTER_NAMES[i] for i, c in enumerate(order)}
    return {r["id"]: name_of[l] for r, l in zip(rows, labels)}


__all__ = ["predict_risk", "cluster_students", "model_metrics", "FEATURES"]
