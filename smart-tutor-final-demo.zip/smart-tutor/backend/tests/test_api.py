"""End-to-end API tests on a fresh seeded SQLite database (offline LLM mode)."""
import os
import tempfile

_db = tempfile.NamedTemporaryFile(suffix=".db", delete=False).name
os.environ.setdefault("DATABASE_URL", f"sqlite:///{_db}")
os.environ["LLM_PROVIDER"] = "offline"

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app.main import app  # noqa: E402
from app.seed import seed  # noqa: E402
from app.services.adaptive import bkt_update, target_difficulty  # noqa: E402

seed(reset=True)
client = TestClient(app)


def login(email, pw):
    r = client.post("/api/auth/login", json={"email": email, "password": pw})
    assert r.status_code == 200, r.text
    return {"Authorization": f"Bearer {r.json()['access_token']}"}


@pytest.fixture(scope="module")
def student():
    return login("student@smarttutor.edu", "student123")


@pytest.fixture(scope="module")
def teacher():
    return login("teacher@smarttutor.edu", "teacher123")


def test_bkt_moves_in_right_direction():
    assert bkt_update(0.5, True, 2) > 0.5
    assert bkt_update(0.5, False, 2) < 0.5
    # a correct hard answer is stronger evidence than a correct easy one
    assert bkt_update(0.5, True, 3) > bkt_update(0.5, True, 1)


def test_difficulty_adapts():
    assert target_difficulty(0.2, []) == 1
    assert target_difficulty(0.9, []) == 3
    assert target_difficulty(0.6, [True, True]) == 3
    assert target_difficulty(0.6, [False]) == 1


def test_auth_rules():
    assert client.post("/api/auth/login", json={"email": "student@smarttutor.edu", "password": "bad"}).status_code == 401
    r = client.post("/api/auth/register", json={"name": "X Y", "email": "x@y.com", "password": "secret1",
                                                "role": "teacher", "teacher_code": "nope"})
    assert r.status_code == 403
    r = client.post("/api/auth/register", json={"name": "New Kid", "email": "new@kid.com", "password": "secret1"})
    assert r.status_code == 200 and r.json()["user"]["role"] == "student"
    assert client.get("/api/student/dashboard").status_code == 401


def test_role_separation(student, teacher):
    assert client.get("/api/teacher/overview", headers=student).status_code == 403
    assert client.get("/api/student/dashboard", headers=teacher).status_code == 403


def test_dashboard(student):
    d = client.get("/api/student/dashboard", headers=student).json()
    assert d["stats"]["attempts"] > 0
    assert d["recommendations"]
    assert d["learning_health"]["label"] in {"On track", "Watch", "High risk"}
    assert any(t["level"] == "Beginner" for t in d["topics"])  # DBMS is weak by design


def test_adaptive_notes(student):
    subs = client.get("/api/subjects", headers=student).json()
    weak = next(t for s in subs for t in s["topics"] if t["level"] == "Beginner")
    t = client.get(f"/api/topics/{weak['id']}", headers=student).json()
    assert t["level"] == "Beginner" and "simple version" in t["notes"]
    assert client.post(f"/api/topics/{weak['id']}/study", json={"seconds": 120}, headers=student).json()["ok"]


def test_full_adaptive_quiz(student):
    s = client.post("/api/quiz/start", json={"topic_id": 1}, headers=student).json()
    assert "correct_index" not in s["question"]
    q, sid, n = s["question"], s["session_id"], 0
    while q:
        r = client.post(f"/api/quiz/{sid}/answer", headers=student,
                        json={"question_id": q["id"], "selected_index": 0, "time_taken_sec": 12}).json()
        assert "correct" in r and "explanation" in r
        n += 1
        q = r["next_question"]
    assert r["finished"] and n == 8
    res = client.get(f"/api/quiz/{sid}/result", headers=student).json()
    assert res["total"] == 8 and len(res["review"]) == 8
    wrong = next((x for x in res["review"] if not x["is_correct"]), None)
    if wrong:
        e = client.post("/api/quiz/explain", headers=student,
                        json={"question_id": wrong["question_id"], "selected_index": wrong["selected_index"]}).json()
        assert e["explanation"]


def test_cannot_answer_wrong_question(student):
    s = client.post("/api/quiz/start", json={"topic_id": 2}, headers=student).json()
    r = client.post(f"/api/quiz/{s['session_id']}/answer", headers=student,
                    json={"question_id": s["question"]["id"] + 9999, "selected_index": 0})
    assert r.status_code == 400


def test_offline_tutor(student):
    r = client.post("/api/tutor/chat", headers=student, json={"message": "what is floor division?", "topic_id": 1})
    assert r.status_code == 200 and r.json()["provider"] == "offline"
    assert "floor" in r.json()["reply"].lower()
    assert len(client.get("/api/tutor/history", headers=student).json()) >= 2


def test_teacher_overview_and_detail(teacher):
    o = client.get("/api/teacher/overview", headers=teacher).json()
    assert o["kpis"]["students"] >= 23
    assert {c["name"] for c in o["clusters"]} >= {"Needs Support", "Fast Learner"}
    assert o["topics"] and o["most_missed"]
    sid = o["students"][0]["id"]
    d = client.get(f"/api/teacher/students/{sid}", headers=teacher).json()
    assert "risk" in d and "topics" in d


def test_human_in_the_loop_questions(teacher, student):
    g = client.post("/api/teacher/questions/generate", headers=teacher,
                    json={"topic_id": 1, "difficulty": 2, "count": 2}).json()
    assert g["questions"], "offline cloze generator should produce questions"
    assert all(not q["approved"] for q in g["questions"])
    qid = g["questions"][0]["id"]
    assert client.post(f"/api/teacher/questions/{qid}/approve", headers=teacher).json()["approved"]


def test_feedback_roundtrip(teacher, student):
    assert client.post("/api/student/doubts", headers=student, json={"message": "Help with joins"}).json()["ok"]
    doubts = client.get("/api/teacher/doubts", headers=teacher).json()
    assert any(d["message"] == "Help with joins" for d in doubts)
    me = next(d for d in doubts if d["message"] == "Help with joins")
    assert client.post("/api/teacher/feedback", headers=teacher,
                       json={"student_id": me["student_id"], "message": "Sure, see notes"}).json()["ok"]
    msgs = client.get("/api/student/dashboard", headers=student).json()["messages"]
    assert any(m["message"] == "Sure, see notes" for m in msgs)


def test_change_password_and_config():
    r = client.post("/api/auth/register", json={"name": "Pw User", "email": "pw@x.com", "password": "secret1"}).json()
    h = {"Authorization": f"Bearer {r['access_token']}"}
    assert client.post("/api/auth/change-password", headers=h,
                       json={"current_password": "wrong", "new_password": "newpass1"}).status_code == 400
    assert client.post("/api/auth/change-password", headers=h,
                       json={"current_password": "secret1", "new_password": "newpass1"}).json()["ok"]
    login("pw@x.com", "newpass1")
    assert client.get("/api/auth/config").json()["demo_mode"] is True
