import { useState } from 'react'
import { NavLink, Outlet, useNavigate } from 'react-router-dom'
import { BarChart3, BookOpen, Bot, Brain, ClipboardList, GraduationCap, LayoutDashboard, LogOut, Menu,
  MessageSquare, FileText, X, KeyRound, ClipboardCheck } from 'lucide-react'
import { useAuth } from '../auth'
import { api } from '../api'

const STUDENT_NAV = [
  { to: '/student', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/student/learn', label: 'Learn', icon: BookOpen },
  { to: '/student/tutor', label: 'AI Tutor', icon: Bot },
  { to: '/student/progress', label: 'My Progress', icon: BarChart3 },
]
const TEACHER_NAV = [
  { to: '/teacher', label: 'Class Overview', icon: LayoutDashboard, end: true },
  { to: '/teacher/questions', label: 'Question Bank', icon: ClipboardList },
  { to: '/teacher/content', label: 'Content', icon: FileText },
  { to: '/teacher/doubts', label: 'Student Doubts', icon: MessageSquare },
  { to: '/teacher/model', label: 'AI Model', icon: Brain },
  { to: '/teacher/review-lab', label: 'AI + Teacher Review', icon: ClipboardCheck },
]

export default function Layout() {
  const { user, logout } = useAuth()
  const nav = useNavigate()
  const [open, setOpen] = useState(false)
  const [pw, setPw] = useState(null)   // null = closed, else {current, next, msg}
  const changePw = async e => {
    e.preventDefault()
    try {
      await api('/api/auth/change-password', { method: 'POST', body: { current_password: pw.current, new_password: pw.next } })
      setPw({ current: '', next: '', msg: 'Password changed ✓' })
    } catch (err) { setPw({ ...pw, msg: err.message }) }
  }
  const items = user?.role === 'teacher' ? TEACHER_NAV : STUDENT_NAV

  const Sidebar = (
    <aside className="flex h-full w-64 flex-col bg-brand-900 text-indigo-100">
      <div className="flex items-center gap-3 px-6 py-5">
        <div className="h-9 w-9 rounded-xl bg-brand-500 grid place-items-center"><GraduationCap size={20} className="text-white" /></div>
        <div>
          <div className="font-bold text-white leading-tight">Smart Tutor</div>
          <div className="text-[11px] text-indigo-300">AI + Natural Intelligence</div>
        </div>
      </div>
      <nav className="flex-1 px-3 space-y-1">
        {items.map(({ to, label, icon: Icon, end }) => (
          <NavLink key={to} to={to} end={end} onClick={() => setOpen(false)}
            className={({ isActive }) => `flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition ${isActive ? 'bg-white/10 text-white' : 'hover:bg-white/5'}`}>
            <Icon size={18} />{label}
          </NavLink>
        ))}
      </nav>
      <div className="m-3 rounded-xl bg-white/5 p-3">
        <div className="text-sm font-semibold text-white truncate">{user?.name}</div>
        <div className="text-xs text-indigo-300 capitalize">{user?.role}</div>
        <button onClick={() => setPw({ current: '', next: '', msg: '' })} className="mt-2 flex items-center gap-2 text-xs text-indigo-200 hover:text-white">
          <KeyRound size={14} /> Change password
        </button>
        <button onClick={() => { logout(); nav('/login') }} className="mt-1 flex items-center gap-2 text-xs text-indigo-200 hover:text-white">
          <LogOut size={14} /> Sign out
        </button>
      </div>
    </aside>
  )

  return (
    <div className="flex min-h-screen">
      <div className="hidden lg:block fixed inset-y-0 left-0">{Sidebar}</div>
      {open && (
        <div className="lg:hidden fixed inset-0 z-40 flex">
          <div className="relative">{Sidebar}<button className="absolute right-3 top-5 text-white" onClick={() => setOpen(false)}><X /></button></div>
          <div className="flex-1 bg-black/40" onClick={() => setOpen(false)} />
        </div>
      )}
      {pw && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/40 p-4" onClick={() => setPw(null)}>
          <form onSubmit={changePw} onClick={e => e.stopPropagation()} className="card w-full max-w-sm p-6 space-y-3">
            <h2 className="h2">Change password</h2>
            <input className="input" type="password" placeholder="Current password" value={pw.current} onChange={e => setPw({ ...pw, current: e.target.value })} required />
            <input className="input" type="password" placeholder="New password (min 6 characters)" minLength={6} value={pw.next} onChange={e => setPw({ ...pw, next: e.target.value })} required />
            {pw.msg && <div className="text-sm text-slate-600">{pw.msg}</div>}
            <div className="flex justify-end gap-2"><button type="button" className="btn-ghost" onClick={() => setPw(null)}>Close</button><button className="btn-primary">Save</button></div>
          </form>
        </div>
      )}
      <main className="flex-1 lg:ml-64 min-w-0">
        <div className="lg:hidden flex items-center gap-3 border-b bg-white px-4 py-3">
          <button onClick={() => setOpen(true)}><Menu /></button><span className="font-semibold">Smart Tutor</span>
        </div>
        <div className="mx-auto max-w-7xl p-4 sm:p-8"><Outlet /></div>
      </main>
    </div>
  )
}
