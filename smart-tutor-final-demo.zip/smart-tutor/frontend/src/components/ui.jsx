import ReactMarkdown from 'react-markdown'
import remarkGfm from 'remark-gfm'
import { Loader2 } from 'lucide-react'

export const Card = ({ className = '', children, ...p }) => <div className={`card ${className}`} {...p}>{children}</div>

export function Stat({ label, value, sub, icon: Icon, tone = 'brand' }) {
  const tones = { brand: 'bg-brand-50 text-brand-600', green: 'bg-emerald-50 text-emerald-600',
    amber: 'bg-amber-50 text-amber-600', rose: 'bg-rose-50 text-rose-600', sky: 'bg-sky-50 text-sky-600' }
  return (
    <Card className="p-4 flex items-center gap-4">
      {Icon && <div className={`h-11 w-11 shrink-0 rounded-xl grid place-items-center ${tones[tone]}`}><Icon size={20} /></div>}
      <div className="min-w-0">
        <div className="text-xs font-medium text-slate-500">{label}</div>
        <div className="text-xl font-bold text-slate-900 truncate">{value}</div>
        {sub && <div className="text-xs text-slate-500 truncate">{sub}</div>}
      </div>
    </Card>
  )
}

const LEVEL_TONE = {
  Beginner: 'bg-rose-50 text-rose-700 ring-rose-200',
  Intermediate: 'bg-amber-50 text-amber-700 ring-amber-200',
  Advanced: 'bg-emerald-50 text-emerald-700 ring-emerald-200',
  'High risk': 'bg-rose-50 text-rose-700 ring-rose-200',
  Watch: 'bg-amber-50 text-amber-700 ring-amber-200',
  'On track': 'bg-emerald-50 text-emerald-700 ring-emerald-200',
  'Needs Support': 'bg-rose-50 text-rose-700 ring-rose-200',
  'Steady Learner': 'bg-sky-50 text-sky-700 ring-sky-200',
  'Fast Learner': 'bg-emerald-50 text-emerald-700 ring-emerald-200',
  Easy: 'bg-emerald-50 text-emerald-700 ring-emerald-200',
  Medium: 'bg-amber-50 text-amber-700 ring-amber-200',
  Hard: 'bg-rose-50 text-rose-700 ring-rose-200',
  ai: 'bg-violet-50 text-violet-700 ring-violet-200',
}

export function Badge({ children, tone }) {
  const cls = LEVEL_TONE[tone || children] || 'bg-slate-100 text-slate-700 ring-slate-200'
  return <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ring-1 ring-inset whitespace-nowrap ${cls}`}>{children}</span>
}

export function MasteryBar({ value, className = '' }) {
  const v = Math.round((value || 0) * 100)
  const color = v < 45 ? 'bg-rose-500' : v < 75 ? 'bg-amber-500' : 'bg-emerald-500'
  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <div className="h-2 flex-1 rounded-full bg-slate-100 overflow-hidden">
        <div className={`h-full rounded-full ${color} transition-all duration-700`} style={{ width: `${v}%` }} />
      </div>
      <span className="w-10 text-right text-xs font-semibold text-slate-600">{v}%</span>
    </div>
  )
}

export const Spinner = ({ label = 'Loading…' }) => (
  <div className="flex items-center justify-center gap-2 py-16 text-slate-500"><Loader2 className="animate-spin" size={18} />{label}</div>
)

export const ErrorBox = ({ error }) => error ? <div className="rounded-xl bg-rose-50 text-rose-700 text-sm px-4 py-3">{String(error)}</div> : null

export const Markdown = ({ children, className = '' }) => (
  <div className={`prose-tutor ${className}`}><ReactMarkdown remarkPlugins={[remarkGfm]}>{children || ''}</ReactMarkdown></div>
)

export const PageHeader = ({ title, subtitle, children }) => (
  <div className="flex flex-wrap items-end justify-between gap-3 mb-6">
    <div><h1 className="h1">{title}</h1>{subtitle && <p className="muted mt-1">{subtitle}</p>}</div>
    {children && <div className="flex gap-2">{children}</div>}
  </div>
)

export const Empty = ({ children }) => <div className="text-sm text-slate-500 text-center py-8">{children}</div>
