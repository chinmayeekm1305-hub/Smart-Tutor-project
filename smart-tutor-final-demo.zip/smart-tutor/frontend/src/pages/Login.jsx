import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Bot, Brain, GraduationCap, LineChart, Users } from 'lucide-react'
import { useAuth } from '../auth'
import { api } from '../api'
import { ErrorBox } from '../components/ui'

export default function Login() {
  const { login, register } = useAuth()
  const nav = useNavigate()
  const [mode, setMode] = useState('login')
  const [f, setF] = useState({ name: '', email: '', password: '', role: 'student', academic_info: '', teacher_code: '' })
  const [err, setErr] = useState('')
  const [busy, setBusy] = useState(false)
  const [demo, setDemo] = useState(false)
  useEffect(() => { api('/api/auth/config').then(c => setDemo(c.demo_mode)).catch(() => {}) }, [])
  const set = k => e => setF({ ...f, [k]: e.target.value })

  const go = async (fn) => {
    setErr(''); setBusy(true)
    try { const u = await fn(); nav(`/${u.role}`) } catch (e) { setErr(e.message) } finally { setBusy(false) }
  }
  const submit = e => {
    e.preventDefault()
    go(() => mode === 'login' ? login(f.email, f.password) : register(f))
  }

  return (
    <div className="min-h-screen grid lg:grid-cols-2">
      <div className="hidden lg:flex flex-col justify-between bg-brand-900 p-12 text-indigo-100">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-xl bg-brand-500 grid place-items-center"><GraduationCap className="text-white" /></div>
          <span className="text-lg font-bold text-white">Smart Tutor Platform</span>
        </div>
        <div>
          <h1 className="text-4xl font-bold text-white leading-tight">Learning that adapts<br />to every student.</h1>
          <p className="mt-4 max-w-md text-indigo-200">Artificial Intelligence personalises content, quizzes and feedback.
            Natural Intelligence (your teachers) guides, reviews and mentors.</p>
          <div className="mt-10 grid grid-cols-2 gap-4 max-w-md">
            {[[Brain, 'Adaptive quizzes', 'Difficulty adjusts after every answer'],
              [Bot, 'AI tutor', 'Ask doubts any time, in plain language'],
              [LineChart, 'ML insights', 'Predicts who needs help, early'],
              [Users, 'Teacher in the loop', 'Teachers review the AI and mentor students']].map(([I, t, d]) => (
              <div key={t} className="rounded-xl bg-white/5 p-4">
                <I size={18} className="text-indigo-300" />
                <div className="mt-2 text-sm font-semibold text-white">{t}</div>
                <div className="text-xs text-indigo-300">{d}</div>
              </div>
            ))}
          </div>
        </div>
        <div className="text-xs text-indigo-400">Dept. of AI & DS · 2025-26</div>
      </div>

      <div className="flex items-center justify-center p-6">
        <div className="w-full max-w-sm">
          <h2 className="text-2xl font-bold text-slate-900">{mode === 'login' ? 'Welcome back' : 'Create your account'}</h2>
          <p className="muted mt-1">{mode === 'login' ? 'Sign in to continue learning.' : 'Join as a student or a teacher.'}</p>

          <form onSubmit={submit} className="mt-6 space-y-4">
            {mode === 'register' && (
              <>
                <div><label className="label">Full name</label><input className="input" value={f.name} onChange={set('name')} required /></div>
                <div className="grid grid-cols-2 gap-2">
                  {['student', 'teacher'].map(r => (
                    <button type="button" key={r} onClick={() => setF({ ...f, role: r })}
                      className={`btn capitalize ${f.role === r ? 'bg-brand-600 text-white' : 'btn-ghost'}`}>{r}</button>
                  ))}
                </div>
                <div><label className="label">Academic info</label><input className="input" placeholder="B.E. AI & DS, 5th Sem" value={f.academic_info} onChange={set('academic_info')} /></div>
                {f.role === 'teacher' && <div><label className="label">Teacher invite code</label><input className="input" value={f.teacher_code} onChange={set('teacher_code')} required /></div>}
              </>
            )}
            <div><label className="label">Email</label><input className="input" type="email" value={f.email} onChange={set('email')} required /></div>
            <div><label className="label">Password</label><input className="input" type="password" minLength={6} value={f.password} onChange={set('password')} required /></div>
            <ErrorBox error={err} />
            <button className="btn-primary w-full py-2.5" disabled={busy}>{busy ? 'Please wait…' : mode === 'login' ? 'Sign in' : 'Create account'}</button>
          </form>

          <button className="mt-4 text-sm text-brand-600 hover:underline" onClick={() => { setMode(mode === 'login' ? 'register' : 'login'); setErr('') }}>
            {mode === 'login' ? "New here? Create an account" : 'Already have an account? Sign in'}
          </button>

          {mode === 'login' && demo && (
            <div className="mt-8 rounded-2xl border border-dashed border-slate-300 p-4">
              <div className="label">Demo accounts</div>
              <div className="grid grid-cols-2 gap-2 mt-2">
                <button className="btn-ghost" disabled={busy} onClick={() => go(() => login('student@smarttutor.edu', 'student123'))}>Student demo</button>
                <button className="btn-ghost" disabled={busy} onClick={() => go(() => login('teacher@smarttutor.edu', 'teacher123'))}>Teacher demo</button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
