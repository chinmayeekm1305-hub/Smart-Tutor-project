import { useEffect, useState } from 'react'
import { Loader2, Save, Sparkles } from 'lucide-react'
import { api } from '../../api'
import { Card, ErrorBox, Markdown, PageHeader, Spinner } from '../../components/ui'

const FIELDS = [['notes', 'Standard notes'], ['simple_notes', 'Simplified (Beginner)'], ['advanced_notes', 'Advanced extension']]

export default function Content() {
  const [subjects, setSubjects] = useState([])
  const [topicId, setTopicId] = useState('')
  const [t, setT] = useState(null)
  const [field, setField] = useState('notes')
  const [preview, setPreview] = useState(false)
  const [busy, setBusy] = useState(false)
  const [msg, setMsg] = useState('')

  useEffect(() => { api('/api/subjects').then(s => { setSubjects(s); setTopicId(String(s[0]?.topics[0]?.id || '')) }) }, [])
  useEffect(() => { if (topicId) { setT(null); api(`/api/teacher/topics/${topicId}`).then(setT) } }, [topicId])

  const save = async () => {
    await api(`/api/teacher/topics/${topicId}`, { method: 'PUT', body: { notes: t.notes, simple_notes: t.simple_notes, advanced_notes: t.advanced_notes, video_url: t.video_url } })
    setMsg('Saved ✓')
    setTimeout(() => setMsg(''), 2500)
  }
  const draft = async () => {
    setBusy(true)
    try {
      const level = field === 'advanced_notes' ? 'Advanced' : 'Beginner'
      const r = await api(`/api/teacher/topics/${topicId}/ai-notes`, { method: 'POST', body: { level } })
      setT({ ...t, [field]: r.draft })
      setMsg(r.provider === 'offline' ? 'Offline mode: add an API key for AI drafts.' : 'AI draft inserted. Review it, then save.')
    } finally { setBusy(false) }
  }

  return (
    <>
      <PageHeader title="Content" subtitle="Write the notes students see at each level. AI can draft; you stay the editor." />
      <Card className="p-4 flex flex-wrap items-end gap-3">
        <div className="w-64"><label className="label">Topic</label>
          <select className="input" value={topicId} onChange={e => setTopicId(e.target.value)}>
            {subjects.map(s => <optgroup key={s.id} label={s.name}>{s.topics.map(x => <option key={x.id} value={x.id}>{x.name}</option>)}</optgroup>)}
          </select></div>
        <div className="flex gap-1 rounded-xl bg-slate-100 p-1">
          {FIELDS.map(([k, l]) => <button key={k} onClick={() => setField(k)} className={`rounded-lg px-3 py-1.5 text-sm ${field === k ? 'bg-white shadow font-medium text-brand-700' : 'text-slate-600'}`}>{l}</button>)}
        </div>
        <div className="flex-1" />
        {field !== 'notes' && <button className="btn bg-violet-600 text-white hover:bg-violet-700" onClick={draft} disabled={busy}>{busy ? <Loader2 size={16} className="animate-spin" /> : <Sparkles size={16} />} AI draft</button>}
        <button className="btn-ghost" onClick={() => setPreview(!preview)}>{preview ? 'Edit' : 'Preview'}</button>
        <button className="btn-primary" onClick={save} disabled={!t}><Save size={16} /> Save</button>
      </Card>
      {msg && <div className="mt-3 text-sm text-emerald-700">{msg}</div>}
      {!t ? <Spinner /> : (
        <Card className="mt-4 p-5">
          {preview
            ? <Markdown>{t[field]}</Markdown>
            : <textarea className="input h-[60vh] font-mono text-xs leading-5" value={t[field] || ''} onChange={e => setT({ ...t, [field]: e.target.value })} />}
          <div className="mt-3"><label className="label">Video link</label><input className="input" value={t.video_url || ''} onChange={e => setT({ ...t, video_url: e.target.value })} /></div>
          <p className="mt-2 text-xs text-slate-500">Tip: wrap key terms in **bold**. The offline question generator uses them to build fill-in-the-blank questions.</p>
        </Card>
      )}
    </>
  )
}
