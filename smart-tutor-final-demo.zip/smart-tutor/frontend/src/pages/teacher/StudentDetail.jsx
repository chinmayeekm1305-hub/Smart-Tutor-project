import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { ArrowLeft, Clock, Send, Target, Zap } from 'lucide-react'
import { api, pct } from '../../api'
import { Badge, Card, Empty, ErrorBox, MasteryBar, Spinner, Stat } from '../../components/ui'

export default function StudentDetail() {
  const { id } = useParams()
  const [d, setD] = useState(null)
  const [err, setErr] = useState('')
  const [msg, setMsg] = useState('')
  const [ok, setOk] = useState('')
  const load = () => api(`/api/teacher/students/${id}`).then(setD).catch(e => setErr(e.message))
  useEffect(() => { load() }, [id])
  if (err) return <ErrorBox error={err} />
  if (!d) return <Spinner />

  const weakest = d.topics[0]
  const suggest = () => setMsg(weakest
    ? `Hi ${d.student.name.split(' ')[0]}, I see ${weakest.topic} is at ${Math.round(weakest.mastery * 100)}% mastery. Please read the simplified notes and take two adaptive quizzes this week. Feel free to meet me after class.`
    : `Hi ${d.student.name.split(' ')[0]}, great work so far. Keep practising!`)
  const send = async () => {
    await api('/api/teacher/feedback', { method: 'POST', body: { student_id: d.student.id, message: msg, topic_id: weakest?.topic_id } })
    setMsg(''); setOk('Sent ✓'); load()
  }

  return (
    <>
      <Link to="/teacher" className="inline-flex items-center gap-1 text-sm text-slate-500 hover:text-brand-600"><ArrowLeft size={14} /> Class overview</Link>
      <div className="mt-2 mb-6 flex flex-wrap items-center gap-3">
        <h1 className="h1">{d.student.name}</h1>
        {d.risk.risk != null && <Badge>{d.risk.label}</Badge>}
        <span className="muted">{d.student.academic_info} · {d.student.email}</span>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Stat label="Accuracy" value={pct(d.features.accuracy)} sub={`hard: ${pct(d.features.hard_accuracy)}`} icon={Target} />
        <Stat label="Avg. mastery" value={pct(d.features.mastery_avg)} sub={`trend ${d.features.trend >= 0 ? '+' : ''}${pct(d.features.trend)}`} icon={Zap} tone="green" />
        <Stat label="Avg. time / question" value={`${d.features.avg_time}s`} sub={`${d.features.n_attempts} answers`} icon={Clock} tone="sky" />
        <Stat label="Risk score" value={d.risk.risk != null ? Math.round(d.risk.risk * 100) : '—'} sub={d.risk.drivers[0] || 'no warning signs'} icon={Target} tone="rose" />
      </div>

      <div className="mt-6 grid lg:grid-cols-3 gap-6">
        <Card className="p-5 lg:col-span-2">
          <h2 className="h2">Daily accuracy (21 days)</h2>
          <div className="h-56 mt-3">
            <ResponsiveContainer>
              <AreaChart data={d.trend}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
                <XAxis dataKey="date" tickFormatter={v => v.slice(5)} fontSize={11} stroke="#94a3b8" />
                <YAxis domain={[0, 100]} unit="%" fontSize={11} width={40} stroke="#94a3b8" />
                <Tooltip formatter={v => (v == null ? 'no activity' : `${v}%`)} />
                <Area type="monotone" dataKey="accuracy" stroke="#4f46e5" fill="#e0e7ff" strokeWidth={2} connectNulls />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>
        <Card className="p-5">
          <h2 className="h2">Topic mastery</h2>
          <div className="mt-3 space-y-3">
            {d.topics.length ? d.topics.map(t => (
              <div key={t.topic_id}>
                <div className="flex justify-between text-sm"><span className="truncate">{t.topic}</span><Badge>{t.level}</Badge></div>
                <MasteryBar value={t.mastery} className="mt-1" />
              </div>
            )) : <Empty>No activity yet.</Empty>}
          </div>
        </Card>
      </div>

      <div className="mt-6 grid lg:grid-cols-2 gap-6">
        <Card className="p-5">
          <h2 className="h2">Repeated mistakes</h2>
          <div className="mt-3 space-y-2">
            {d.mistakes.length ? d.mistakes.map(m => (
              <div key={m.question_id} className="rounded-xl bg-slate-50 p-3 text-sm">
                <div className="flex justify-between"><span className="text-xs font-semibold text-slate-500">{m.topic}</span><span className="text-xs text-rose-600">wrong {m.times_wrong}×</span></div>
                <div className="text-slate-700 line-clamp-2">{m.text.replace(/```[\s\S]*?```/g, '[code]')}</div>
              </div>
            )) : <Empty>None 🎉</Empty>}
          </div>
          <h2 className="h2 mt-5">Recent quizzes</h2>
          <div className="mt-2 divide-y text-sm">
            {d.sessions.map((s, i) => <div key={i} className="flex justify-between py-1.5"><span>{s.topic}</span><span className="font-semibold">{s.score}/{s.total}</span></div>)}
          </div>
        </Card>

        <Card className="p-5">
          <h2 className="h2">Mentor this student</h2>
          <p className="muted">Natural Intelligence: a personal note from you appears on their dashboard.</p>
          <div className="mt-3 space-y-2 max-h-56 overflow-y-auto">
            {d.messages.map(m => (
              <div key={m.id} className={`rounded-xl p-3 text-sm ${m.from_student ? 'bg-slate-50 mr-8' : 'bg-brand-50 ml-8'}`}>
                <div className="text-xs font-semibold text-slate-500">{m.from_student ? d.student.name : 'You'} · {new Date(m.created_at).toLocaleDateString()}</div>
                <div className="text-slate-700">{m.message}</div>
              </div>
            ))}
          </div>
          <textarea className="input mt-3 h-24" value={msg} onChange={e => setMsg(e.target.value)} placeholder="Write guidance…" />
          <div className="mt-2 flex items-center justify-between gap-2">
            <button className="btn-ghost" onClick={suggest}>Suggest a message</button>
            <div className="flex items-center gap-2"><span className="text-xs text-emerald-600">{ok}</span>
              <button className="btn-primary" disabled={msg.trim().length < 2} onClick={send}><Send size={16} /> Send</button></div>
          </div>
        </Card>
      </div>
    </>
  )
}
