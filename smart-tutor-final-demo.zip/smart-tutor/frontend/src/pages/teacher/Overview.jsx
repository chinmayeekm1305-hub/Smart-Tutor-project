import { useEffect, useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from 'recharts'
import { AlertTriangle, ClipboardCheck, MessageSquare, Target, Users } from 'lucide-react'
import { api, pct } from '../../api'
import { Badge, Card, ErrorBox, MasteryBar, PageHeader, Spinner, Stat } from '../../components/ui'

const CLUSTER_COLORS = { 'Needs Support': '#f43f5e', 'Steady Learner': '#0ea5e9', 'Fast Learner': '#10b981', New: '#cbd5e1' }

function heat(v) {
  if (v == null) return 'bg-slate-50 text-slate-400'
  if (v < 0.45) return 'bg-rose-100 text-rose-800'
  if (v < 0.6) return 'bg-amber-100 text-amber-800'
  if (v < 0.75) return 'bg-yellow-50 text-yellow-800'
  return 'bg-emerald-100 text-emerald-800'
}

export default function Overview() {
  const [d, setD] = useState(null)
  const [err, setErr] = useState('')
  const [sort, setSort] = useState('risk')
  const [q, setQ] = useState('')
  useEffect(() => { api('/api/teacher/overview').then(setD).catch(e => setErr(e.message)) }, [])

  const students = useMemo(() => {
    if (!d) return []
    const list = d.students.filter(s => s.name.toLowerCase().includes(q.toLowerCase()))
    const key = { risk: s => -(s.risk.risk ?? -1), accuracy: s => s.accuracy, name: s => s.name }[sort]
    return [...list].sort((a, b) => (key(a) > key(b) ? 1 : -1))
  }, [d, sort, q])

  if (err) return <ErrorBox error={err} />
  if (!d) return <Spinner />
  const k = d.kpis
  const bySubject = d.topics.reduce((acc, t) => ((acc[t.subject] ||= []).push(t), acc), {})

  return (
    <>
      <PageHeader title="Class Overview" subtitle="AI surfaces the patterns; you decide the intervention." />
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Stat label="Students" value={k.students} sub={`${k.active} active · ${k.quizzes} quizzes`} icon={Users} />
        <Stat label="Class accuracy" value={pct(k.avg_accuracy)} icon={Target} tone="green" />
        <Stat label="High-risk students" value={k.at_risk} sub="flagged by ML model" icon={AlertTriangle} tone="rose" />
        <Link to="/teacher/doubts"><Stat label="Open doubts / AI drafts" value={`${k.unread_doubts} / ${k.pending_questions}`} sub="need your attention" icon={MessageSquare} tone="amber" /></Link>
      </div>

      <div className="mt-6 grid lg:grid-cols-3 gap-6">
        <Card className="p-5">
          <h2 className="h2">Learner groups</h2>
          <p className="muted">K-Means clustering on behaviour</p>
          <div className="h-44 mt-2">
            <ResponsiveContainer>
              <PieChart>
                <Pie data={d.clusters} dataKey="count" nameKey="name" innerRadius={45} outerRadius={70} paddingAngle={3}>
                  {d.clusters.map(c => <Cell key={c.name} fill={CLUSTER_COLORS[c.name]} />)}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="space-y-1">
            {d.clusters.map(c => (
              <div key={c.name} className="flex items-center justify-between text-sm">
                <span className="flex items-center gap-2"><span className="h-2.5 w-2.5 rounded-full" style={{ background: CLUSTER_COLORS[c.name] }} />{c.name}</span>
                <span className="font-semibold">{c.count}</span>
              </div>
            ))}
          </div>
        </Card>

        <Card className="p-5 lg:col-span-2">
          <h2 className="h2 flex items-center gap-2"><AlertTriangle size={18} className="text-rose-500" /> Students who need attention</h2>
          <p className="muted">Ranked by predicted risk of under-performing</p>
          <div className="mt-3 divide-y">
            {d.at_risk.map(s => (
              <Link key={s.id} to={`/teacher/students/${s.id}`} className="flex flex-wrap items-center gap-3 py-2.5 hover:bg-slate-50 rounded px-2">
                <span className="font-medium text-slate-800 w-40 truncate">{s.name}</span>
                <Badge>{s.risk.label}</Badge>
                <span className="text-xs text-slate-500 flex-1 truncate">{s.risk.drivers.join(' · ') || '—'}</span>
                <span className="text-sm font-bold text-rose-600">{Math.round(s.risk.risk * 100)}</span>
              </Link>
            ))}
            {!d.at_risk.length && <div className="muted py-4">No students currently at risk 🎉</div>}
          </div>
        </Card>
      </div>

      <Card className="p-5 mt-6">
        <h2 className="h2">Topic heatmap: class average mastery</h2>
        <p className="muted">Red topics need re-teaching in class</p>
        <div className="mt-4 space-y-3">
          {Object.entries(bySubject).map(([subj, ts]) => (
            <div key={subj} className="grid grid-cols-[140px_1fr] items-center gap-3">
              <div className="text-sm font-semibold text-slate-700">{subj}</div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                {ts.map(t => (
                  <div key={t.topic_id} className={`rounded-xl px-3 py-2 ${heat(t.students ? t.avg_mastery : null)}`}>
                    <div className="text-xs font-medium truncate">{t.topic}</div>
                    <div className="text-lg font-bold">{t.students ? pct(t.avg_mastery) : '—'}</div>
                    <div className="text-[11px] opacity-80">{t.students} students</div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </Card>

      <div className="mt-6 grid lg:grid-cols-3 gap-6">
        <Card className="p-5 lg:col-span-2">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h2 className="h2">All students</h2>
            <div className="flex gap-2">
              <input className="input w-40" placeholder="Search…" value={q} onChange={e => setQ(e.target.value)} />
              <select className="input w-36" value={sort} onChange={e => setSort(e.target.value)}>
                <option value="risk">Sort: risk</option><option value="accuracy">Sort: accuracy</option><option value="name">Sort: name</option>
              </select>
            </div>
          </div>
          <div className="mt-3 overflow-x-auto">
            <table className="w-full text-sm">
              <thead><tr className="text-left text-slate-500 border-b"><th className="py-2">Name</th><th>Group</th><th>Accuracy</th><th className="w-36">Mastery</th><th>Answers</th><th>Risk</th></tr></thead>
              <tbody>
                {students.map(s => (
                  <tr key={s.id} className="border-b last:border-0 hover:bg-slate-50">
                    <td className="py-2"><Link className="font-medium text-brand-700 hover:underline" to={`/teacher/students/${s.id}`}>{s.name}</Link></td>
                    <td><Badge>{s.cluster}</Badge></td>
                    <td>{pct(s.accuracy)}</td>
                    <td><MasteryBar value={s.mastery_avg} /></td>
                    <td>{s.n_attempts}</td>
                    <td>{s.risk.risk != null ? <Badge>{s.risk.label}</Badge> : <span className="text-xs text-slate-400">n/a</span>}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
        <Card className="p-5">
          <h2 className="h2 flex items-center gap-2"><ClipboardCheck size={18} /> Most-missed questions</h2>
          <div className="mt-3 space-y-3">
            {d.most_missed.map(m => (
              <div key={m.question_id} className="text-sm">
                <div className="flex justify-between"><span className="text-xs font-semibold text-slate-500">{m.topic}</span><span className="text-xs font-bold text-rose-600">{pct(m.accuracy)} correct</span></div>
                <div className="text-slate-700 line-clamp-2">{m.text.replace(/```[\s\S]*?```/g, '[code]')}</div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </>
  )
}
