import { useEffect, useState } from 'react'
import { Bar, BarChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { api } from '../../api'
import { Badge, Card, PageHeader, Spinner } from '../../components/ui'

const PIPELINE = [
  ['1. Data collection', 'Every answer (correctness, difficulty, time), reading time and quiz session is logged.'],
  ['2. Knowledge tracing', 'Bayesian Knowledge Tracing updates P(student knows topic) after each answer.'],
  ['3. Adaptive engine', 'Next question difficulty = f(mastery, recent streak). Past mistakes resurface.'],
  ['4. Risk prediction', 'A supervised classifier predicts which students may under-perform.'],
  ['5. Learner clustering', 'K-Means groups students into Needs Support / Steady / Fast learners.'],
  ['6. LLM tutor', 'An LLM (GPT / Claude) answers doubts, explains mistakes and drafts questions, with an offline NLP fallback.'],
  ['7. Teacher in the loop', 'Teachers approve AI questions, edit notes, answer doubts and mentor at-risk students.'],
]

export default function ModelInfo() {
  const [m, setM] = useState(null)
  useEffect(() => { api('/api/teacher/model').then(setM) }, [])
  if (!m) return <Spinner />
  const met = m.metrics
  const fi = Object.entries(met.feature_importance || {}).map(([k, v]) => ({ name: k.replaceAll('_', ' '), v: Number(v.toFixed(3)) }))

  return (
    <>
      <PageHeader title="AI Model" subtitle="How the intelligence works: transparent for teachers and examiners." />
      <div className="grid lg:grid-cols-3 gap-6">
        <Card className="p-5">
          <h2 className="h2">Risk model</h2>
          <div className="mt-3 space-y-2 text-sm">
            <div className="flex justify-between"><span className="text-slate-500">Selected model</span><Badge>{met.selected_model?.replace('_', ' ')}</Badge></div>
            <div className="flex justify-between"><span className="text-slate-500">Training samples</span><b>{met.n_samples}</b></div>
            <div className="flex justify-between"><span className="text-slate-500">At-risk share</span><b>{Math.round(met.positive_rate * 100)}%</b></div>
            <div className="flex justify-between"><span className="text-slate-500">LLM provider</span><Badge>{m.llm_provider}</Badge></div>
          </div>
          <table className="mt-4 w-full text-sm">
            <thead><tr className="text-left text-slate-500 border-b"><th className="py-1">Model</th><th>Acc.</th><th>F1</th><th>AUC</th></tr></thead>
            <tbody>{Object.entries(met.results || {}).map(([k, r]) => (
              <tr key={k} className="border-b last:border-0"><td className="py-1 capitalize">{k.replace('_', ' ')}</td><td>{r.accuracy}</td><td>{r.f1}</td><td>{r.roc_auc}</td></tr>
            ))}</tbody>
          </table>
          <p className="mt-3 text-xs text-slate-500">Trained on a simulated cohort at launch. Retrain on real students with <code>python -m ml.train --from-db</code>.</p>
        </Card>
        <Card className="p-5 lg:col-span-2">
          <h2 className="h2">What drives the prediction</h2>
          <div className="h-72 mt-3">
            <ResponsiveContainer>
              <BarChart data={fi} layout="vertical" margin={{ left: 30 }}>
                <XAxis type="number" fontSize={11} stroke="#94a3b8" />
                <YAxis type="category" dataKey="name" fontSize={12} width={110} stroke="#94a3b8" />
                <Tooltip />
                <Bar dataKey="v" name="importance" fill="#6366f1" radius={[0, 6, 6, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </div>
      <Card className="p-5 mt-6">
        <h2 className="h2">System pipeline</h2>
        <div className="mt-4 grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {PIPELINE.map(([t, d]) => <div key={t} className="rounded-xl bg-slate-50 p-4"><div className="font-semibold text-slate-800 text-sm">{t}</div><div className="text-xs text-slate-600 mt-1">{d}</div></div>)}
        </div>
      </Card>
    </>
  )
}
