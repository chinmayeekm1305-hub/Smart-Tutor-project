import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { Send } from 'lucide-react'
import { api } from '../../api'
import { Badge, Card, Empty, PageHeader, Spinner } from '../../components/ui'

export default function Doubts() {
  const [rows, setRows] = useState(null)
  const [reply, setReply] = useState({})
  const load = () => api('/api/teacher/doubts').then(setRows)
  useEffect(() => { load() }, [])
  const send = async d => {
    await api('/api/teacher/feedback', { method: 'POST', body: { student_id: d.student_id, message: reply[d.id] } })
    setReply({ ...reply, [d.id]: '' }); load()
  }
  if (!rows) return <Spinner />
  return (
    <>
      <PageHeader title="Student Doubts" subtitle="Questions students escalated from the AI tutor to you." />
      <div className="space-y-3">
        {!rows.length && <Empty>No doubts yet.</Empty>}
        {rows.map(d => (
          <Card key={d.id} className={`p-5 ${!d.is_read ? 'border-amber-300' : ''}`}>
            <div className="flex flex-wrap items-center gap-2">
              <Link to={`/teacher/students/${d.student_id}`} className="font-semibold text-brand-700 hover:underline">{d.student}</Link>
              {d.topic && <Badge>{d.topic}</Badge>}
              {!d.is_read ? <Badge tone="Watch">Awaiting reply</Badge> : <Badge tone="On track">Answered</Badge>}
              <span className="ml-auto text-xs text-slate-500">{new Date(d.created_at).toLocaleString()}</span>
            </div>
            <p className="mt-2 text-slate-700">{d.message}</p>
            {!d.is_read && (
              <div className="mt-3 flex gap-2">
                <input className="input" placeholder="Reply to the student…" value={reply[d.id] || ''} onChange={e => setReply({ ...reply, [d.id]: e.target.value })} />
                <button className="btn-primary" disabled={(reply[d.id] || '').trim().length < 2} onClick={() => send(d)}><Send size={16} /></button>
              </div>
            )}
          </Card>
        ))}
      </div>
    </>
  )
}
