import { useMemo, useState } from 'react'
import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { CheckCircle2, RotateCcw, Sparkles, Users, ClipboardCheck, BarChart3 } from 'lucide-react'
import { Card, PageHeader, Stat, Badge } from '../../components/ui'

const STORE_KEY = 'smart-tutor-review-lab-v1'
const STUDENTS = [
  ['ST-01','Aarav Sharma',72,80],['ST-02','Ananya Rao',86,86],['ST-03','Vihaan Patel',58,68],['ST-04','Diya Nair',91,88],['ST-05','Ishaan Gupta',64,72],
  ['ST-06','Meera Iyer',77,77],['ST-07','Kabir Singh',49,60],['ST-08','Saanvi Reddy',83,90],['ST-09','Arjun Das',68,68],['ST-10','Kiara Joshi',95,95],
]
const QUESTIONS = {
  Python: [
    { q:'Which Python keyword defines a function?', options:['func','def','function','define'], answer:1, explain:'Python functions are declared with the def keyword.' },
    { q:'What does len([3, 5, 7]) return?', options:['2','3','15','7'], answer:1, explain:'The list contains three elements.' },
    { q:'Which data type stores key-value pairs?', options:['List','Tuple','Dictionary','Set'], answer:2, explain:'A dictionary stores key-value pairs.' },
    { q:'What is the output of 2 ** 3?', options:['6','8','9','5'], answer:1, explain:'The ** operator means exponentiation: 2³ = 8.' },
    { q:'Which block handles an exception?', options:['catch','error','except','final'], answer:2, explain:'Python uses except to handle exceptions.' },
  ],
  DBMS: [
    { q:'Which SQL command retrieves data?', options:['GET','SELECT','FETCH ALL','OPEN'], answer:1, explain:'SELECT retrieves rows from a table.' },
    { q:'A primary key must be…', options:['Duplicate','Unique and not NULL','Text only','Optional'], answer:1, explain:'A primary key uniquely identifies each row and cannot be NULL.' },
    { q:'Which clause filters grouped rows?', options:['WHERE','ORDER BY','HAVING','FROM'], answer:2, explain:'HAVING filters groups after GROUP BY.' },
    { q:'What does JOIN do?', options:['Combines related rows','Deletes rows','Creates a database','Sorts one column'], answer:0, explain:'JOIN combines related rows from tables.' },
    { q:'Which normal form removes partial dependency?', options:['1NF','2NF','3NF','4NF'], answer:1, explain:'Second Normal Form removes partial functional dependencies.' },
  ],
  'Quantitative Aptitude': [
    { q:'What is 20% of 150?', options:['15','20','30','35'], answer:2, explain:'0.20 × 150 = 30.' },
    { q:'Average of 4, 6 and 8?', options:['5','6','7','8'], answer:1, explain:'(4 + 6 + 8) / 3 = 6.' },
    { q:'If x + 7 = 12, x = ?', options:['3','4','5','6'], answer:2, explain:'Subtract 7 from both sides: x = 5.' },
    { q:'A ratio is 2:3 and total is 25. First part?', options:['5','10','12','15'], answer:1, explain:'2/5 × 25 = 10.' },
    { q:'Simple interest on ₹1000 at 5% for 2 years?', options:['₹50','₹75','₹100','₹150'], answer:2, explain:'SI = P × R × T / 100 = ₹100.' },
  ],
}
function initialState() {
  try { const saved = JSON.parse(localStorage.getItem(STORE_KEY)); if (saved?.students?.length === 10) return saved } catch {}
  return { topic:'Python', quizTitle:'Python Foundations — AI Quiz', students: STUDENTS.map(([id,name,ai,teacher], i) => ({ id,name,ai,teacher, answers:[(i+1)%4, i%2 ? 1 : 0, (i+2)%4, i%3, (i+1)%3], overrides:{} })), generatedAt:'Demo quiz loaded' }
}
const pct = n => `${Math.round(n)}%`

export default function ReviewLab() {
  const [state, setState] = useState(initialState)
  const [selected, setSelected] = useState('ST-01')
  const [message, setMessage] = useState('')
  const questions = QUESTIONS[state.topic] || QUESTIONS.Python
  const active = state.students.find(s => s.id === selected) || state.students[0]
  const update = fn => setState(prev => { const next = fn(prev); try { localStorage.setItem(STORE_KEY, JSON.stringify(next)) } catch {} return next })
  const chartData = useMemo(() => state.students.map(s => ({ name:s.name.split(' ')[0], 'AI score':s.ai, 'Teacher score':s.teacher ?? s.ai, 'Final score':s.teacher ?? s.ai })), [state.students])
  const totals = useMemo(() => {
    const teacherEdits = state.students.reduce((n,s) => n + Object.keys(s.overrides || {}).length, 0)
    const avgAI = state.students.reduce((n,s) => n+s.ai,0)/state.students.length
    const avgTeacher = state.students.reduce((n,s) => n+(s.teacher ?? s.ai),0)/state.students.length
    return { teacherEdits, avgAI, avgTeacher, difference: Math.abs(avgAI-avgTeacher) }
  }, [state.students])
  function generateQuiz() {
    update(prev => ({ ...prev, topic:prev.topic, quizTitle:`${prev.topic} — AI-generated practice quiz`, generatedAt:new Date().toLocaleString(), students:prev.students.map((s,i) => ({...s, answers: QUESTIONS[prev.topic].map((q,j) => (i+j+1)%q.options.length), overrides:{}, ai:Math.max(35,Math.min(100,45+((i*13+prev.topic.length*7)%55))), teacher:null })) }))
    setMessage('A fresh demo quiz has been generated. Review student answers and enter teacher corrections below.')
  }
  function setTeacherScore(id, value) {
    const parsed = value === '' ? null : Math.max(0,Math.min(100,Number(value)))
    update(prev => ({ ...prev, students:prev.students.map(s => s.id===id ? {...s, teacher:parsed} : s) }))
  }
  function setOverride(id, qi, value) {
    update(prev => ({ ...prev, students:prev.students.map(s => {
      if (s.id !== id) return s
      const overrides = {...s.overrides}
      if (value === 'ai') delete overrides[qi]
      else overrides[qi] = Number(value)
      const teacherCorrect = s.answers.reduce((n, answer, idx) => n + ((overrides[idx] ?? (answer === questions[idx].answer ? 1 : 0)) ? 1 : 0), 0)
      return {...s, overrides, teacher:Math.round(teacherCorrect/questions.length*100)}
    }) }))
  }
  function reset() { try { localStorage.removeItem(STORE_KEY) } catch {} setState(initialState()); setMessage('Demo data reset.') }
  const correctedCount = state.students.reduce((n,s) => n+Object.keys(s.overrides || {}).length,0)
  const aiCorrect = active.answers.reduce((n,a,i)=>n+(a===questions[i].answer?1:0),0)
  const teacherCorrect = active.answers.reduce((n,a,i)=>n+((active.overrides?.[i] ?? (a===questions[i].answer?1:0))?1:0),0)
  const finalScore = active.teacher ?? active.ai

  return <>
    <PageHeader title="AI + Teacher Review Lab" subtitle="Demo workspace: compare AI grading with teacher corrections. Teacher decisions always determine the final score." >
      <button className="btn-ghost" onClick={reset}><RotateCcw size={16}/> Reset demo</button>
    </PageHeader>
    <div className="rounded-2xl border border-violet-200 bg-violet-50 p-4 mb-6 text-sm text-violet-900">
      <strong>Demo mode:</strong> this page uses 10 sample students and saves edits in this browser only. Quiz generation and initial scores are simulated for demonstration; connect your LLM/backend to make generation and grading live.
    </div>
    <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
      <Stat label="Sample students" value="10" sub="Ready for review" icon={Users}/>
      <Stat label="Average AI score" value={pct(totals.avgAI)} sub="Initial automated grade" icon={Sparkles} tone="brand"/>
      <Stat label="Average teacher score" value={Number.isNaN(totals.avgTeacher)?'—':pct(totals.avgTeacher)} sub="Teacher grade when entered" icon={ClipboardCheck} tone="green"/>
      <Stat label="Teacher corrections" value={correctedCount} sub="Answer-level overrides" icon={BarChart3} tone="amber"/>
    </div>

    <Card className="p-5 mt-6">
      <div className="flex flex-wrap items-end gap-3 justify-between">
        <div><h2 className="h2">1. Generate a quiz with AI (demo)</h2><p className="muted mt-1">Choose a subject and create a fresh sample quiz.</p></div>
        <div className="flex flex-wrap gap-2 items-center"><select className="input w-56" value={state.topic} onChange={e=>update(p=>({...p,topic:e.target.value,quizTitle:`${e.target.value} — practice quiz`}))}><option>Python</option><option>DBMS</option><option>Quantitative Aptitude</option></select><button className="btn-primary" onClick={generateQuiz}><Sparkles size={16}/> Generate quiz</button></div>
      </div>
      <div className="mt-4 rounded-xl bg-slate-50 p-4"><div className="font-semibold">{state.quizTitle}</div><div className="text-xs text-slate-500 mt-1">{questions.length} multiple-choice questions · {state.generatedAt}</div><div className="grid md:grid-cols-2 gap-3 mt-4">{questions.map((q,i)=><div key={q.q} className="rounded-xl bg-white border p-3"><div className="text-xs text-slate-500">Question {i+1}</div><div className="text-sm font-medium mt-1">{q.q}</div><div className="text-xs text-emerald-700 mt-2">Answer: {q.options[q.answer]} — {q.explain}</div></div>)}</div></div>
      {message && <p className="text-sm text-emerald-700 mt-3" role="status">{message}</p>}
    </Card>

    <div className="grid xl:grid-cols-5 gap-6 mt-6">
      <Card className="p-5 xl:col-span-2"><h2 className="h2">2. Select a student to review</h2><p className="muted mt-1">AI evaluation, teacher evaluation, and final result.</p>
        <label className="label mt-4">Student</label><select className="input" value={selected} onChange={e=>setSelected(e.target.value)}>{state.students.map(s=><option key={s.id} value={s.id}>{s.id} · {s.name}</option>)}</select>
        <div className="grid grid-cols-3 gap-2 mt-4"><div className="rounded-xl bg-violet-50 p-3"><div className="text-xs text-violet-700">AI score</div><div className="text-2xl font-bold text-violet-900">{pct(active.ai)}</div></div><div className="rounded-xl bg-sky-50 p-3"><div className="text-xs text-sky-700">Teacher score</div><div className="text-2xl font-bold text-sky-900">{active.teacher == null ? '—' : pct(active.teacher)}</div></div><div className="rounded-xl bg-emerald-50 p-3"><div className="text-xs text-emerald-700">Final score</div><div className="text-2xl font-bold text-emerald-900">{pct(finalScore)}</div></div></div>
        <div className="mt-4 rounded-xl border border-emerald-200 bg-emerald-50 p-3 text-sm text-emerald-900"><div className="font-semibold flex items-center gap-2"><CheckCircle2 size={16}/> Human correction wins</div><p className="mt-1">{active.teacher == null ? 'No teacher grade entered yet, so the AI score is shown as provisional.' : 'Teacher score overrides the AI score and is used as the final score.'}</p></div>
        <label className="label mt-4">Teacher final score (0–100)</label><input className="input" type="number" min="0" max="100" value={active.teacher ?? ''} placeholder="Enter teacher score" onChange={e=>setTeacherScore(active.id,e.target.value)}/><p className="text-xs text-slate-500 mt-1">Enter or adjust a score to override the AI result. Clear the field to return to provisional AI score.</p>
      </Card>
      <Card className="p-5 xl:col-span-3"><h2 className="h2">3. Correct individual answers</h2><p className="muted mt-1">The teacher can accept or change the AI's answer evaluation.</p>
        <div className="mt-4 space-y-3">{questions.map((q,i)=>{const isCorrect=active.answers[i]===q.answer; const overridden=Object.prototype.hasOwnProperty.call(active.overrides||{},i); const teacherIsCorrect=(active.overrides?.[i] ?? (isCorrect?1:0))===1; return <div key={q.q} className="rounded-xl border p-3"><div className="flex items-start justify-between gap-3"><div><div className="text-xs text-slate-500">Question {i+1}</div><div className="text-sm font-semibold">{q.q}</div></div><Badge tone={overridden?'Watch':isCorrect?'On track':'Needs Support'}>{overridden?'Teacher corrected':isCorrect?'AI correct':'AI incorrect'}</Badge></div><div className="grid md:grid-cols-2 gap-2 mt-3 text-sm"><div className="rounded-lg bg-slate-50 p-2"><span className="text-slate-500">Student answer:</span> {q.options[active.answers[i] % q.options.length]}</div><div className="rounded-lg bg-emerald-50 p-2"><span className="text-slate-500">Correct answer:</span> {q.options[q.answer]}</div></div><div className="mt-3 flex flex-wrap items-center justify-between gap-2"><div className="text-xs text-slate-600">Teacher evaluation: <strong>{teacherIsCorrect?'Correct':'Incorrect'}</strong></div><div className="flex gap-2"><button className="btn-ghost text-xs" onClick={()=>setOverride(active.id,i,'1')}>Mark correct</button><button className="btn-ghost text-xs" onClick={()=>setOverride(active.id,i,'0')}>Mark incorrect</button><button className="btn-ghost text-xs" onClick={()=>setOverride(active.id,i,'ai')}>Use AI</button></div></div></div>})}</div>
        <div className="mt-4 grid grid-cols-2 gap-3"><div className="rounded-xl border p-3"><div className="text-xs text-slate-500">AI answer evaluation</div><div className="text-xl font-bold">{aiCorrect}/{questions.length} correct</div><div className="text-xs text-slate-500">{pct(aiCorrect/questions.length*100)}</div></div><div className="rounded-xl border p-3"><div className="text-xs text-slate-500">Teacher answer evaluation</div><div className="text-xl font-bold">{teacherCorrect}/{questions.length} correct</div><div className="text-xs text-slate-500">{pct(teacherCorrect/questions.length*100)}</div></div></div>
      </Card>
    </div>

    <Card className="p-5 mt-6"><h2 className="h2">4. AI vs teacher score comparison</h2><p className="muted mt-1">Both scores are displayed for all 10 students. A teacher-entered score becomes the final score.</p><div className="h-80 mt-4"><ResponsiveContainer width="100%" height="100%"><BarChart data={chartData} margin={{top:10,right:10,left:0,bottom:5}}><CartesianGrid strokeDasharray="3 3"/><XAxis dataKey="name" tick={{fontSize:12}}/><YAxis domain={[0,100]} tickFormatter={v=>`${v}%`}/><Tooltip formatter={v=>`${v}%`}/><Legend/><Bar dataKey="AI score" fill="#8b5cf6" radius={[4,4,0,0]}/><Bar dataKey="Teacher score" fill="#0ea5e9" radius={[4,4,0,0]}/><Bar dataKey="Final score" fill="#10b981" radius={[4,4,0,0]}/></BarChart></ResponsiveContainer></div></Card>

    <div className="grid lg:grid-cols-2 gap-6 mt-6"><Card className="p-5"><h2 className="h2">5. Quiz correction graph</h2><p className="muted mt-1">Count of answers accepted by AI vs changed by the teacher.</p><div className="h-64 mt-4"><ResponsiveContainer width="100%" height="100%"><BarChart data={[{name:'AI evaluation',accepted:state.students.reduce((n,s)=>n+s.answers.filter((a,i)=>a===questions[i].answer).length,0),corrected:0},{name:'Teacher review',accepted:state.students.reduce((n,s)=>n+s.answers.filter((a,i)=>(s.overrides?.[i] ?? (a===questions[i].answer?1:0))===1).length,0),corrected:correctedCount}]}><CartesianGrid strokeDasharray="3 3"/><XAxis dataKey="name"/><YAxis allowDecimals={false}/><Tooltip/><Legend/><Bar dataKey="accepted" name="Answers marked correct" fill="#10b981" radius={[4,4,0,0]}/><Bar dataKey="corrected" name="Teacher overrides" fill="#f59e0b" radius={[4,4,0,0]}/></BarChart></ResponsiveContainer></div></Card>
      <Card className="p-5"><h2 className="h2">6. Student score register</h2><p className="muted mt-1">Final score follows teacher score when provided.</p><div className="overflow-x-auto mt-3"><table className="w-full text-sm"><thead><tr className="border-b text-left text-slate-500"><th className="py-2">Student</th><th>AI</th><th>Teacher</th><th>Final</th><th>Source</th></tr></thead><tbody>{state.students.map(s=><tr className="border-b last:border-0" key={s.id}><td className="py-2"><div className="font-medium">{s.name}</div><div className="text-xs text-slate-400">{s.id}</div></td><td>{s.ai}%</td><td>{s.teacher == null?'—':`${s.teacher}%`}</td><td className="font-bold text-emerald-700">{s.teacher ?? s.ai}%</td><td><Badge tone={s.teacher == null?'ai':'On track'}>{s.teacher == null?'AI provisional':'Teacher final'}</Badge></td></tr>)}</tbody></table></div></Card></div>
  </>
}
