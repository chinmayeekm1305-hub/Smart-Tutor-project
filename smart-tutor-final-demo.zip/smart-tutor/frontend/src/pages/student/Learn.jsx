import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { ChevronRight } from 'lucide-react'
import { api } from '../../api'
import { Badge, Card, ErrorBox, MasteryBar, PageHeader, Spinner } from '../../components/ui'

export default function Learn() {
  const [subjects, setSubjects] = useState(null)
  const [err, setErr] = useState('')
  useEffect(() => { api('/api/subjects').then(setSubjects).catch(e => setErr(e.message)) }, [])
  if (err) return <ErrorBox error={err} />
  if (!subjects) return <Spinner />
  return (
    <>
      <PageHeader title="Learn" subtitle="Notes adapt to your level. Quizzes adapt after every answer." />
      <div className="space-y-6">
        {subjects.map(s => (
          <Card key={s.id} className="p-5">
            <div className="flex items-center gap-3">
              <div className="text-3xl">{s.icon}</div>
              <div><h2 className="text-lg font-bold text-slate-900">{s.name}</h2><p className="muted">{s.description}</p></div>
            </div>
            <div className="mt-4 grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {s.topics.map(t => (
                <Link key={t.id} to={`/student/topic/${t.id}`} className="group rounded-xl border border-slate-200 p-4 hover:border-brand-300 hover:shadow-md transition">
                  <div className="flex items-start justify-between gap-2">
                    <div className="font-semibold text-slate-800">{t.name}</div>
                    <ChevronRight size={16} className="text-slate-400 group-hover:text-brand-600 shrink-0" />
                  </div>
                  <div className="mt-1 text-xs text-slate-500">{t.questions} questions</div>
                  <div className="mt-3">
                    {t.mastery != null
                      ? <><div className="mb-1"><Badge>{t.level}</Badge></div><MasteryBar value={t.mastery} /></>
                      : <span className="text-xs text-slate-400">Not started</span>}
                  </div>
                </Link>
              ))}
            </div>
          </Card>
        ))}
      </div>
    </>
  )
}
