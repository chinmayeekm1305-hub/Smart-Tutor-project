import { useEffect, useRef, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { Bot, Loader2, Send, Trash2, User } from 'lucide-react'
import { api } from '../../api'
import { Card, Markdown, PageHeader } from '../../components/ui'

const STARTERS = {
  'Python Programming': ['Explain the difference between a list and a tuple', 'Why does 0.1 + 0.2 != 0.3?', 'Give me a tricky question on default arguments'],
  DBMS: ['Explain 2NF vs 3NF with an example', 'When should I use LEFT JOIN?', 'What does ACID mean, in simple words?'],
  'Quantitative Aptitude': ['Teach me the LCM trick for time & work', 'Why does +20% then -20% give a loss?', 'Give me one practice problem on CI'],
}

export default function Tutor() {
  const [params] = useSearchParams()
  const [subjects, setSubjects] = useState([])
  const [topicId, setTopicId] = useState(params.get('topic') || '')
  const [msgs, setMsgs] = useState([])
  const [input, setInput] = useState('')
  const [busy, setBusy] = useState(false)
  const [provider, setProvider] = useState('')
  const end = useRef(null)

  useEffect(() => {
    api('/api/subjects').then(setSubjects)
    api('/api/tutor/history').then(setMsgs)
    api('/api/tutor/status').then(s => setProvider(s.provider))
  }, [])
  useEffect(() => { end.current?.scrollIntoView({ behavior: 'smooth' }) }, [msgs, busy])

  const topic = subjects.flatMap(s => s.topics.map(t => ({ ...t, subject: s.name }))).find(t => String(t.id) === String(topicId))
  const starters = STARTERS[topic?.subject] || ['How should I prepare for placements aptitude?', 'Explain primary key vs foreign key', 'What is a Python dictionary?']

  const send = async text => {
    const message = (text ?? input).trim()
    if (!message || busy) return
    setInput(''); setMsgs(m => [...m, { role: 'user', content: message }]); setBusy(true)
    try {
      const r = await api('/api/tutor/chat', { method: 'POST', body: { message, topic_id: topicId ? Number(topicId) : null } })
      setMsgs(m => [...m, { role: 'assistant', content: r.reply }]); setProvider(r.provider)
    } catch (e) {
      setMsgs(m => [...m, { role: 'assistant', content: `⚠️ ${e.message}` }])
    } finally { setBusy(false) }
  }
  const clear = async () => { await api('/api/tutor/history', { method: 'DELETE' }); setMsgs([]) }

  return (
    <>
      <PageHeader title="AI Tutor" subtitle={`Answers adapt to your level · engine: ${provider || '…'}`}>
        <select className="input w-56" value={topicId} onChange={e => setTopicId(e.target.value)}>
          <option value="">General (any topic)</option>
          {subjects.map(s => <optgroup key={s.id} label={s.name}>{s.topics.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}</optgroup>)}
        </select>
        <button className="btn-ghost" onClick={clear} title="Clear chat"><Trash2 size={16} /></button>
      </PageHeader>

      <Card className="flex flex-col h-[calc(100vh-220px)] min-h-[420px]">
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {msgs.length === 0 && (
            <div className="text-center py-10">
              <div className="mx-auto h-14 w-14 rounded-2xl bg-brand-50 grid place-items-center"><Bot className="text-brand-600" size={28} /></div>
              <div className="mt-3 font-semibold text-slate-800">Hi! I'm your Smart Tutor.</div>
              <p className="muted">Pick a topic above for focused help, or try one of these:</p>
              <div className="mt-4 flex flex-wrap justify-center gap-2">
                {starters.map(s => <button key={s} className="btn-ghost text-xs" onClick={() => send(s)}>{s}</button>)}
              </div>
            </div>
          )}
          {msgs.map((m, i) => (
            <div key={i} className={`flex gap-3 ${m.role === 'user' ? 'flex-row-reverse' : ''}`}>
              <div className={`h-8 w-8 shrink-0 rounded-lg grid place-items-center ${m.role === 'user' ? 'bg-slate-200' : 'bg-brand-600 text-white'}`}>
                {m.role === 'user' ? <User size={16} /> : <Bot size={16} />}
              </div>
              <div className={`max-w-[80%] rounded-2xl px-4 py-2 ${m.role === 'user' ? 'bg-brand-600 text-white' : 'bg-slate-50 border border-slate-200'}`}>
                {m.role === 'user' ? <div className="whitespace-pre-wrap text-sm">{m.content}</div> : <Markdown className="text-sm">{m.content}</Markdown>}
              </div>
            </div>
          ))}
          {busy && <div className="flex items-center gap-2 text-sm text-slate-500"><Loader2 className="animate-spin" size={16} /> Thinking…</div>}
          <div ref={end} />
        </div>
        <form onSubmit={e => { e.preventDefault(); send() }} className="border-t p-3 flex gap-2">
          <input className="input" placeholder={topic ? `Ask about ${topic.name}…` : 'Ask any doubt…'} value={input} onChange={e => setInput(e.target.value)} />
          <button className="btn-primary" disabled={busy || !input.trim()}><Send size={16} /></button>
        </form>
      </Card>
    </>
  )
}
