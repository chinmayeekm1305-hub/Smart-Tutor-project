import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { Bot, CheckCircle2, RotateCcw, XCircle } from 'lucide-react'
import { api, diffLabel } from '../../api'
import { Badge, Card, ErrorBox, Markdown, MasteryBar, Spinner } from '../../components/ui'

export default function QuizResult() {
  const { sessionId } = useParams()
  const [r, setR] = useState(null)
  const [err, setErr] = useState('')
  useEffect(() => { api(`/api/quiz/${sessionId}/result`).then(setR).catch(e => setErr(e.message)) }, [sessionId])
  if (err) return <ErrorBox error={err} />
  if (!r) return <Spinner />
  const pctScore = r.total ? Math.round((100 * r.score) / r.total) : 0

  return (
    <div className="max-w-3xl mx-auto">
      <Card className="p-6 text-center">
        <div className="text-sm text-slate-500">{r.topic}</div>
        <div className="mt-2 text-5xl font-bold text-slate-900">{r.score}<span className="text-2xl text-slate-400">/{r.total}</span></div>
        <div className="mt-1 text-slate-600">{pctScore}% · avg {r.avg_time}s per question</div>
        <div className="mx-auto mt-4 max-w-xs"><div className="label">Topic mastery now</div><MasteryBar value={r.mastery} /><div className="mt-2"><Badge>{r.level}</Badge></div></div>
        <p className="mt-4 text-slate-700">{r.tip}</p>
        <div className="mt-5 flex flex-wrap justify-center gap-2">
          <Link to={`/student/quiz/${r.topic_id}`} className="btn-primary"><RotateCcw size={16} /> Try again</Link>
          <Link to={`/student/topic/${r.topic_id}`} className="btn-ghost">Back to notes</Link>
          <Link to={`/student/tutor?topic=${r.topic_id}`} className="btn-ghost"><Bot size={16} /> Ask AI tutor</Link>
        </div>
      </Card>

      <h2 className="h2 mt-8 mb-3">Answer review</h2>
      <div className="space-y-3">
        {r.review.map((a, i) => (
          <Card key={i} className="p-5">
            <div className="flex items-start gap-3">
              {a.is_correct ? <CheckCircle2 className="text-emerald-600 shrink-0" /> : <XCircle className="text-rose-600 shrink-0" />}
              <div className="flex-1 min-w-0">
                <div className="flex justify-between gap-2"><span className="text-xs text-slate-500">Q{i + 1} · {Math.round(a.time_taken_sec)}s</span><Badge>{diffLabel(a.difficulty)}</Badge></div>
                <Markdown className="text-sm">{a.text}</Markdown>
                <div className="mt-2 text-sm">
                  {!a.is_correct && <div className="text-rose-700">Your answer: {a.options[a.selected_index]}</div>}
                  <div className="text-emerald-700">Correct: {a.options[a.correct_index]}</div>
                  <div className="mt-1 text-slate-600">{a.explanation}</div>
                </div>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  )
}
