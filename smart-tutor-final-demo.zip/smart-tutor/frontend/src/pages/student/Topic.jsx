import { useEffect, useRef, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { ArrowLeft, Bot, PlayCircle, Youtube, Zap } from 'lucide-react'
import { api } from '../../api'
import { Badge, Card, ErrorBox, Markdown, MasteryBar, Spinner } from '../../components/ui'

const VIEWS = [['auto', 'For me'], ['simple', 'Simplified'], ['standard', 'Standard'], ['advanced', 'Advanced']]

export default function TopicPage() {
  const { id } = useParams()
  const [view, setView] = useState('auto')
  const [t, setT] = useState(null)
  const [err, setErr] = useState('')
  const started = useRef(Date.now())

  useEffect(() => {
    setT(null)
    api(`/api/topics/${id}?view=${view}`).then(setT).catch(e => setErr(e.message))
  }, [id, view])

  // log reading time (time spent on topics is an ML feature)
  useEffect(() => {
    started.current = Date.now()
    const flush = () => {
      const secs = Math.round((Date.now() - started.current) / 1000)
      if (secs >= 10) api(`/api/topics/${id}/study`, { method: 'POST', body: { seconds: Math.min(secs, 3600) } }).catch(() => {})
      started.current = Date.now()
    }
    return flush
  }, [id])

  if (err) return <ErrorBox error={err} />
  if (!t) return <Spinner />

  return (
    <div className="grid lg:grid-cols-[1fr_300px] gap-6">
      <div>
        <Link to="/student/learn" className="inline-flex items-center gap-1 text-sm text-slate-500 hover:text-brand-600"><ArrowLeft size={14} /> {t.subject}</Link>
        <div className="mt-3 flex flex-wrap gap-1 rounded-xl bg-slate-100 p-1 w-fit">
          {VIEWS.filter(([v]) => (v !== 'simple' || t.has_simple) && (v !== 'advanced' || t.has_advanced)).map(([v, label]) => (
            <button key={v} onClick={() => setView(v)} className={`rounded-lg px-3 py-1.5 text-sm font-medium ${view === v ? 'bg-white shadow text-brand-700' : 'text-slate-600'}`}>{label}</button>
          ))}
        </div>
        <Card className="mt-4 p-6 sm:p-8"><Markdown>{t.notes}</Markdown></Card>
      </div>

      <div className="space-y-4 lg:sticky lg:top-8 h-fit">
        <Card className="p-5">
          <div className="label">Your level</div>
          <div className="flex items-center gap-2"><Badge>{t.level}</Badge>{view === 'auto' && <span className="text-xs text-slate-500">notes adapted for you</span>}</div>
          {t.mastery != null && <div className="mt-3"><div className="label">Mastery</div><MasteryBar value={t.mastery} /></div>}
          <Link to={`/student/quiz/${t.id}`} className="btn-primary w-full mt-5"><PlayCircle size={16} /> Start adaptive quiz</Link>
          <Link to={`/student/tutor?topic=${t.id}`} className="btn-ghost w-full mt-2"><Bot size={16} /> Ask the AI tutor</Link>
          {t.video_url && <a href={t.video_url} target="_blank" rel="noreferrer" className="btn-ghost w-full mt-2"><Youtube size={16} /> Watch videos</a>}
        </Card>
        <Card className="p-5 text-sm text-slate-600">
          <div className="flex items-center gap-2 font-semibold text-slate-800"><Zap size={16} className="text-amber-500" /> How this adapts</div>
          <ul className="mt-2 space-y-1 list-disc pl-5">
            <li>Below 45% mastery you see <b>simplified notes</b> and easy questions.</li>
            <li>Above 75% you unlock <b>advanced notes</b> and hard questions.</li>
            <li>Every answer updates your mastery using Bayesian Knowledge Tracing.</li>
          </ul>
        </Card>
      </div>
    </div>
  )
}
