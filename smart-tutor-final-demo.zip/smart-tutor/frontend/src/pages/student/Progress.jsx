import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { Bar, BarChart, CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { api, diffLabel } from '../../api'
import { Badge, Card, Empty, ErrorBox, Markdown, PageHeader, Spinner } from '../../components/ui'

export default function Progress() {
  const [p, setP] = useState(null)
  const [mist, setMist] = useState([])
  const [err, setErr] = useState('')
  useEffect(() => {
    api('/api/student/progress').then(setP).catch(e => setErr(e.message))
    api('/api/quiz/mistakes').then(setMist)
  }, [])
  if (err) return <ErrorBox error={err} />
  if (!p) return <Spinner />
  const sessions = p.sessions.map((s, i) => ({ ...s, n: i + 1 }))

  return (
    <>
      <PageHeader title="My Progress" subtitle="Every quiz, every answer, tracked." />
      <div className="grid lg:grid-cols-2 gap-6">
        <Card className="p-5">
          <h2 className="h2">Quiz scores over time</h2>
          <div className="h-64 mt-4">
            <ResponsiveContainer>
              <LineChart data={sessions}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
                <XAxis dataKey="n" fontSize={11} stroke="#94a3b8" label={{ value: 'quiz #', position: 'insideBottom', offset: -2, fontSize: 11 }} />
                <YAxis domain={[0, 100]} unit="%" fontSize={11} stroke="#94a3b8" width={40} />
                <Tooltip formatter={v => `${v}%`} labelFormatter={(n) => sessions[n - 1]?.topic} />
                <Line type="monotone" dataKey="pct" stroke="#4f46e5" strokeWidth={2} dot={{ r: 3 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>
        <Card className="p-5">
          <h2 className="h2">Accuracy by difficulty</h2>
          <div className="h-64 mt-4">
            <ResponsiveContainer>
              <BarChart data={p.by_difficulty.map(d => ({ ...d, name: diffLabel(d.difficulty) }))}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
                <XAxis dataKey="name" fontSize={12} stroke="#94a3b8" />
                <YAxis domain={[0, 100]} unit="%" fontSize={11} stroke="#94a3b8" width={40} />
                <Tooltip formatter={(v, k) => (k === 'accuracy' ? `${v}%` : v)} />
                <Bar dataKey="accuracy" fill="#6366f1" radius={[6, 6, 0, 0]} maxBarSize={56} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </div>

      <Card className="p-5 mt-6">
        <h2 className="h2">Repeated mistakes: your revision list</h2>
        <p className="muted">Questions you've got wrong two or more times. The adaptive quiz brings these back to you.</p>
        <div className="mt-4 space-y-3">
          {mist.length ? mist.map(m => (
            <div key={m.question_id} className="rounded-xl border border-slate-200 p-4">
              <div className="flex justify-between gap-2"><Link to={`/student/topic/${m.topic_id}`} className="text-xs font-semibold text-brand-700">{m.topic}</Link><Badge tone="Hard">wrong {m.times_wrong}×</Badge></div>
              <Markdown className="text-sm">{m.text}</Markdown>
              <div className="text-sm text-emerald-700">Answer: {m.options[m.correct_index]}</div>
              <div className="text-sm text-slate-600">{m.explanation}</div>
            </div>
          )) : <Empty>No repeated mistakes. Nice!</Empty>}
        </div>
      </Card>

      <Card className="p-5 mt-6">
        <h2 className="h2">Quiz history</h2>
        <div className="mt-3 overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="text-left text-slate-500 border-b"><th className="py-2">Date</th><th>Subject</th><th>Topic</th><th className="text-right">Score</th></tr></thead>
            <tbody>
              {[...p.sessions].reverse().map(s => (
                <tr key={s.id} className="border-b last:border-0 hover:bg-slate-50">
                  <td className="py-2">{new Date(s.date).toLocaleDateString()}</td><td>{s.subject}</td>
                  <td><Link to={`/student/result/${s.id}`} className="text-brand-700 hover:underline">{s.topic}</Link></td>
                  <td className="text-right font-semibold">{s.score}/{s.total}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </>
  )
}
