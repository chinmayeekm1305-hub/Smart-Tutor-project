import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { Award, BookOpen, Clock, Flame, HeartPulse, Mail, Sparkles, Target, TrendingDown, TrendingUp } from 'lucide-react'
import { api, pct } from '../../api'
import { Badge, Card, Empty, ErrorBox, MasteryBar, PageHeader, Spinner, Stat } from '../../components/ui'

const REC_STYLE = {
  revise: ['Revise', 'bg-rose-50 border-rose-200'],
  mistakes: ['Fix mistakes', 'bg-amber-50 border-amber-200'],
  practice: ['Practise', 'bg-sky-50 border-sky-200'],
  start: ['Start', 'bg-slate-50 border-slate-200'],
  challenge: ['Challenge', 'bg-emerald-50 border-emerald-200'],
}

export default function Dashboard() {
  const [d, setD] = useState(null)
  const [err, setErr] = useState('')
  const [doubt, setDoubt] = useState('')
  const [sent, setSent] = useState('')

  const load = () => api('/api/student/dashboard').then(setD).catch(e => setErr(e.message))
  useEffect(() => { load() }, [])
  if (err) return <ErrorBox error={err} />
  if (!d) return <Spinner />

  const health = d.learning_health
  const unread = d.messages.filter(m => !m.from_student && !m.is_read)
  const sendDoubt = async () => {
    if (!doubt.trim()) return
    const r = await api('/api/student/doubts', { method: 'POST', body: { message: doubt } })
    setDoubt(''); setSent(`Sent to ${r.teacher}. You'll see the reply here.`); load()
  }
  const markRead = async id => { await api(`/api/student/messages/${id}/read`, { method: 'POST' }); load() }

  return (
    <>
      <PageHeader title={`Hi ${d.user.name.split(' ')[0]} 👋`} subtitle={`${d.user.academic_info} · ${d.user.level_badge} badge · ${d.user.xp} XP`}>
        <Link to="/student/learn" className="btn-primary"><BookOpen size={16} /> Continue learning</Link>
      </PageHeader>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Stat label="Overall accuracy" value={pct(d.stats.accuracy)} icon={Target}
          sub={`last 10 answers: ${d.stats.trend >= 0 ? '▲' : '▼'} ${Math.abs(Math.round(d.stats.trend * 100))} pts`} />
        <Stat label="Questions answered" value={d.stats.attempts} sub={`${d.stats.quizzes} quizzes`} icon={Flame} tone="amber" />
        <Stat label="Study time" value={`${Math.round(d.stats.study_minutes)} min`} sub={`${d.stats.active_days} active days`} icon={Clock} tone="sky" />
        <Stat label="Experience" value={`${d.user.xp} XP`} sub={`${d.user.level_badge} badge`} icon={Award} tone="green" />
      </div>

      {unread.length > 0 && (
        <Card className="mt-6 p-4 border-brand-200 bg-brand-50">
          {unread.map(m => (
            <div key={m.id} className="flex gap-3">
              <Mail className="text-brand-600 shrink-0 mt-0.5" size={18} />
              <div className="flex-1">
                <div className="text-sm font-semibold text-brand-900">Message from {m.teacher}</div>
                <p className="text-sm text-slate-700 mt-1">{m.message}</p>
              </div>
              <button className="btn-ghost h-8" onClick={() => markRead(m.id)}>Got it</button>
            </div>
          ))}
        </Card>
      )}

      <div className="mt-6 grid lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2 p-5">
          <div className="flex items-center justify-between">
            <h2 className="h2 flex items-center gap-2"><Sparkles size={18} className="text-brand-600" /> Recommended for you</h2>
            <span className="muted">Personalised by the adaptive engine</span>
          </div>
          <div className="mt-4 grid sm:grid-cols-2 gap-3">
            {d.recommendations.map(r => {
              const [tag, cls] = REC_STYLE[r.kind]
              return (
                <Link key={r.topic_id} to={`/student/topic/${r.topic_id}`} className={`rounded-xl border p-4 hover:shadow-md transition ${cls}`}>
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-bold uppercase tracking-wide text-slate-600">{tag}</span>
                    <span className="text-xs text-slate-500">{r.subject}</span>
                  </div>
                  <div className="mt-1 font-semibold text-slate-900">{r.topic}</div>
                  <div className="mt-1 text-xs text-slate-600">{r.reason}</div>
                  <div className="mt-2 text-xs font-medium text-brand-700">→ {r.action}</div>
                </Link>
              )
            })}
          </div>
        </Card>

        <Card className="p-5">
          <h2 className="h2 flex items-center gap-2"><HeartPulse size={18} className="text-rose-500" /> Learning health</h2>
          <p className="muted mt-1">ML model trained on learning behaviour</p>
          <div className="mt-4 flex items-center gap-3">
            <Badge>{health.label}</Badge>
            {health.risk != null && <span className="text-sm text-slate-600">risk score {Math.max(1, Math.round(health.risk * 100))}/100</span>}
          </div>
          {health.drivers.length > 0
            ? <ul className="mt-3 space-y-1 text-sm text-slate-600 list-disc pl-5">{health.drivers.map(x => <li key={x}>{x}</li>)}</ul>
            : <p className="mt-3 text-sm text-slate-600">No warning signs. Keep up the steady practice!</p>}
          <div className="mt-5 grid grid-cols-2 gap-3">
            <div>
              <div className="label flex items-center gap-1"><TrendingUp size={12} /> Strengths</div>
              {d.strengths.length ? d.strengths.map(t => <div key={t.topic_id} className="text-sm text-slate-700 truncate">{t.topic}</div>) : <div className="muted">—</div>}
            </div>
            <div>
              <div className="label flex items-center gap-1"><TrendingDown size={12} /> Focus areas</div>
              {d.weaknesses.length ? d.weaknesses.map(t => <div key={t.topic_id} className="text-sm text-slate-700 truncate">{t.topic}</div>) : <div className="muted">—</div>}
            </div>
          </div>
        </Card>
      </div>

      <div className="mt-6 grid lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2 p-5">
          <h2 className="h2">Accuracy over the last 14 days</h2>
          <div className="h-60 mt-4">
            <ResponsiveContainer>
              <AreaChart data={d.trend}>
                <defs><linearGradient id="g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#6366f1" stopOpacity={0.3} /><stop offset="1" stopColor="#6366f1" stopOpacity={0} /></linearGradient></defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
                <XAxis dataKey="date" tickFormatter={v => v.slice(5)} fontSize={11} stroke="#94a3b8" />
                <YAxis domain={[0, 100]} unit="%" fontSize={11} stroke="#94a3b8" width={40} />
                <Tooltip formatter={v => (v == null ? 'no activity' : `${v}%`)} />
                <Area type="monotone" dataKey="accuracy" stroke="#4f46e5" strokeWidth={2} fill="url(#g)" connectNulls />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card className="p-5">
          <h2 className="h2">Topic mastery</h2>
          <div className="mt-4 space-y-3 max-h-60 overflow-y-auto pr-1">
            {d.topics.length ? [...d.topics].reverse().map(t => (
              <Link to={`/student/topic/${t.topic_id}`} key={t.topic_id} className="block">
                <div className="flex justify-between text-sm"><span className="font-medium text-slate-700 truncate">{t.topic}</span><Badge>{t.level}</Badge></div>
                <MasteryBar value={t.mastery} className="mt-1" />
              </Link>
            )) : <Empty>Take your first quiz to see mastery.</Empty>}
          </div>
        </Card>
      </div>

      <div className="mt-6 grid lg:grid-cols-2 gap-6">
        <Card className="p-5">
          <h2 className="h2">Recent quizzes</h2>
          <div className="mt-3 divide-y">
            {d.recent_quizzes.length ? d.recent_quizzes.map(q => (
              <Link key={q.id} to={`/student/result/${q.id}`} className="flex justify-between py-2 text-sm hover:bg-slate-50 rounded px-1">
                <span className="text-slate-700">{q.topic}</span>
                <span className="font-semibold">{q.score}/{q.total}</span>
              </Link>
            )) : <Empty>No quizzes yet.</Empty>}
          </div>
        </Card>
        <Card className="p-5">
          <h2 className="h2">Ask your teacher</h2>
          <p className="muted mt-1">The AI tutor can't settle everything. Send a doubt to a real teacher.</p>
          <textarea className="input mt-3 h-20" placeholder="Type your doubt…" value={doubt} onChange={e => setDoubt(e.target.value)} />
          <div className="mt-2 flex items-center justify-between gap-2">
            <span className="text-xs text-emerald-600">{sent}</span>
            <button className="btn-primary" onClick={sendDoubt} disabled={!doubt.trim()}>Send to teacher</button>
          </div>
          {d.messages.length > 0 && (
            <div className="mt-4 space-y-2 max-h-48 overflow-y-auto">
              {d.messages.map(m => (
                <div key={m.id} className={`rounded-xl p-3 text-sm ${m.from_student ? 'bg-slate-50 ml-8' : 'bg-brand-50 mr-8'}`}>
                  <div className="text-xs font-semibold text-slate-500">{m.from_student ? 'You' : m.teacher} · {new Date(m.created_at).toLocaleDateString()}</div>
                  <div className="text-slate-700 mt-0.5">{m.message}</div>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>
    </>
  )
}
