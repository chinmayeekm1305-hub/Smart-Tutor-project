import { useEffect, useRef, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { ArrowRight, Bot, CheckCircle2, Loader2, TrendingDown, TrendingUp, XCircle } from 'lucide-react'
import { api, diffLabel } from '../../api'
import { Badge, Card, ErrorBox, Markdown, MasteryBar, Spinner } from '../../components/ui'

export default function Quiz() {
  const { topicId } = useParams()
  const nav = useNavigate()
  const [session, setSession] = useState(null)
  const [q, setQ] = useState(null)
  const [picked, setPicked] = useState(null)
  const [fb, setFb] = useState(null)
  const [aiExpl, setAiExpl] = useState('')
  const [aiBusy, setAiBusy] = useState(false)
  const [mastery, setMastery] = useState(null)
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState('')
  const t0 = useRef(Date.now())
  const startedRef = useRef(false)

  useEffect(() => {
    if (startedRef.current) return   // avoid a double start in React StrictMode
    startedRef.current = true
    api('/api/quiz/start', { method: 'POST', body: { topic_id: Number(topicId) } })
      .then(s => { setSession(s); setQ(s.question); setMastery(s.mastery); t0.current = Date.now() })
      .catch(e => setErr(e.message))
  }, [topicId])

  const answer = async idx => {
    if (fb || busy) return
    setPicked(idx); setBusy(true)
    try {
      const r = await api(`/api/quiz/${session.session_id}/answer`, {
        method: 'POST', body: { question_id: q.id, selected_index: idx, time_taken_sec: (Date.now() - t0.current) / 1000 },
      })
      setFb(r); setMastery(r.mastery)
    } catch (e) { setErr(e.message) } finally { setBusy(false) }
  }

  const next = () => {
    if (fb.finished) return nav(`/student/result/${session.session_id}`)
    setQ(fb.next_question); setFb(null); setPicked(null); setAiExpl(''); t0.current = Date.now()
  }

  const explainAI = async () => {
    setAiBusy(true)
    try {
      const r = await api('/api/quiz/explain', { method: 'POST', body: { question_id: q.id, selected_index: picked } })
      setAiExpl(r.explanation)
    } catch (e) { setAiExpl(e.message) } finally { setAiBusy(false) }
  }

  if (err) return <ErrorBox error={err} />
  if (!q) return <Spinner label="Preparing your adaptive quiz…" />

  const progress = ((q.number - 1 + (fb ? 1 : 0)) / q.total) * 100
  const optClass = i => {
    if (!fb) return 'border-slate-200 hover:border-brand-400 hover:bg-brand-50'
    if (i === fb.correct_index) return 'border-emerald-400 bg-emerald-50'
    if (i === picked) return 'border-rose-400 bg-rose-50'
    return 'border-slate-200 opacity-60'
  }

  return (
    <div className="max-w-3xl mx-auto">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <div className="text-sm text-slate-500">{session.subject}</div>
          <h1 className="h1">{session.topic}</h1>
        </div>
        <div className="w-48"><div className="label">Live mastery</div><MasteryBar value={mastery} /></div>
      </div>

      <div className="mt-4 h-2 rounded-full bg-slate-200 overflow-hidden"><div className="h-full bg-brand-600 transition-all" style={{ width: `${progress}%` }} /></div>

      <Card className="mt-6 p-6">
        <div className="flex items-center justify-between">
          <span className="text-sm font-semibold text-slate-500">Question {q.number} of {q.total}</span>
          <Badge>{diffLabel(q.difficulty)}</Badge>
        </div>
        <Markdown className="mt-3 text-lg">{q.text}</Markdown>
        <div className="mt-5 grid gap-3">
          {q.options.map((o, i) => (
            <button key={i} disabled={!!fb || busy} onClick={() => answer(i)}
              className={`flex items-center gap-3 rounded-xl border-2 px-4 py-3 text-left transition ${optClass(i)}`}>
              <span className="h-7 w-7 shrink-0 rounded-lg bg-white border grid place-items-center text-sm font-bold text-slate-600">{String.fromCharCode(65 + i)}</span>
              <span className="text-slate-800">{o}</span>
              {fb && i === fb.correct_index && <CheckCircle2 className="ml-auto text-emerald-600" size={20} />}
              {fb && i === picked && i !== fb.correct_index && <XCircle className="ml-auto text-rose-600" size={20} />}
            </button>
          ))}
        </div>
      </Card>

      {fb && (
        <Card className={`mt-4 p-5 border-2 ${fb.correct ? 'border-emerald-200' : 'border-rose-200'}`}>
          <div className="flex flex-wrap items-center gap-3">
            {fb.correct
              ? <span className="flex items-center gap-2 font-bold text-emerald-700"><CheckCircle2 /> Correct! +{fb.xp_gained} XP</span>
              : <span className="flex items-center gap-2 font-bold text-rose-700"><XCircle /> Not quite</span>}
            <span className="flex items-center gap-1 text-sm text-slate-600">
              {fb.mastery >= fb.mastery_before ? <TrendingUp size={16} className="text-emerald-600" /> : <TrendingDown size={16} className="text-rose-600" />}
              Mastery {Math.round(fb.mastery_before * 100)}% → {Math.round(fb.mastery * 100)}%
            </span>
          </div>
          <p className="mt-3 text-slate-700">{fb.explanation}</p>
          {!fb.correct && (
            <div className="mt-3">
              {aiExpl
                ? <div className="rounded-xl bg-violet-50 p-4"><div className="flex items-center gap-2 text-sm font-semibold text-violet-800"><Bot size={16} /> AI tutor explains</div><Markdown className="mt-1 text-sm">{aiExpl}</Markdown></div>
                : <button className="btn-ghost" onClick={explainAI} disabled={aiBusy}>{aiBusy ? <Loader2 size={16} className="animate-spin" /> : <Bot size={16} />} Explain my mistake</button>}
            </div>
          )}
          <div className="mt-4 flex items-center justify-between gap-3">
            <span className="text-xs text-slate-500">{fb.finished ? 'Quiz complete!' : fb.adapt_reason}</span>
            <button className="btn-primary" onClick={next}>{fb.finished ? 'See results' : 'Next question'} <ArrowRight size={16} /></button>
          </div>
        </Card>
      )}
    </div>
  )
}
